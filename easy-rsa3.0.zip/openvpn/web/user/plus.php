
<a href="" class="btn btn btn-danger btn-large" target="_blank">购买卡密</a>
<a href="" class="btn btn btn-warning btn-large" target="_blank">联系我们</a>
<a href="http://" class="btn btn btn-danger btn-large" target="_blank">客户端下载</a>

