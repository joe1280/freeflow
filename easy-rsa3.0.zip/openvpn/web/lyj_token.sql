﻿-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2016-07-29 14:09:19
-- 服务器版本： 5.5.42-log
-- PHP Version: 5.4.41

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `love`
--

-- --------------------------------------------------------

--
-- 表的结构 `lyj_token`
--

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='登录令牌表';

--
-- 转存表中的数据 `lyj_token`
--

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, '9651bf37257165b96e92e1839afa59b2', 1472321068, 1469729068),
(2, 2, '1ade3b90bde227ec3242fa4c65369ad9', 1789665003, 1789665003);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lyj_token`
--
ALTER TABLE `lyj_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lyj_token`
--
ALTER TABLE `lyj_token`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
