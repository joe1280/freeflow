--
-- 设置表
--
DROP TABLE IF EXISTS `lyj_setting`;
CREATE TABLE `lyj_setting` (
  `id`   INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `skey` VARCHAR(100)     NOT NULL DEFAULT '要设置的键',
  `sval` VARCHAR(1024)    NOT NULL DEFAULT '要设置的值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `skey` (`skey`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '设置表';

INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES (1, 'contact', '1850696151');
INSERT INTO `lyj_setting` (`id`, `skey`, `sval`)
VALUES (2, 'seo_title', 'key123456');
INSERT INTO `lyj_setting` (`id`, `skey`, `sval`)
VALUES (3, 'seo_keywords', 'http://d.5857.com/htfss_140227/004.jpg');
INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES (4, 'seo_description', '河南移动用户今天请更新线路');
INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES (5, 'copyright', 'http://d.5857.com/htfss_140227/004.jpg');

--
-- 栏目表
--
DROP TABLE IF EXISTS `lyj_category`;
CREATE TABLE `lyj_category` (
  `id`          INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(100)     NOT NULL DEFAULT '默认栏目',
  `description` VARCHAR(255)     NOT NULL DEFAULT '栏目简介',
  `sortby`      INT(5)           NOT NULL DEFAULT 0,
  `hidden`      INT(2)           NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '栏目表';

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES (1, '某动', '', 1, 0);
INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES (2, '某通', '', 2, 0);
INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES (3, '某信', '', 3, 0);

--
-- 文章表
--
DROP TABLE IF EXISTS `lyj_article`;
CREATE TABLE `lyj_article` (
  `id`          INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` INT(10) UNSIGNED NOT NULL,
  `title`       VARCHAR(255)     NOT NULL DEFAULT '无题',
  `content`     TEXT             NOT NULL,
  `visit_count` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `timeline`    INT(10)          NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '文章表';

INSERT INTO `lyj_article` (`id`, `category_id`, `title`, `content`, `timeline`) VALUES (1, 1, '某通线路', '添加线路内容', 0);


--
-- 登录令牌表
--
DROP TABLE IF EXISTS `lyj_token`;
CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id`              INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`         INT(10) UNSIGNED NOT NULL,
  `token`           VARCHAR(32)      NOT NULL,
  `expire_timeline` INT(10)          NOT NULL,
  `update_timeline` INT(10)          NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '登录令牌表';

--
-- 用户表
--
DROP TABLE IF EXISTS `lyj_user`;
CREATE TABLE IF NOT EXISTS `lyj_user` (
  `id`        INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `account`   VARCHAR(15)               DEFAULT NULL,
  `password`  VARCHAR(32)               DEFAULT NULL,
  `nick`      VARCHAR(15)      NOT NULL,
  `face`      VARCHAR(255)              DEFAULT NULL,
  `sex`       INT(2)                    DEFAULT 0,
  `device_id` VARCHAR(20)      NOT NULL,
  `is_forbidden`    INT(10)          NOT NULL DEFAULT 0,
  `is_app`    INT(2)                    DEFAULT 0,
  `timeline`  INT(10)          NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '用户表';

INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`)
VALUES (1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '风语者', '', 1, '1163844562', 0, 0, 0);
INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`)
VALUES (2, 'lyj', '369189fb6b1d00e690a15496240d09d8', '风语者', '', 1, '1163844562', 0, 0, 0);

--
-- 友链表
--
DROP TABLE IF EXISTS `lyj_link`;
CREATE TABLE `lyj_link` (
  `id`          INT(8) UNSIGNED  NOT NULL AUTO_INCREMENT,
  `category_id` INT(10) UNSIGNED NOT NULL,
  `name`        VARCHAR(200)     NOT NULL DEFAULT '链接名称',
  `description` VARCHAR(255)     NOT NULL DEFAULT '链接简介',
  `url`         VARCHAR(255)     NOT NULL DEFAULT 'http://',
  `icon`        VARCHAR(255)     NOT NULL DEFAULT 'http://',
  `sortby`      INT(5)           NOT NULL DEFAULT 0,
  `hidden`      INT(2)           NOT NULL DEFAULT 0,
  `timeline`    INT(8)           NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
)
  ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  COMMENT = '友链表';

INSERT INTO `lyj_link` (`id`, `category_id`, `name`, `description`, `url`, `icon`, `sortby`, `hidden`, `timeline`)
VALUES (1, 1, '逸云加速器', '我的加速器我做主', 'http://www.baidu.com/',
        'http://www.baidu.com/', 0, 0, 0);
