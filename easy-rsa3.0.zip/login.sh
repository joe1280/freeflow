#!/bin/sh
ip=all.joe1280.com
#!/bin/sh
if [ -z "`curl http://$ip/user/yan.php?user=$username\\&pass=$password | grep ^1`" ] ;then
exit 1
fi
exit 0
