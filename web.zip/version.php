<?php
return array (
  'ver' => '1.7',
  'release' => '2016/6/27 一键脚本，拒绝康师傅盗版！',
  'vername' => '变脸狗控流www.bldog.cn',
);
?>