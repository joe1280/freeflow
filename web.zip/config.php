<?php
//数据库信息
$host = "localhost" ;
$port = "3306" ;
$user = "root" ;
$pwd = "root" ;
$dbname = "ov" ;

//管理员账号
$adminuser='admin';
$adminpass='123456';
//JXL_add for 2016-04-16 begin
$conf_rate="0.1";//推荐人返现折扣率，如：0为不返现，1为全额返现，返点5%填0.05，返点10%填0.1，正常情况下，取值范围（0~1），请须知
//JXL_add for 2016-04-16 end
?>