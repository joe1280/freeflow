<?php
header("Location: ../index.php?s=/Agent/login/login.html"); 
?>