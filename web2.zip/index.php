<?php
/**
 * 功能：框架入口文件
 */

//开启开发者模式
define('APP_DEBUG',true);
//上线生产模式
//define('APP_DEBUG',false);

//定义前台静态资源路径
//这是index开始
define('INDEX_CSS_URL', '/Agent/Public/index/csc/css/');
define('INDEX_JS_URL', '/Agent/Public/index/csc/js/');
//这是index 结束
define('CSS_URL','/Agent/Public/css/');
define('JS_URL','/Agent/Public/js/');
define('FONTS_URL','/Agent/Public/fonts/');
define('IMG_URL','/Agent/Public/img/');
define('PUBLIC_URL','/Public/');
define('PROGRAM_NAME','VPN流量监控系统' );
//设置字符utf-8
header('content-type:text/html;charset=utf-8');
//引入ThinkPHP入口文件
include './ThinkPHP/ThinkPHP.php';
