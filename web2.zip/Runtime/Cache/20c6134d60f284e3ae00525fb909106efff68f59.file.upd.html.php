<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 00:09:33
         compiled from "D:/projects/s17/Agent/View\Info\upd.html" */ ?>
<?php /*%%SmartyHeaderCode:3104457a4ba3d235539-82041336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20c6134d60f284e3ae00525fb909106efff68f59' => 
    array (
      0 => 'D:/projects/s17/Agent/View\\Info\\upd.html',
      1 => 1469595823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3104457a4ba3d235539-82041336',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'agent_info' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a4ba3d28c83',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a4ba3d28c83')) {function content_57a4ba3d28c83($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>代理修改</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<ol class="breadcrumb">
    <li><a href="<?php echo @__MODULE__;?>
/agent/index" target="_self">代理管理</a></li>
    <li class="active">修改代理</li>
</ol>
<a href="<?php echo @__MODULE__;?>
/agent/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

<form style="margin-left: 20%" method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/upd" TARGET="_self">
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>用户名:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_name'];?>
" disabled="disabled">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>密码:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="password" class="form-control" name="mg_pwd" placeholder="不填默认不修改！">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_email" class="col-xs-2 control-label"><h4>邮箱:</h4></label>
        <div id="mg_email" class="col-xs-5">
            <input type="text" class="form-control" name="mg_email" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_email'];?>
">
        </div>
    </div>
    <button type="submit" style="margin-left: 20%" class="btn btn-primary">提交</button>
</form>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>