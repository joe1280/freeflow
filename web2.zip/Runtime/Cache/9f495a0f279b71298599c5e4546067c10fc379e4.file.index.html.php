<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:39:38
         compiled from "/var/www/html/Agent/View/Shop/index.html" */ ?>
<?php /*%%SmartyHeaderCode:55485081957a5ad02df7f02-56268930%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9f495a0f279b71298599c5e4546067c10fc379e4' => 
    array (
      0 => '/var/www/html/Agent/View/Shop/index.html',
      1 => 1470650984,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '55485081957a5ad02df7f02-56268930',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5ad02edd2a',
  'variables' => 
  array (
    'z_info' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5ad02edd2a')) {function content_57a5ad02edd2a($_smarty_tpl) {?><?php if (!is_callable('smarty_function_math')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/function.math.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>商城管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">
                <form style="margin-left: 5%" method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/z_search" target="_self">
                    <div class="form-group">
                        <div id="mg_name" class="col-xs-5">
                            <input type="text" class="form-control" name="name" value="" placeholder="账号商品名关键字">
                        </div>
                    </div>
                    <button type="submit"  class="btn btn-primary ">搜索</button>
                    <a href="<?php echo @__CONTROLLER__;?>
/index" class="btn btn-primary btn-sm active " role="button" target="_self" style="margin-left: 2%">管理账号商品</a>
                    <a href="<?php echo @__CONTROLLER__;?>
/k_index" class="btn btn-primary btn-sm active " role="button" target="_self" style="margin-left: 2%">管理卡密商品</a>
                </form>
                <hr>
                <a href="<?php echo @__CONTROLLER__;?>
/z_addition" class="btn btn-primary btn-sm active " role="button" target="_self">添加账号商品</a>
                <a href="<?php echo @__CONTROLLER__;?>
/z_batadd" class="btn btn-primary btn-sm active " role="button" target="_self">批量添加</a>
                <h3>账号商品列表</h3>
                <form method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/z_batdel" target="_self">
                <table class="table">
                    <thead>
                    <tr>
                        <th>选择</th>
                        <th>id</th>
                        <th>商品名</th>
                        <th>用户名</th>
                        <th >密码</th>
                        <th>天数</th>
                        <th >流量</th>
                        <th >状态</th>
                        <th >有效期</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['z_info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <tr>
                        <td><input type="checkbox"  name="ck[]" value="<?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
"/> </td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['type'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['iuser'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['pass'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['days'];?>
天</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['max'];?>
G</td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['state']==0){?>待交易<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['state']==1){?>已出售<?php }?></td>
                        <td><?php echo smarty_function_math(array('equation'=>"(x-y)/z",'x'=>$_smarty_tpl->tpl_vars['v']->value['endtime'],'y'=>time(),'z'=>43200,'format'=>"%.2f"),$_smarty_tpl);?>
天</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/z_upd/z_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
" target="_self">修改</a> </td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/z_del/z_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
" target="_self" onclick="return confirm('您真的要删除该条记录吗？')">删除</a> </td>
                    </tr>
                    <?php } ?>

                    </tbody>
                </table>
                <input type="button" value="全选/取消" class="btn btn-info" id="all" />
                    <button type="submit"  class="btn btn-warning">删除选中</button>
                </form>
                    <br>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>


            </div>

        <hr>
        </div>
    </div>
</div>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script type="text/javascript">
    window.onload = function () {
        var list=document.getElementsByName("ck[]");
        var all=document.getElementById("all");
        var t=0;
        all.onclick = function () {
            if(t==0){
                for(var i=0;i<list.length;i++){
                    list[i].checked = true;
                }
                t=1;
            }else{
                for(var i=0;i<list.length;i++){
                    list[i].checked = false;
                }
                t=0;
            }

        }


    }

</script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>