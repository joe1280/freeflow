<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 21:59:52
         compiled from "/var/www/html/Home/View/Index/index.html" */ ?>
<?php /*%%SmartyHeaderCode:185424308157a5ab14b2d0c1-69497508%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '911e2725b706b7d0a713fc2ebdc7cde8c731450e' => 
    array (
      0 => '/var/www/html/Home/View/Index/index.html',
      1 => 1470664791,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185424308157a5ab14b2d0c1-69497508',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5ab14b9811',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5ab14b9811')) {function content_57a5ab14b9811($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
		<meta name="author" content="Coderthemes">
		<link rel="shortcut icon" href="http://o843f0hn0.bkt.clouddn.com/favicon.ico?attname=&e=1465158001&token=HktW-GgQpfmnfw4AeacOCLxxGKGurH3lJQk22bFA:rD7wX8ltlSqQYXwVwtyTEM9xNAM" type="image/x-icon" />
        <title><?php echo @PROGRAM_NAME;?>
 - 前台用户登录</title>
        <link rel="stylesheet" href="<?php echo @INDEX_CSS_URL;?>
bootstrap.min.css" />
        <link href="<?php echo @INDEX_CSS_URL;?>
core.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
components.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
icons.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
pages.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
responsive.css" rel="stylesheet" type="text/css">
        <script src="../../../Agent/Public/index/csc/js/modernizr.min.js"></script>
        </head>
<body class="widescreen">

		<div class="account-pages">
			<nav class="navbar navbar-default container-fluid " role="navigation" style="margin-bottom:30px;">
   <div class="navbar-header">
      <a style="color:#FFFFFF;" class="navbar-brand" href="http://tss9.cn">Ade 免流</a>
   </div>
   <div>
      <ul class="nav navbar-nav navbar-right">
         <li><a href="#">登录</a></li>
         <li><a href="<?php echo @__MODULE__;?>
/index/register">注册</a></li>
         <li><a href="#" onclick="disp_alert()">提交工单</a></li>         
      </ul>
   </div>
</nav>
		</div>
		<div class="clearfix"></div>
		<div class="wrapper-page">
			<div class="card-box">
			
				<div class="panel-body">
					<form method="post"  method="get" role="form" class="text-center" style="margin-top:30px;">
						<div class="user-thumb">
							<img src="http://q2.qlogo.cn/headimg_dl?bs=2644503544&dst_uin=2644503544&src_uin=2644503544&fid=2644503544&spec=100&url_enc=0&referer=bu_interface&term_type=PC" style="border-radius:50%">
						</div>
						<div class="form-group">
							<h3 class="text-center">登录 <strong class="text-custom">Ade免流</strong></h3>
						</div>
					</form>
				<div class="panel-body">
					<form class="form-horizontal m-t-20"  role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/index" target="_self">

						<div class="form-group ">
							<div class="col-xs-12">
								<input class="form-control" type="text" name="iuser" placeholder="用户名" required="">
							</div>
						</div>

						<div class="form-group">
							<div class="col-xs-12">
								<input class="form-control" type="password" name="pass" placeholder="密码" required="">
							</div>
						</div>

						<div class="form-group ">
							<div class="col-xs-12">
								<div class="checkbox checkbox-primary">
									<input id="checkbox-signup" type="checkbox">
									<label for="checkbox-signup"> 记住我 </label>
								</div>

							</div>
						</div>

						<div class="form-group text-center m-t-40">
							<div class="col-xs-12">
								<button  class="btn btn-pink btn-block text-uppercase waves-effect waves-light" type="submit" >登 录</button>
								
				<a href="<?php echo @__ROOT__;?>
/index.php?s=/Agent/login/login.html" class="btn btn-success btn-block text-uppercase waves-effect waves-light" role="button" target="_self">代理入口</a>
           
							</div>
						</div>

				
								<script>
function login(){
	$.post('./php/Feiniao.php', { username:$('#username').val(),password:$('#password').val(),submit:$('#logindiv').val(),}, 
	function (text, status) { $("#logindiv").html(text) });

}
</script>
<script type="text/javascript">
function disp_alert()
{
alert("工单系统正在开发中...")
}
</script>
					</form>

				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 text-center">
					<p>
						还没有账户吗? <a href="<?php echo @__ROOT__;?>
/index.php?s=/index/register" class="text-primary m-l-5"><b>点这里注册</b></a>
					</p>
				</div>
			</div>

		</div>

		<script>
			var resizefunc = [];
		</script>

		<!-- jQuery  --> 
        <script src="../../../Agent/Public/index/csc/js/bootstrap.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/detect.js"></script>
        <script src="../../../Agent/Public/index/csc/js/fastclick.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.slimscroll.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.blockUI.js"></script>
        <script src="../../../Agent/Public/index/csc/js/waves.js"></script>
        <script src="../../../Agent/Public/index/csc/js/wow.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.nicescroll.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.scrollTo.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.core.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.app.js"></script>

	
</div>
</body>
</html>





























<!--
	作者：1319188427@qq.com
	时间：2016-08-07
	描述：


<body>
<div style="position:absolute; left:0; top:0; width:100%; height:100%"><img src="images/bg2.jpg" width=100% height=100%<?php ?>></div>

    <div class="middle-box text-center loginscreen  animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name"></h1>

            </div>
            <h3><font color=”#0000FF”>欢迎进入llb云流量账号管理中心</font></h3>
            <h3><font color=”#0000FF”>请使用云流量账号登录</font></h3>
            <form class="m-t" role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/index"  target="_self">
                <div class="form-group">
                    <input type="text" name="iuser" class="form-control" placeholder="用户名" required="">
                </div>
                <div class="form-group">
                    <input type="password" name="pass" class="form-control" placeholder="密码" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">登 录</button>


                <p class="text-muted text-center"> <a href="index.html#"><small></small></a> <a href="<?php echo @__MODULE__;?>
/index/register" target="_self"><font color=”#FFFFFF”>注册一个新账号</font></a>
                </p>

            </form>
        </div>
    </div>
    <script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
    <script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
    <script type="text/javascript" src="http://tajs.qq.com/stats?sId=9051096" charset="UTF-8"></script>
</body>

</html>--><?php }} ?>