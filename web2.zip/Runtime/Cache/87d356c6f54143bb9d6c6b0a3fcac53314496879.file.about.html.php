<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:42:21
         compiled from "/var/www/html/Agent/View/Index/about.html" */ ?>
<?php /*%%SmartyHeaderCode:63798119557a5aea99991f8-02636520%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '87d356c6f54143bb9d6c6b0a3fcac53314496879' => 
    array (
      0 => '/var/www/html/Agent/View/Index/about.html',
      1 => 1470652903,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '63798119557a5aea99991f8-02636520',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5aea9a031d',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5aea9a031d')) {function content_57a5aea9a031d($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>关于信息</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <blockquote class="text-warning" style="font-size:14px">
            <!--内容编辑开始    -->
            感谢您的使用！
            <br>欢迎加入交流群:581338296
            <br>Ade免流官网:tss9.cn
            <br>如果程序有BUG，请联系Ade！771637831@qq.com
            <h4 class="text-danger">感谢您的支持！</h4>



            <!--内容编辑结束-->
        </blockquote>

        <hr>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>