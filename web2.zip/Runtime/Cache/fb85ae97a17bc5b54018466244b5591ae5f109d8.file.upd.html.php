<?php /* Smarty version Smarty-3.1.6, created on 2016-08-07 11:51:04
         compiled from "/var/www/html/Agent/View/Server/upd.html" */ ?>
<?php /*%%SmartyHeaderCode:41433593057a6b0287038b0-65322868%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb85ae97a17bc5b54018466244b5591ae5f109d8' => 
    array (
      0 => '/var/www/html/Agent/View/Server/upd.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '41433593057a6b0287038b0-65322868',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a6b0287a965',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a6b0287a965')) {function content_57a6b0287a965($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>服务器修改</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
        <ol class="breadcrumb">
            <li><a href="<?php echo @__MODULE__;?>
/agent/index" target="_self">服务器管理</a></li>
            <li class="active">修改服务器</li>
        </ol>
        <a href="<?php echo @__MODULE__;?>
/server/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

        <form style="margin-left: 20%" method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/upd" TARGET="_self">
            <div class="form-group">
            <label for="mg_name" class="col-xs-2 control-label"><h4>服务器名:</h4></label>
            <div id="mg_name" class="col-xs-5">
                <input type="text" class="form-control" name="s_name" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['s_name'];?>
">
            </div>
            </div>
            <div class="form-group">
            <label for="mg_pwd" class="col-xs-2 control-label"><h4>服务器ip:</h4></label>
            <div id="mg_pwd" class="col-xs-5">
                <input type="text" class="form-control" name="s_ip" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['s_ip'];?>
">
            </div>
            </div>
            <input type="hidden" name="s_id" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['s_id'];?>
">
            <button type="submit" style="margin-left: 20%" class="btn btn-primary">修改</button>
        </form>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>