<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 20:45:57
         compiled from "/var/www/html/Agent/View/Buy/z_index.html" */ ?>
<?php /*%%SmartyHeaderCode:3692991357a5dc0535e437-83663819%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b52c430c882f010ee94e0469663ac63356045dc0' => 
    array (
      0 => '/var/www/html/Agent/View/Buy/z_index.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3692991357a5dc0535e437-83663819',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'z_info' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5dc054ae53',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5dc054ae53')) {function content_57a5dc054ae53($_smarty_tpl) {?><?php if (!is_callable('smarty_function_math')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/function.math.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>商城管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">
                <form style="margin-left: 5%" method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/z_search_t" target="_self">
                    <div class="form-group">
                        <div id="mg_name" class="col-xs-5">
                            <input type="text" class="form-control" name="name" value="" placeholder="搜索天数">
                        </div>
                    </div>
                    <input type="hidden" name="type" value="<?php echo $_smarty_tpl->tpl_vars['z_info']->value[0]['type'];?>
">
                    <button type="submit"  class="btn btn-primary ">搜索</button>
                    <a href="<?php echo @__CONTROLLER__;?>
/index" class="btn btn-primary btn-sm active " role="button" target="_self" style="margin-left: 2%">返回账号商城中心</a>
                </form>
                <hr>
                <span style="font-size: 20px">余额：<span style="color: red;"><?php echo $_SESSION['money'];?>
</span>元</span>
                <hr>
                <a href="<?php echo @__MODULE__;?>
/Buylog/z_log" class="btn btn-primary btn-sm active " role="button" target="_self">查看已购买</a>
                <a onclick="alert('请到余额充值中充值！')" class="btn btn-primary btn-sm active " role="button" target="_self">充值余额</a>
                <hr>
                <form id="list" method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/z_buy" target="_self">
                    <h3><?php echo $_smarty_tpl->tpl_vars['z_info']->value[0]['type'];?>
</h3>
                <table class="table">
                    <thead>
                    <tr>
                        <th>选择</th>
                        <th>id</th>
                        <th>价格</th>
                        <th>用户名</th>
                        <th>天数</th>
                        <th >流量</th>
                        <th >状态</th>
                        <th >有效期</th>

                    </tr>
                    </thead>

                    <tbody >
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['z_info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <tr>
                        <td>
                            <input type="checkbox"  name="ck[]" <?php if ($_smarty_tpl->tpl_vars['v']->value['endtime']>time()&&$_smarty_tpl->tpl_vars['v']->value['state']==0){?> value="<?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
"<?php }?>
                            <?php if ($_smarty_tpl->tpl_vars['v']->value['endtime']<time()||$_smarty_tpl->tpl_vars['v']->value['state']==1){?> value="0"<?php }?>
                            <?php if ($_smarty_tpl->tpl_vars['v']->value['endtime']<time()||$_smarty_tpl->tpl_vars['v']->value['state']==1){?> disabled=true<?php }?> />
                             </td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['z_id'];?>
</td>
                        <td name="p">
                            <?php if ($_SESSION['admin_p']=='p1'){?><?php echo $_smarty_tpl->tpl_vars['v']->value['p1'];?>
<?php }?>
                            <?php if ($_SESSION['admin_p']=='p2'){?><?php echo $_smarty_tpl->tpl_vars['v']->value['p2'];?>
<?php }?>
                            <?php if ($_SESSION['admin_p']=='p3'){?><?php echo $_smarty_tpl->tpl_vars['v']->value['p3'];?>
<?php }?>
                            <?php if ($_SESSION['admin_p']=='p4'){?><?php echo $_smarty_tpl->tpl_vars['v']->value['p4'];?>
<?php }?>
                            <?php if ($_SESSION['admin_p']=='p5'){?><?php echo $_smarty_tpl->tpl_vars['v']->value['p5'];?>
<?php }?>
                        </td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['iuser'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['days'];?>
天</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['max'];?>
G</td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['state']==0){?>待交易<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['state']==1){?>已出售<?php }?></td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['endtime']<time()){?>下架<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['endtime']>time()){?><?php echo smarty_function_math(array('equation'=>"(x-y)/z",'x'=>$_smarty_tpl->tpl_vars['v']->value['endtime'],'y'=>time(),'z'=>43200,'format'=>"%.2f"),$_smarty_tpl);?>
天<?php }?></td>

                    </tr>

                    <?php } ?>
                    </tbody>

                </table>
                    <input type="button" value="全选/取消" class="btn btn-info" id="all" />
                    <input type="hidden" name="type" value="<?php echo $_smarty_tpl->tpl_vars['z_info']->value[0]['type'];?>
">
                    <button id="show" type="button" class="btn btn-success">总价0元
                    <button type="submit"  class="btn btn-primary pull-right">立即购买</button>
                </form>
                <br>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>


            </div>

        <hr>
        </div>
    </div>
</div>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
ck.js"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>