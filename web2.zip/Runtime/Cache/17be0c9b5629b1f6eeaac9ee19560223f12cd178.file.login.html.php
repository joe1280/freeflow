<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 22:01:56
         compiled from "/var/www/html/Agent/View/Login/login.html" */ ?>
<?php /*%%SmartyHeaderCode:115847197457a5acccb5a298-26739517%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '17be0c9b5629b1f6eeaac9ee19560223f12cd178' => 
    array (
      0 => '/var/www/html/Agent/View/Login/login.html',
      1 => 1470664911,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '115847197457a5acccb5a298-26739517',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5acccbc584',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5acccbc584')) {function content_57a5acccbc584($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
		<meta name="author" content="Coderthemes">
		<link rel="shortcut icon" href="http://o843f0hn0.bkt.clouddn.com/favicon.ico?attname=&e=1465158001&token=HktW-GgQpfmnfw4AeacOCLxxGKGurH3lJQk22bFA:rD7wX8ltlSqQYXwVwtyTEM9xNAM" type="image/x-icon" />
        <title><?php echo @PROGRAM_NAME;?>
 - 后台登录</title>
        <link rel="stylesheet" href="<?php echo @INDEX_CSS_URL;?>
bootstrap.min.css" />
        <link href="<?php echo @INDEX_CSS_URL;?>
core.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
components.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
icons.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
pages.css" rel="stylesheet" type="text/css">
        <link href="<?php echo @INDEX_CSS_URL;?>
responsive.css" rel="stylesheet" type="text/css">
        <script src="../../../Agent/Public/index/csc/js/modernizr.min.js"></script>
        </head>
<body class="widescreen">
		<div class="account-pages"></div>
		<div class="clearfix"></div>
		<div class="wrapper-page">
			<div class="card-box">
			
				<div class="panel-body">
					<form method="post"  method="get" role="form" class="text-center">
						<div class="user-thumb">
							<img src="http://q2.qlogo.cn/headimg_dl?bs=2644503544&dst_uin=2644503544&src_uin=2644503544&fid=2644503544&spec=100&url_enc=0&referer=bu_interface&term_type=PC" style="border-radius:50%">
						</div>
						<div class="form-group">
							<h3 class="text-center">登录 <strong class="text-custom">Ade免流</strong></h3>
						</div>
					</form>
				<div class="panel-body">
					<form class="form-horizontal m-t-20"  role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/login"  target="_self">

						<div class="form-group ">
							<div class="col-xs-12">
								<input class="form-control" type="text" name="username" placeholder="用户名" required="">
							</div>
						</div>

						<div class="form-group">
							<div class="col-xs-12">
								<input class="form-control" type="password" name="password" placeholder="密码" required="">
							</div>
						</div>

						<div class="form-group ">
							<div class="col-xs-12">
								<div class="checkbox checkbox-primary">
									<input id="checkbox-signup" type="checkbox">
									<label for="checkbox-signup"> 记住我 </label>
								</div>

							</div>
						</div>

						<div class="form-group text-center m-t-40">
							<div class="col-xs-12">
								<button  class="btn btn-pink btn-block text-uppercase waves-effect waves-light" type="submit" >登 录</button>
								
				
           
							</div>
						</div>

				
								<script>
function login(){
	$.post('./php/Feiniao.php', { username:$('#username').val(),password:$('#password').val(),submit:$('#logindiv').val(),}, 
	function (text, status) { $("#logindiv").html(text) });

}
</script>
					</form>

				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 text-center">
					<p>
						还没有账户吗? <a href="<?php echo @__ROOT__;?>
/index.php?s=/Agent/Register/register.html" class="text-primary m-l-5"><b>点这里注册代理帐号</b></a>
					</p>
				</div>
			</div>

		</div>

		<script>
			var resizefunc = [];
		</script>

		<!-- jQuery  --> 
        <script src="../../../Agent/Public/index/csc/js/bootstrap.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/detect.js"></script>
        <script src="../../../Agent/Public/index/csc/js/fastclick.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.slimscroll.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.blockUI.js"></script>
        <script src="../../../Agent/Public/index/csc/js/waves.js"></script>
        <script src="../../../Agent/Public/index/csc/js/wow.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.nicescroll.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.scrollTo.min.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.core.js"></script>
        <script src="../../../Agent/Public/index/csc/js/jquery.app.js"></script>

	
</div>
</body>
</html>
<?php }} ?>