<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:19:05
         compiled from "/var/www/html/Agent/View/Index/index_v1.html" */ ?>
<?php /*%%SmartyHeaderCode:45752833257a5acdc46b5c7-73849051%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1d12f18cbb4248f4029ea9b5fe3d03d6d50e135' => 
    array (
      0 => '/var/www/html/Agent/View/Index/index_v1.html',
      1 => 1470650982,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '45752833257a5acdc46b5c7-73849051',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5acdc4dc68',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5acdc4dc68')) {function content_57a5acdc4dc68($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>快速操作</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<blockquote class="text-warning" style="font-size:24px">快速充值通道↓↓↓↓
</blockquote>
<form method="post" class="form-horizontal" action="<?php echo @__MODULE__;?>
/Fast/renewUser" TARGET="_self">
    <h3>账号流量充值</h3>
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>账号:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="iuser" value="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>流量（G）:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="text" class="form-control" name="maxll" value="0">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_email" class="col-xs-2 control-label"><h4>续期（天）:</h4></label>
        <div id="mg_email" class="col-xs-5">
            <input type="text" class="form-control" name="endtime" value="0">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">充值</button>
</form>
<form method="post" class="form-horizontal" action="<?php echo @__MODULE__;?>
/Fast/renewAgent" TARGET="_self">
    <h3>代理余额充值</h3>
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>代理账号:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="mg_name" value="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>金额:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="text" class="form-control" name="mg_money" value="0">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">充值</button>
</form>

</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>