<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 17:25:30
         compiled from "/var/www/html/Agent/View/Server/addition.html" */ ?>
<?php /*%%SmartyHeaderCode:213118012857a5b02f16a918-44241944%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3fdf12aebf0a4508ba1069d36546abd9afc2ff7' => 
    array (
      0 => '/var/www/html/Agent/View/Server/addition.html',
      1 => 1470647294,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '213118012857a5b02f16a918-44241944',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5b02f1d100',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5b02f1d100')) {function content_57a5b02f1d100($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>服务器修改</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<ol class="breadcrumb">
    <li><a href="<?php echo @__MODULE__;?>
/agent/index" target="_self">服务器管理</a></li>
    <li class="active">添加服务器</li>
</ol>
<a href="<?php echo @__MODULE__;?>
/server/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

<form method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/addition" TARGET="_self">
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>服务器名:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="s_name" value="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>服务器ip:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="text" class="form-control" name="s_ip" placeholder="改了端口带上端口">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">提交</button>
</form>
<h3>服务器ip为可以访问网站的ip!改了端口记得带上端口！</h3>
<h3>例如：119.29.150.103：666！</h3>


</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>