<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 19:32:14
         compiled from "/var/www/html/Agent/View/Register/register.html" */ ?>
<?php /*%%SmartyHeaderCode:165529758457a5bce8b7d527-06014309%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25b58f6ab87091b0634e0ee55432fba635b49ba1' => 
    array (
      0 => '/var/www/html/Agent/View/Register/register.html',
      1 => 1470650983,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '165529758457a5bce8b7d527-06014309',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5bce8c04c3',
  'variables' => 
  array (
    'err_info' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5bce8c04c3')) {function content_57a5bce8c04c3($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?php echo @PROGRAM_NAME;?>
 - 注册</title>
    <meta name="keywords" content="<?php echo @PROGRAM_NAME;?>
 - 注册">
    <meta name="description" content="<?php echo @PROGRAM_NAME;?>
 - 注册">

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet"><base target="_blank">
    <script>if(window.top !== window.self){ window.top.location = window.location;}</script>

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name"></h1>

            </div>
            <h3>简约中创造出不简单！ </h3>
            <h3>代理注册</h3>
            <p>创建一个vpn新时代</p>
            <form class="m-t" role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/register" target="_self">
                <div class="form-group">
                    <input type="text" name="mg_name" class="form-control" placeholder="请输入用户名" required="">
                </div>
                <span style=" color: red"><?php echo $_smarty_tpl->tpl_vars['err_info']->value['mg_name'];?>
</span>
                <div class="form-group">
                    <input type="password" name="mg_pwd" class="form-control" placeholder="请输入密码" required="">
                </div>
                <span style=" color: red"><?php echo $_smarty_tpl->tpl_vars['err_info']->value['mg_pwd'];?>
</span>
                <div class="form-group">
                    <input type="password" name="mg_pwd1" class="form-control" placeholder="请再次输入密码" required="">
                </div>
                <div class="form-group">
                    <span style="color: red"><?php echo $_smarty_tpl->tpl_vars['err_info']->value['mg_pwd1'];?>
</span>
                    <input type="email" name="mg_email" class="form-control" placeholder="邮箱" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">注 册</button>

                <p class="text-muted text-center"><small>已经有账户了？</small><a href="<?php echo @__MODULE__;?>
/login/login" target="_self">点此登录</a>
                </p>

            </form>
        </div>
    </div>
    <script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
    <script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
    <script src="<?php echo @JS_URL;?>
plugins/iCheck/icheck.min.js"></script>
    <script>
        $(document).ready(function(){
            $(".i-checks").iCheck({ checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",
            )});
    </script>
    <script type="text/javascript" src="http://tajs.qq.com/stats?sId=9051096" charset="UTF-8"></script>
</body>

</html><?php }} ?>