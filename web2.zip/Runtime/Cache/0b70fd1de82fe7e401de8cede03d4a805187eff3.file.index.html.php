<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 22:37:04
         compiled from "/var/www/html/Agent/View/Index/index.html" */ ?>
<?php /*%%SmartyHeaderCode:18563660457a5acda51bc18-55980767%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b70fd1de82fe7e401de8cede03d4a805187eff3' => 
    array (
      0 => '/var/www/html/Agent/View/Index/index.html',
      1 => 1470667004,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18563660457a5acda51bc18-55980767',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5acda6ce3b',
  'variables' => 
  array (
    'admin_name' => 0,
    'admin_id' => 0,
    'c_l_name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5acda6ce3b')) {function content_57a5acda6ce3b($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <title>Ade VPN流量监控系统</title>

    <meta name="keywords" content="Ade VPN流量监控系统">
    <meta name="description" content="Ade VPN流量监控系统，界面上使用Bootstrap3框架开发，采用了主流的左右两栏式布局，使用了Html5+CSS3等现代技术，程序使用PHP+mysql开发">

    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->

    <!--<link rel="shortcut icon" href="tu.ico">-->
    <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
</head>

<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
<div id="wrapper">
    <!--左侧导航开始-->
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="nav-close"><i class="fa fa-times-circle"></i>
        </div>
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <span><img alt="image" class="img-circle" src="<?php echo @IMG_URL;?>
profile_small.jpg" /></span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear">
                               <span class="block m-t-xs"><strong class="font-bold"><?php echo $_smarty_tpl->tpl_vars['admin_name']->value;?>
</strong></span>
                                <span class="text-muted text-xs block">超级管理员<b class="caret"></b></span>
                                </span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a class="J_menuItem" href="">修改头像</a>
                            </li>
                            <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/info/upd">个人资料</a>
                            </li>
                            <li><a href="<?php echo @__CONTROLLER__;?>
/logout">安全退出</a>
                            </li>
                        </ul>
                    </div>
                    <div class="logo-element">sy
                    </div>
                </li>
                <?php if ($_smarty_tpl->tpl_vars['admin_id']->value==1){?>
                <li>
                    <a href="#">
                        <i class="fa fa-home"></i>
                        <span class="nav-label">超级管理员</span>
                        <span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/server/index">多服务器</a>
                        </li>
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/shop/index">商城管理</a>
                        </li>
                        <li>
                            <a href="#">商城中心 <span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/buy/index">账号中心</a>
                                </li>
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/buy/k_index">卡密中心</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/agent/index">代理管理</a>
                        </li>

                        <li>
                            <a href="#">用户管理 <span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/user/index">所有用户</a>
                                </li>
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/user/online">在线用户</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/key/index">余额卡密</a>
                        </li>
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/usage/index">流量卡密</a>
                        </li>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/upinfo/index">代理升级</a>
                        </li>
                        <li>
                            <a class="J_menuItem" href="<?php echo @__MODULE__;?>
/log/index">操作记录</a>
                        </li>

                    </ul>

                </li>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>
                <li>
                    <a href="#"><i class="fa fa-desktop"></i> <span class="nav-label"><?php echo $_smarty_tpl->tpl_vars['c_l_name']->value;?>
</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="#">商城中心 <span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/buy/index">账号中心</a>
                                </li>
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/buy/k_index">卡密中心</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">用户管理 <span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/user/index">所有用户</a>
                                </li>
                                <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/user/online">在线用户</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/key/usekey">余额充值</a>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/usage/index">流量卡密</a>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/log/index">操作记录</a>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/upinfo/index">代理升级</a>
                        </li>
                    </ul>
                </li>
                <?php }?>
                <li>
                    <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">个人中心 </span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/info/index">查看资料</a>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__MODULE__;?>
/info/upd">修改资料</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">使用教程</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a class="J_menuItem" href="<?php echo @__CONTROLLER__;?>
/help.html">使用教程</a>
                        </li>
                        <li><a class="J_menuItem" href="<?php echo @__CONTROLLER__;?>
/about.html">关于我们</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </nav>
    <!--左侧导航结束-->
    <!--右侧部分开始-->
    <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header"><a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                    <form role="search" class="navbar-form-custom" action="">
                        <div class="form-group">
                            <h2>功能面板</h2>
                        </div>
                    </form>
                </div>
                <ul class="nav navbar-top-links navbar-right">
                    <li><li class="J_tabCloseAll"><a>更新缓存</a></li>
                    <li class="dropdown hidden-xs">
                        <a class="right-sidebar-toggle" aria-expanded="false">
                            <i class="fa fa-tasks"></i> 主题
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="row content-tabs">
            <button class="roll-nav roll-left J_tabLeft"><i class="fa fa-backward"></i>
            </button>
            <nav class="page-tabs J_menuTabs">
                <div class="page-tabs-content">
                    <a href="javascript:;" class="active J_menuTab" data-id="index_v1.html">后台首页</a>
                </div>
            </nav>
            <button class="roll-nav roll-right J_tabRight"><i class="fa fa-forward"></i>
            </button>
            <div class="btn-group roll-nav roll-right">
                <button class="dropdown J_tabClose" data-toggle="dropdown">关闭操作<span class="caret"></span>

                </button>
                <ul role="menu" class="dropdown-menu dropdown-menu-right">
                    <li class="J_tabShowActive"><a>定位当前选项卡</a>
                    </li>
                    <li class="divider"></li>
                    <li class="J_tabCloseAll"><a>关闭全部选项卡</a>
                    </li>
                    <li class="J_tabCloseOther"><a>关闭其他选项卡</a>
                    </li>
                </ul>
            </div>
            <a href="<?php echo @__CONTROLLER__;?>
/logout" class="roll-nav roll-right J_tabExit"><i class="fa fa fa-sign-out"></i> 退出</a>
        </div>
        <div class="row J_mainContent" id="content-main">
            <iframe class="J_iframe" name="iframe0" width="100%" height="100%" src="<?php echo @__CONTROLLER__;?>
/<?php if ($_smarty_tpl->tpl_vars['admin_id']->value==1){?>index_v1.html<?php }?><?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>index_v2.html<?php }?>" frameborder="0" data-id="index_v1.html" seamless></iframe>
        </div>
        <div class="footer">
            <div class="pull-right">&copy; 2016 By Ade
            </div>
        </div>
    </div>
    <!--右侧部分结束-->
    <!--右侧边栏开始-->
    <div id="right-sidebar">
        <div class="sidebar-container">

            <ul class="nav nav-tabs navs-3">

                <li class="active">
                    <a data-toggle="tab" href="#tab-1">
                        <i class="fa fa-gear"></i> 主题
                    </a>
                </li>
            </ul>

            <div class="tab-content">
                <div id="tab-1" class="tab-pane active">
                    <div class="sidebar-title">
                        <h3> <i class="fa fa-comments-o"></i> 主题设置</h3>
                        <small><i class="fa fa-tim"></i> 你可以从这里选择和预览主题的布局和样式，这些设置会被保存在本地，下次打开的时候会直接应用这些设置。</small>
                    </div>
                    <div class="skin-setttings">
                        <div class="title">主题设置</div>
                        <div class="setings-item">
                            <span>收起左侧菜单</span>
                            <div class="switch">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="collapsemenu" class="onoffswitch-checkbox" id="collapsemenu">
                                    <label class="onoffswitch-label" for="collapsemenu">
                                        <span class="onoffswitch-inner"></span>
                                        <span class="onoffswitch-switch"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="setings-item">
                            <span>固定顶部</span>

                            <div class="switch">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="fixednavbar" class="onoffswitch-checkbox" id="fixednavbar">
                                    <label class="onoffswitch-label" for="fixednavbar">
                                        <span class="onoffswitch-inner"></span>
                                        <span class="onoffswitch-switch"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="setings-item">
                                <span>
                        固定宽度
                    </span>

                            <div class="switch">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="boxedlayout" class="onoffswitch-checkbox" id="boxedlayout">
                                    <label class="onoffswitch-label" for="boxedlayout">
                                        <span class="onoffswitch-inner"></span>
                                        <span class="onoffswitch-switch"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="title">皮肤选择</div>
                        <div class="setings-item default-skin nb">
                                <span class="skin-name ">
                         <a href="#" class="s-skin-0">
                             默认皮肤
                         </a>
                    </span>
                        </div>
                        <div class="setings-item blue-skin nb">
                                <span class="skin-name ">
                        <a href="#" class="s-skin-1">
                            蓝色主题
                        </a>
                    </span>
                        </div>
                        <div class="setings-item yellow-skin nb">
                                <span class="skin-name ">
                        <a href="#" class="s-skin-3">
                            黄色/紫色主题
                        </a>
                    </span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--右侧边栏结束-->

</div>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo @JS_URL;?>
plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
hplus.min.js"></script>
<script type="text/javascript" src="<?php echo @JS_URL;?>
contabs.min.js"></script>
<script src="<?php echo @JS_URL;?>
plugins/pace/pace.min.js"></script>
</body>

</html><?php }} ?>