<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 00:08:34
         compiled from "D:/projects/s17/Agent/View\Info\index.html" */ ?>
<?php /*%%SmartyHeaderCode:2722357a4ba02d88aa3-15900093%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'afccd502d2abe1f9704a4983cc1b2ec145f84581' => 
    array (
      0 => 'D:/projects/s17/Agent/View\\Info\\index.html',
      1 => 1469595823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2722357a4ba02d88aa3-15900093',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a4ba02e26d6',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a4ba02e26d6')) {function content_57a4ba02e26d6($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'D:\\projects\\s17\\ThinkPHP\\Library\\Vendor\\Smarty\\plugins\\modifier.date_format.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>资料管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">

            <div class="ibox-content">

                <table class="table">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>代理名</th>
                        <th class="hidden-xs">邮箱</th>
                        <th>注册时间</th>
                        <th>余额</th>
                        <th>等级</th>
                        <th>状态</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_id'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_name'];?>
</td>
                        <td class="hidden-xs"><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_email'];?>
</td>
                        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['mg_time'],"%y-%m-%d-%T");?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_money'];?>
</td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_id']==1){?>超级管理员<?php }elseif($_smarty_tpl->tpl_vars['v']->value['mg_level']==0){?>金牌代理<?php }?>
                            <?php if ($_smarty_tpl->tpl_vars['v']->value['mg_level']==1){?>钻石代理<?php }?>

                        </td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_state']==0){?>未激活<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_state']==1){?>正常<?php }?></td>
                    </tr>
                    </tbody>
                </table>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

            </div>

        <hr>

    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>