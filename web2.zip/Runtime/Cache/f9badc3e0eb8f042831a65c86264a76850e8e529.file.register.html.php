<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:10:07
         compiled from "/var/www/html/Home/View/Index/register.html" */ ?>
<?php /*%%SmartyHeaderCode:72339595357a5ab4540fd67-95256492%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f9badc3e0eb8f042831a65c86264a76850e8e529' => 
    array (
      0 => '/var/www/html/Home/View/Index/register.html',
      1 => 1470650988,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '72339595357a5ab4540fd67-95256492',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5ab45499bf',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5ab45499bf')) {function content_57a5ab45499bf($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">  
        <title><?php echo @PROGRAM_NAME;?>
 - 注册</title>
        <meta name="description" content="">
        <meta name="author" content="templatemo">
		<link rel="icon" href="/favi.ico" type="image/x-icon">
	    <link href='http://fonts.useso.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
	    <link href="../../../Agent/Public/index/css/reg/animate.min.css" rel="stylesheet">
	    <link href=".../../../Agent/Public/index/css/reg/bootstrap.min.css" rel="stylesheet">
	    <link href="../../../Agent/Public/index/css/reg/templatemo-style.css" rel="stylesheet">
	    
		<script type="text/javascript" src="../../../Agent/Public/index/css/reg/jquery.2.1.1.js"></script><script type="text/javascript" 

src="../../../Agent/Public/index/css/reg/jquery.form.js"></script><script type="text/javascript" src="../../../Agent/Public/index/css/reg/reg/AWS.js"></script><script type="text/javascript" 

src="../../../Agent/Public/index/css/reg/qzone.js"></script><script type="text/javascript" src="../../../Agent/Public/index/css/reg/plug-in_module.js"></script><!--[if lt IE 9]>
    <script src='../../../Agent/Public/index/css/reg/jquery.1.9.1.js'></script>
<![endif]-->
<!--[if gte IE 9]>
     <script src='.../../../Agent/Public/index/css/reg/jquery.2.1.1.js'></script>
<![endif]-->
	    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	    <!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	    <![endif]-->
	</head>

<body class="light-gray-bg">
 </br> </br> </br> </br></br>
		<div class="templatemo-content-widget templatemo-login-widget white-bg">
			<header class="text-center">
	          <div class="square"></div>
	          <h1>账号注册</h1>
	       </header>
	<form class="form-horizontal" role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/register" target="_self">
			<div class='input-group'><span class='input-group-addon'>账号</span>
			<input style="ime-mode:disabled;" type='text'name="iuser" value=''class='form-control'placeholder='请输入用户名'></div><BR/>
			<div class='input-group'><span class='input-group-addon'>密码</span>
			<input type='password'name="pass" value=''class='form-control'placeholder='请输入密码'></div><br/>
			<div class='input-group'><span class='input-group-addon'>密码</span>
			<input type='password'name="pass1" value=''class='form-control'placeholder='请再次输入密码'></div><br/>
			<div class='input-group'><span class='input-group-addon'>推荐人</span>
			<input type='password'name="dlid" value=''class='form-control'placeholder='推荐人id，没有则不填'></div><br/>
			<input type='text' name='uid'id='uid' value=''style="display:none" class='form-control'><br/>&nbsp;
			<center>  <button type="submit" class="btn btn-success btn_reg">》立即注册会员《</button></center></div>
		    <div class="templatemo-content-widget templatemo-login-widget templatemo-register-widget white-bg">
		    <p>注册成功? 已有账号?<strong><a href="<?php echo @__MODULE__;?>
/index/index" class="blue-text">点击登录</a></strong></p>
		</div>
	</form>		</body>

</html><?php }} ?>