<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 17:31:17
         compiled from "/var/www/html/Agent/View/Shop/z_addition.html" */ ?>
<?php /*%%SmartyHeaderCode:139295574857a5ae65762a71-20915640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a13f6b1f359d2c17a8ec2b8996780cf0ae4b9e71' => 
    array (
      0 => '/var/www/html/Agent/View/Shop/z_addition.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '139295574857a5ae65762a71-20915640',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5ae657fb73',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5ae657fb73')) {function content_57a5ae657fb73($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>账号商品添加</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<ol class="breadcrumb">
    <li><a href="<?php echo @__MODULE__;?>
/shop/index" target="_self">商城管理</a></li>
    <li class="active">添加账号商品</li>
</ol>
<a href="<?php echo @__MODULE__;?>
/shop/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

<form method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/z_addition" TARGET="_self">
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>用户名:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="iuser" value="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>密码:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="password" class="form-control" name="pass" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>天数:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="days" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>流量(G):</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="max" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>有效期（天）:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="endtime" placeholder="">
        </div>
    </div>
    <hr>
    <h3>代理价配置（元）</h3>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>一级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p1" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>二级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p2" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>三级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p3" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>四级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p4" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>五级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p5" placeholder="">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">提交</button>
</form>
<hr>
<div style="margin-left: 10%">
    <p>注意：天数为账号使用的天数！</p>
    <p>有效期即为该账号商品的有效期！</p>
    <p>包括代理价，都只输入纯数字！</p>
</div>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>