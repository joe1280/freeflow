<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 21:21:36
         compiled from "/var/www/html/Agent/View/Index/jian.html" */ ?>
<?php /*%%SmartyHeaderCode:158599156157a88637b6b469-21168623%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36527999549a9cda72d0939c1a0802532019b9ac' => 
    array (
      0 => '/var/www/html/Agent/View/Index/jian.html',
      1 => 1470662466,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158599156157a88637b6b469-21168623',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a88637bb5bf',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a88637bb5bf')) {function content_57a88637bb5bf($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>监控详情</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <blockquote class="text-warning" style="font-size:14px">
            <!--内容编辑开始    -->
<<?php ?>?php  
$myfile = fopen("../res/jiankong.log", "r") or die("Unable to open file!");
$hs = count(file('../res/jiankong.log'));
fgets($myfile);
fgets($myfile);
echo "<br>";
echo fgets($myfile);
echo "</br>";
for ($i = 0; $i < $hs ; $i++) {
	$jst = fgets($myfile);
	$bj = explode("年", $jst);
	if ($bj[0] >= 2016){
	echo "<br>";
		echo $jst;
	echo "</br>";
}
}
?<?php ?>>
            <!--内容编辑结束-->
        </blockquote>

        <hr>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>