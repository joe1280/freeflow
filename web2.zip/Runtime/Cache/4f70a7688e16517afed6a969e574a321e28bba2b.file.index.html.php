<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 00:04:31
         compiled from "D:/projects/s17/Agent/View\Usage\index.html" */ ?>
<?php /*%%SmartyHeaderCode:3067857a4b90f7c6c63-06509623%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4f70a7688e16517afed6a969e574a321e28bba2b' => 
    array (
      0 => 'D:/projects/s17/Agent/View\\Usage\\index.html',
      1 => 1469595825,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3067857a4b90f7c6c63-06509623',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'usage' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a4b90f8b9a3',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a4b90f8b9a3')) {function content_57a4b90f8b9a3($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'D:\\projects\\s17\\ThinkPHP\\Library\\Vendor\\Smarty\\plugins\\modifier.date_format.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>卡密管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>
<script src="<?php echo @JS_URL;?>
jquery.js"></script>
<script  src="<?php echo @JS_URL;?>
jquery.zclip.min.js"></script>
<script >
    $(function (){
        <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usage']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
        $('#copyBtn<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
').zclip({
            path: "<?php echo @JS_URL;?>
ZeroClipboard.swf",
            copy: function(){
                return $('#k_con<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
').val();
            }
        });
        <?php } ?>
        $('#copyBtnAll').zclip({
            path: "<?php echo @JS_URL;?>
ZeroClipboard.swf",
            copy: function(){
                return $('#kms').val();
            }
        });

    })

</script>
<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <form style="margin-left: 5%" method="post" class="form-inline" action="<?php echo @__MODULE__;?>
/Search/usage" target="_self">
            <div class="form-group">
                <div id="mg_name" class="col-xs-5">
                    <input type="text" class="form-control" name="name" value="" placeholder="搜索卡密">
                </div>
            </div>
            <button type="submit"  class="btn btn-primary ">搜索</button>
        </form>
        <div class="ibox-content">
            <table class="table">
                <thead>
                <tr>
                    <th>id</th>
                    <th>卡密</th>
                    <th>流量</th>
                    <th>天数</th>
                    <th class="hidden-xs">时间</th>
                    <th>状态</th>
                    <th>使用者</th>
                    <th>操作</th>
                    <th>复制</th>
                </tr>
                </thead>
                <tbody id="km">
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usage']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                <tr >
                    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
</td>
                    <td ><?php echo $_smarty_tpl->tpl_vars['v']->value['u_number'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['u_max'];?>
M</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['u_day'];?>
</td>
                    <td class="hidden-xs"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['u_time'],"%y-%m-%d-%T");?>
</td>
                    <td><?php if ($_smarty_tpl->tpl_vars['v']->value['u_state']==0){?>未使用<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['u_state']==1){?>已使用<?php }?></td>
                    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</td>
                    <td><a href="<?php echo @__CONTROLLER__;?>
/del/u_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
" target="_self" onclick="return confirm('您真的要删除该条记录吗？')">删除</a> </td>
                    <td><div style="position: relative;"><button id="copyBtn<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
"  class="btn btn-primary " >复制</button></div></td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
            <input type="hidden" id="kms" value="<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usage']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>卡密<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_number'];?>
，流量：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_max'];?>
M，天数：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_day'];?>

<?php } ?>">
            <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usage']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?><input type="hidden" id="k_con<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
" value="卡密<?php echo $_smarty_tpl->tpl_vars['v']->value['u_id'];?>
：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_number'];?>
，流量：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_max'];?>
M，天数：<?php echo $_smarty_tpl->tpl_vars['v']->value['u_day'];?>
"><?php } ?>
            <button id="copyBtnAll" class="btn btn-primary ">复制全部</button><br>
            <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>



        </div>
        </div>

        <hr>

    </div>
</div>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>