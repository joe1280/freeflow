<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:39:41
         compiled from "/var/www/html/Agent/View/User/online.html" */ ?>
<?php /*%%SmartyHeaderCode:102169414557a5b0b8841df9-97435264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3a3ba911bcc7f8ce8be87b10e782967b672edcc' => 
    array (
      0 => '/var/www/html/Agent/View/User/online.html',
      1 => 1470650986,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '102169414557a5b0b8841df9-97435264',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5b0b8934f3',
  'variables' => 
  array (
    'Users' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5b0b8934f3')) {function content_57a5b0b8934f3($_smarty_tpl) {?><?php if (!is_callable('smarty_function_math')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/function.math.php';
if (!is_callable('smarty_modifier_date_format')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/modifier.date_format.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>代理管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">

            <div class="table-responsive">
                <a href="<?php echo @__CONTROLLER__;?>
/index" class="btn btn-primary btn-sm active pull-left" role="button" target="_self">所有用户</a>
                <a href="<?php echo @__CONTROLLER__;?>
/batdel" class="btn btn-primary btn-sm active pull-right" role="button" target="_self">批量删除</a>
                <a href="<?php echo @__CONTROLLER__;?>
/batadd" class="btn btn-primary btn-sm active pull-right" role="button" target="_self">批量添加</a>
                <a href="<?php echo @__CONTROLLER__;?>
/addition" class="btn btn-primary btn-sm active pull-right" role="button" target="_self">添加用户</a>
                <table class="table">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>用户名</th>
                        <th>密码</th>
                        <th class="visible-md visible-lg">上传</th>
                        <th class="visible-md visible-lg">下载</th>
                        <th>已用</th>
                        <th>剩余</th>
                        <th>总量</th>
                        <th>状态</th>
                        <th class="visible-md visible-lg">开通日期</th>
                        <th>过期日期</th>
                        <th colspan="2">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['Users']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['iuser'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['pass'];?>
</td>
                        <td class="visible-md visible-lg"><?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['v']->value['isent'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M</td>
                        <td class="visible-md visible-lg"><?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['v']->value['irecv'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M</td>
                        <td><?php echo smarty_function_math(array('equation'=>"x/1024/1024 + y/1024/1024",'x'=>$_smarty_tpl->tpl_vars['v']->value['irecv'],'y'=>$_smarty_tpl->tpl_vars['v']->value['isent'],'format'=>"%.2f"),$_smarty_tpl);?>
M</td>
                        <td><?php echo smarty_function_math(array('equation'=>"z/1024/1024-(x/1024/1024 + y/1024/1024)",'x'=>$_smarty_tpl->tpl_vars['v']->value['irecv'],'y'=>$_smarty_tpl->tpl_vars['v']->value['isent'],'z'=>$_smarty_tpl->tpl_vars['v']->value['maxll'],'format'=>"%.2f"),$_smarty_tpl);?>
M</td>
                        <td><?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['v']->value['maxll'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M</td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['i']==0){?>锁定<?php }?><?php if ($_smarty_tpl->tpl_vars['v']->value['i']==1){?>正常<?php }?></td>
                        <td class="visible-md visible-lg"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['starttime'],"%y-%m-%d");?>
</td>
                        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['endtime'],"%y-%m-%d");?>
</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/upd/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
" target="_self">修改</a> </td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/del/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
" target="_self" onclick="return confirm('您真的要删除该条记录吗？')">删除</a> </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                </table>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

            </div>

        <hr>

</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>