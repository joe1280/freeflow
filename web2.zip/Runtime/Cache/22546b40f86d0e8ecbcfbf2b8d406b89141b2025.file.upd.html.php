<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 17:30:22
         compiled from "/var/www/html/Agent/View/User/upd.html" */ ?>
<?php /*%%SmartyHeaderCode:21135344257a5bb19239572-48480021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22546b40f86d0e8ecbcfbf2b8d406b89141b2025' => 
    array (
      0 => '/var/www/html/Agent/View/User/upd.html',
      1 => 1470647294,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21135344257a5bb19239572-48480021',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5bb1933395',
  'variables' => 
  array (
    'User_info' => 0,
    'admin_id' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5bb1933395')) {function content_57a5bb1933395($_smarty_tpl) {?><?php if (!is_callable('smarty_function_math')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/function.math.php';
if (!is_callable('smarty_modifier_date_format')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/modifier.date_format.php';
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>用户修改</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
        <ol class="breadcrumb">
            <li><a href="<?php echo @__MODULE__;?>
/user/index" target="_self">用户管理</a></li>
            <li class="active">修改用户</li>
        </ol>
        <a href="<?php echo @__MODULE__;?>
/user/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

        <form method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/upd" TARGET="_self">
            <div class="form-group">
            <label for="mg_name" class="col-sm-4"><h4>用户名:</h4></label>
            <div id="mg_name" class="form-control col-sm-8">
                <input type="text" class="form-control"  value="<?php echo $_smarty_tpl->tpl_vars['User_info']->value['iuser'];?>
" disabled="disabled">
            </div>
            </div>
            <div class="form-group">
            <label for="mg_pwd" class="col-sm-4"><h4>密码:</h4></label>
            <div id="mg_pwd" class="form-control col-sm-8">
                <input type="password" class="form-control" name="pass" placeholder="不填默认不修改！">
            </div>
            </div>
            <div class="form-group">
            <label for="isent" class="col-sm-4"><h4>上传:</h4></label>
            <div id="isent" class="form-control col-sm-8">
                <input type="text" class="form-control" name="isent" <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>disabled="disabled"<?php }?> value="<?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['User_info']->value['isent'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M">
            </div>
            </div>

            <div class="form-group">
                <label for="irecv" class="col-sm-4"><h4>下载:</h4></label>
                <div id="irecv" class="form-control col-sm-8">
                    <input type="text" class="form-control" name="irecv" <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>disabled="disabled"<?php }?> value="<?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['User_info']->value['irecv'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M">
                </div>
            </div>


            <div class="form-group">
                <label for="maxll" class="col-sm-4"><h4>总量:</h4></label>
                <div id="maxll" class="form-control col-sm-8">
                    <input type="text" class="form-control" name="maxll" id="maxll" <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>disabled="disabled"<?php }?> value="<?php echo smarty_function_math(array('equation'=>"x / y / y",'x'=>$_smarty_tpl->tpl_vars['User_info']->value['maxll'],'y'=>1024,'format'=>"%.2f"),$_smarty_tpl);?>
M">
                </div>
            </div>

            <div class="form-group">
                <label for="starttime" class="col-sm-1"><h4>开通日期:</h4></label>
                <input type="text" class="form-control" name="starttime" id="starttime" <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>disabled="disabled"<?php }?> value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['User_info']->value['starttime'],"%y-%m-%d %T");?>
">
            </div>
            <div class="form-group">
                <label for="endtime" class="col-sm-1"><h4>结束日期:</h4></label>
                <input type="text" class="form-control" name="endtime" id="endtime" <?php if ($_smarty_tpl->tpl_vars['admin_id']->value!=1){?>disabled="disabled"<?php }?> value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['User_info']->value['endtime'],'%y-%m-%d %T');?>
">
            </div>

            <div class="form-group">
                <label for="i" class="col-sm-1"><h4>账号状态:</h4></label>
                <select id="i" name="i" class="form-controller">
                    <option value="0" <?php if ($_smarty_tpl->tpl_vars['User_info']->value['i']==0){?>selected="selected"<?php }?>>未激活</option>
                    <option value="1" <?php if ($_smarty_tpl->tpl_vars['User_info']->value['i']==1){?>selected="selected"<?php }?>>正常</option>
                </select>
            </div>
            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['User_info']->value['id'];?>
">
            <button type="submit" class="btn btn-primary">提交</button>
        </form>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>