<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:39:43
         compiled from "/var/www/html/Agent/View/Upinfo/index.html" */ ?>
<?php /*%%SmartyHeaderCode:156844994057a5fcf01848f5-08134835%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e00584e4dd028a366d02f5f20f0ba24d77e8f20a' => 
    array (
      0 => '/var/www/html/Agent/View/Upinfo/index.html',
      1 => 1470650985,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '156844994057a5fcf01848f5-08134835',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5fcf02231d',
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5fcf02231d')) {function content_57a5fcf02231d($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>代理升级</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<h3>账户余额：<span style="color:red;"><?php echo $_SESSION['money'];?>
</span>元</h3>
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">
                <table class="table">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>代理名</th>
                        <th>价格</th>
                        <th colspan="2">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['c_id'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['c_l_name'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['c_p'];?>
</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/isup/c_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['c_id'];?>
" target="_self">立刻升级</a> </td>
                        <?php if ($_SESSION['admin_id']==1){?><td><a href="<?php echo @__CONTROLLER__;?>
/upd/c_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['c_id'];?>
" target="_self">修改</a> </td><?php }?>
                        <?php if ($_SESSION['admin_id']==1){?><td><a href="<?php echo @__CONTROLLER__;?>
/del/c_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['c_id'];?>
" target="_self" onclick="return confirm('您真的要停用吗？（不可恢复哦！）')">停用</a> </td><?php }?>
                    </tr>
                    <?php } ?>
                    </tbody>
                </table>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>


            </div>

        <hr>
        </div>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>