<?php /* Smarty version Smarty-3.1.6, created on 2016-08-07 08:28:36
         compiled from "/var/www/html/Agent/View/Agent/upd.html" */ ?>
<?php /*%%SmartyHeaderCode:196095782857a680b4010df9-91617037%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '400291df5e8479d526d04082a662d689c7f0f280' => 
    array (
      0 => '/var/www/html/Agent/View/Agent/upd.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '196095782857a680b4010df9-91617037',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'agent_info' => 0,
    'charges' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a680b40cc10',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a680b40cc10')) {function content_57a680b40cc10($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>代理修改</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
        <ol class="breadcrumb">
            <li><a href="<?php echo @__MODULE__;?>
/agent/index" target="_self">代理管理</a></li>
            <li class="active">修改代理</li>
        </ol>
        <a href="<?php echo @__MODULE__;?>
/agent/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

        <form style="margin-left: 20%" method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/upd" TARGET="_self">
            <div class="form-group">
            <label for="mg_name" class="col-xs-2 control-label"><h4>用户名:</h4></label>
            <div id="mg_name" class="col-xs-5">
                <input type="text" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_name'];?>
" disabled="disabled">
            </div>
            </div>
            <div class="form-group">
            <label for="mg_pwd" class="col-xs-2 control-label"><h4>密码:</h4></label>
            <div id="mg_pwd" class="col-xs-5">
                <input type="password" class="form-control" name="mg_pwd" placeholder="不填默认不修改！">
            </div>
            </div>
            <div class="form-group">
            <label for="mg_email" class="col-xs-2 control-label"><h4>邮箱:</h4></label>
            <div id="mg_email" class="col-xs-5">
                <input type="text" class="form-control" name="mg_email" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_email'];?>
">
            </div>
            </div>


            <div class="form-group">
                <label for="mg_money" class="col-xs-2 control-label"><h4>余额:</h4></label>
                <div id="mg_money" class="col-xs-5">
                    <input type="text" class="form-control" name="mg_money" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_money'];?>
">
                </div>
            </div>

            <div class="form-group">
                <label for="mg_level" class="col-xs-2 control-label"><h4>代理等级:</h4></label>
                <select id="mg_level" name="mg_level" class="form-controller">
                <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['charges']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['c_mg_level'];?>
"
                            <?php if ($_smarty_tpl->tpl_vars['v']->value['c_mg_level']==$_smarty_tpl->tpl_vars['agent_info']->value['mg_level']){?> selected="selected" <?php }?> ><?php echo $_smarty_tpl->tpl_vars['v']->value['c_l_name'];?>
</option>
                    <?php } ?>
                </select>
            </div>


            <div class="form-group">
                <label for="mg_state" class="col-xs-2 control-label"><h4>账号状态:</h4></label>
                <select id="mg_state" name="mg_state" class="form-controller">
                    <option value="0" <?php if ($_smarty_tpl->tpl_vars['agent_info']->value['mg_state']==0){?>selected="selected"<?php }?>>未激活</option>
                    <option value="1" <?php if ($_smarty_tpl->tpl_vars['agent_info']->value['mg_state']==1){?>selected="selected"<?php }?>>正常</option>
                </select>
            </div>

            <input type="hidden" name="mg_id" value="<?php echo $_smarty_tpl->tpl_vars['agent_info']->value['mg_id'];?>
">
            <button type="submit" style="margin-left: 20%" class="btn btn-primary">提交</button>
        </form>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>