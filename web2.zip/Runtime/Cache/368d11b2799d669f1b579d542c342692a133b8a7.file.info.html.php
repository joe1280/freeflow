<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 20:04:55
         compiled from "/var/www/html/Agent/View/Server/info.html" */ ?>
<?php /*%%SmartyHeaderCode:33417210457a5dbfe496b33-26929445%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '368d11b2799d669f1b579d542c342692a133b8a7' => 
    array (
      0 => '/var/www/html/Agent/View/Server/info.html',
      1 => 1470650984,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33417210457a5dbfe496b33-26929445',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5dbfe5340c',
  'variables' => 
  array (
    'o_num' => 0,
    'i' => 0,
    'name' => 0,
    's' => 0,
    'r' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5dbfe5340c')) {function content_57a5dbfe5340c($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>服务器管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<a href="<?php echo @__MODULE__;?>
/server/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">

                <table class="table">
                    <thead>
                    <tr>
                        <th>用户名</th>
                        <th>上传</th>
                        <th >下载</th>
                    </tr>
                    </thead>
                    <tbody>
                    <h3>服务器总在线<span style="color: red;"><?php echo $_smarty_tpl->tpl_vars['o_num']->value;?>
</span>人</h3>
                    <?php $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int)ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['o_num']->value+1 - (0) : 0-($_smarty_tpl->tpl_vars['o_num']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0){
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++){
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration == 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration == $_smarty_tpl->tpl_vars['i']->total;?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['name']->value[$_smarty_tpl->tpl_vars['i']->value];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['s']->value[$_smarty_tpl->tpl_vars['i']->value];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['r']->value[$_smarty_tpl->tpl_vars['i']->value];?>
</td>
                    </tr>
                    <?php }} ?>
                    </tbody>
                </table>

            </div>

        <hr>
        </div>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>