<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 21:44:00
         compiled from "/var/www/html/Agent/View/Index/index_v2.html" */ ?>
<?php /*%%SmartyHeaderCode:53150283057a5e9a044e929-94441397%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7399437074f460eeafa5199bcff8fa821881422d' => 
    array (
      0 => '/var/www/html/Agent/View/Index/index_v2.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '53150283057a5e9a044e929-94441397',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5e9a04b086',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5e9a04b086')) {function content_57a5e9a04b086($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>快速操作</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<blockquote class="text-warning" style="font-size:24px">快速充值通道↓↓↓↓
</blockquote>
<form method="post" class="form-horizontal" action="<?php echo @__MODULE__;?>
/usage/a_usekey" TARGET="_self">
    <h3>账号快速充值</h3>
    <div class="form-group">
        <label for="mg_name" class="col-xs-2 control-label"><h4>账号:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="name" value="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>卡密:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="text" class="form-control" name="u_number" placeholder="">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">充值</button>
</form>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>