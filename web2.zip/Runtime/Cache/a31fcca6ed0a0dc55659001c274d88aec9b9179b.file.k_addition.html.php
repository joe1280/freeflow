<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 20:10:55
         compiled from "/var/www/html/Agent/View/Shop/k_addition.html" */ ?>
<?php /*%%SmartyHeaderCode:131135066457a5d3cf203107-25529329%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a31fcca6ed0a0dc55659001c274d88aec9b9179b' => 
    array (
      0 => '/var/www/html/Agent/View/Shop/k_addition.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131135066457a5d3cf203107-25529329',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5d3cf30136',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5d3cf30136')) {function content_57a5d3cf30136($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>卡密商品添加</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<ol class="breadcrumb">
    <li><a href="<?php echo @__MODULE__;?>
/shop/k_index" target="_self">商城管理</a></li>
    <li class="active">添加卡密商品</li>
</ol>
<a href="<?php echo @__MODULE__;?>
/shop/k_index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

<form method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/k_addition" TARGET="_self">
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>天数:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="days" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>流量(G):</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="max" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>有效期（天）:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="endtime" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>张数:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="num" value="1">
        </div>
    </div>
    <hr>
    <h3>代理价配置（元）</h3>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>一级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p1" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>二级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p2" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>三级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p3" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>四级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p4" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="mg_pwd" class="col-xs-2 control-label"><h4>五级代理价:</h4></label>
        <div id="mg_pwd" class="col-xs-5">
            <input type="number" class="form-control" name="p5" placeholder="">
        </div>
    </div>
    <button style="margin-left: 20%" type="submit" class="btn btn-primary">提交</button>
</form>
<hr>
<div style="margin-left: 10%">
    <p>注意：天数为卡密使用的天数！</p>
    <p>有效期即为该卡密商品的有效期！</p>
    <p>包括代理价，都只输入纯数字！</p>
</div>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>