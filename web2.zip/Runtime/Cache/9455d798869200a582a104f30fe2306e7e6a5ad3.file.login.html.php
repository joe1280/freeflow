<?php /* Smarty version Smarty-3.1.6, created on 2016-08-06 00:03:42
         compiled from "D:/projects/s17/Agent/View\Login\login.html" */ ?>
<?php /*%%SmartyHeaderCode:83757a4b8de3114d0-87441574%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9455d798869200a582a104f30fe2306e7e6a5ad3' => 
    array (
      0 => 'D:/projects/s17/Agent/View\\Login\\login.html',
      1 => 1469595823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '83757a4b8de3114d0-87441574',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a4b8de37bf1',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a4b8de37bf1')) {function content_57a4b8de37bf1($_smarty_tpl) {?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?php echo @PROGRAM_NAME;?>
 - 登录</title>
    <meta name="keywords" content="<?php echo @PROGRAM_NAME;?>
 - 登录">
    <meta name="description" content="<?php echo @PROGRAM_NAME;?>
 - 登录">

    <!--<link rel="shortcut icon" href="favicon.ico"> -->
    <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet"><base target="_blank">
    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    <!--<script>if(window.top !== window.self){ window.top.location = window.location;}</script>-->
</head>

<body>
<div style="position:absolute; left:0; top:0; width:100%; height:100%"><img src="images/bg2.jpg" width=100% height=100%<?php ?>></div>

    <div class="middle-box text-center loginscreen  animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name"></h1>

            </div>
            <h3><font color=”#0000FF”>欢迎进入 云流量后台管理中心</font></h3>
            <h3><font color=”#0000FF”>请使用代理账户登录</font></h3>
            <form class="m-t" role="form" method="post" action="<?php echo @__CONTROLLER__;?>
/login"  target="_self">
                <div class="form-group">
                    <input type="text" name="username" class="form-control" placeholder="用户名" required="">
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="密码" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">登 录</button>


                <p class="text-muted text-center"> <a href="login.html#"><small></small></a><a href="<?php echo @__MODULE__;?>
/register/register"  target="_self"><font color=”#FFFFFF”>注册一个代理账号</font></a>
                </p>

            </form>
        </div>
    </div>
    <script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
    <script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
    <script type="text/javascript" src="http://tajs.qq.com/stats?sId=9051096" charset="UTF-8"></script>
</body>

</html><?php }} ?>