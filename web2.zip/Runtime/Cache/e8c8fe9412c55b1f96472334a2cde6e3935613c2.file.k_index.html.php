<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:39:39
         compiled from "/var/www/html/Agent/View/Buy/k_index.html" */ ?>
<?php /*%%SmartyHeaderCode:94391671857a5bbd9c2e5b0-64466640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e8c8fe9412c55b1f96472334a2cde6e3935613c2' => 
    array (
      0 => '/var/www/html/Agent/View/Buy/k_index.html',
      1 => 1470650980,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '94391671857a5bbd9c2e5b0-64466640',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5bbd9ccecb',
  'variables' => 
  array (
    'i' => 0,
    'j' => 0,
    'type' => 0,
    'sum' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5bbd9ccecb')) {function content_57a5bbd9ccecb($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>商城中心</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">
                <form style="margin-left: 5%" method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/k_search" target="_self">
                    <div class="form-group">
                        <div id="mg_name" class="col-xs-5">
                            <input type="text" class="form-control" name="name" value="" placeholder="搜索卡密商品">
                        </div>
                    </div>
                    <button type="submit"  class="btn btn-primary ">搜索</button>
                    <a href="<?php echo @__CONTROLLER__;?>
/index" class="btn btn-primary btn-sm active " role="button" target="_self" style="margin-left: 2%">账号中心</a>
                    <a href="<?php echo @__CONTROLLER__;?>
/k_index" class="btn btn-primary btn-sm active " role="button" target="_self" style="margin-left: 2%">卡密中心</a>
                </form>
                <hr>
                <span style="font-size: 20px">余额：<span style="color: red;"><?php echo $_SESSION['money'];?>
</span>元</span>
                <hr>
                <a href="<?php echo @__MODULE__;?>
/Buylog/k_log" class="btn btn-primary btn-sm active " role="button" target="_self">查看已购买</a>
                <a onclick="alert('请到余额充值中充值！')" class="btn btn-primary btn-sm active " role="button" target="_self">充值余额</a>
                <h3>卡密购买中心</h3>
                <table class="table">
                    <thead>
                    <tr>
                        <th>商品名</th>
                        <th >库存</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $_smarty_tpl->tpl_vars['j'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['j']->step = 1;$_smarty_tpl->tpl_vars['j']->total = (int)ceil(($_smarty_tpl->tpl_vars['j']->step > 0 ? $_smarty_tpl->tpl_vars['i']->value+1 - (0) : 0-($_smarty_tpl->tpl_vars['i']->value)+1)/abs($_smarty_tpl->tpl_vars['j']->step));
if ($_smarty_tpl->tpl_vars['j']->total > 0){
for ($_smarty_tpl->tpl_vars['j']->value = 0, $_smarty_tpl->tpl_vars['j']->iteration = 1;$_smarty_tpl->tpl_vars['j']->iteration <= $_smarty_tpl->tpl_vars['j']->total;$_smarty_tpl->tpl_vars['j']->value += $_smarty_tpl->tpl_vars['j']->step, $_smarty_tpl->tpl_vars['j']->iteration++){
$_smarty_tpl->tpl_vars['j']->first = $_smarty_tpl->tpl_vars['j']->iteration == 1;$_smarty_tpl->tpl_vars['j']->last = $_smarty_tpl->tpl_vars['j']->iteration == $_smarty_tpl->tpl_vars['j']->total;?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['type']->value[$_smarty_tpl->tpl_vars['j']->value]['type'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['sum']->value[$_smarty_tpl->tpl_vars['j']->value];?>
</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/kk_index/type/<?php echo $_smarty_tpl->tpl_vars['type']->value[$_smarty_tpl->tpl_vars['j']->value]['type'];?>
" target="_self">我要购买</a></td>
                    </tr>
                    <?php }} ?>
                    </tbody>
                </table>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>


            </div>

        <hr>
        </div>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>