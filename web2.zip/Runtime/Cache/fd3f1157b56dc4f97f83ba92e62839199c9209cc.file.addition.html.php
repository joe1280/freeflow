<?php /* Smarty version Smarty-3.1.6, created on 2016-08-07 14:41:00
         compiled from "/var/www/html/Agent/View/Key/addition.html" */ ?>
<?php /*%%SmartyHeaderCode:48819133257a6d7fcf36467-92040645%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fd3f1157b56dc4f97f83ba92e62839199c9209cc' => 
    array (
      0 => '/var/www/html/Agent/View/Key/addition.html',
      1 => 1470471058,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '48819133257a6d7fcf36467-92040645',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a6d7fd09a3d',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a6d7fd09a3d')) {function content_57a6d7fd09a3d($_smarty_tpl) {?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>卡密添加</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css?v=4.0.0" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<ol class="breadcrumb">
    <li><a href="<?php echo @__MODULE__;?>
/key/index" target="_self">卡密管理</a></li>
    <li class="active">添加卡密</li>
</ol>
<a href="<?php echo @__MODULE__;?>
/key/index" target="_self" class="btn btn-info btn-sm active pull-right" role="button">返回</a>

<form style="margin-left: 20%" method="post" class="form-horizontal" action="<?php echo @__CONTROLLER__;?>
/addition" TARGET="_self">
    <br>
    <div class="form-group">
        <label for="mg_name" class="col-xs-4 control-label"><h4>面额:</h4></label>
        <div id="mg_name" class="col-xs-5">
            <input type="text" class="form-control" name="k_money" value="">
        </div>
    </div>

    <div class="form-group">
        <label for="mg_email" class="col-xs-4 control-label"><h4>张数:</h4></label>
        <div id="mg_email" class="col-xs-5">
            <input type="text" class="form-control" name="k_num"  placeholder="不要超过100张！">
        </div>
    </div>

    <button style="margin-left: 20%" type="submit" class="btn btn-primary">提交</button>
</form>



</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>