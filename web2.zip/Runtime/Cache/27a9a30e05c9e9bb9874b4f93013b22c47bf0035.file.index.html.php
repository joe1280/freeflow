<?php /* Smarty version Smarty-3.1.6, created on 2016-08-08 18:38:00
         compiled from "/var/www/html/Agent/View/Agent/index.html" */ ?>
<?php /*%%SmartyHeaderCode:43468014857a5af9bc8cfb9-69822994%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '27a9a30e05c9e9bb9874b4f93013b22c47bf0035' => 
    array (
      0 => '/var/www/html/Agent/View/Agent/index.html',
      1 => 1470650980,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '43468014857a5af9bc8cfb9-69822994',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_57a5af9bd68a3',
  'variables' => 
  array (
    'agents' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a5af9bd68a3')) {function content_57a5af9bd68a3($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/var/www/html/ThinkPHP/Library/Vendor/Smarty/plugins/modifier.date_format.php';
?>﻿<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--360浏览器优先以webkit内核解析-->


    <title>代理管理</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="<?php echo @CSS_URL;?>
bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo @CSS_URL;?>
animate.min.css" rel="stylesheet">
    <link href="<?php echo @CSS_URL;?>
style.min.css" rel="stylesheet">
    <base target="_blank">

</head>

<body class="gray-bg">
<div class="row  border-bottom white-bg dashboard-header">
    <div class="col-sm-12">
        <div class="table-responsive">
            <div class="ibox-content">
                <form style="margin-left: 5%" method="post" class="form-inline" action="<?php echo @__CONTROLLER__;?>
/search" target="_self">
                    <div class="form-group">
                        <div id="mg_name" class="col-xs-5">
                            <input type="text" class="form-control" name="name" value="" placeholder="搜索代理">
                        </div>
                    </div>
                    <button type="submit"  class="btn btn-primary ">搜索</button>
                </form>
                <a href="<?php echo @__CONTROLLER__;?>
/addition" class="btn btn-primary btn-sm active " role="button" target="_self">添加代理</a>
                <table class="table">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>代理名</th>
                        <th class="hidden-xs">邮箱</th>
                        <th>注册时间</th>
                        <th class="visible-lg">角色</th>
                        <th>余额</th>
                        <th>状态</th>
                        <th>等级</th>

                        <th colspan="2">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['agents']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_id'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_name'];?>
</td>
                        <td class="hidden-xs"><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_email'];?>
</td>
                        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['mg_time'],"%y-%m-%d-%T");?>
</td>
                        <td class="visible-lg"><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_id']==1){?>管理<?php }elseif($_smarty_tpl->tpl_vars['v']->value['mg_role_id']==0){?>代理<?php }?></td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['mg_money'];?>
</td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_state']==0){?>未激活<?php }elseif($_smarty_tpl->tpl_vars['v']->value['mg_state']==1){?>正常<?php }?></td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_id']!=1){?><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
<?php }elseif($_smarty_tpl->tpl_vars['v']->value['mg_id']==1){?>超级管理员<?php }?></td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/upd/mg_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['mg_id'];?>
" target="_self">修改</a> </td>
                        <td><?php if ($_smarty_tpl->tpl_vars['v']->value['mg_id']!=1){?><a href="<?php echo @__CONTROLLER__;?>
/del/mg_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['mg_id'];?>
" target="_self" onclick="return confirm('您真的要删除该条记录吗？')">删除</a><?php }?> </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                </table>
                <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>


            </div>
 <font color="#FF0000"></a>温馨提示：超级管理员代理账户为admin，此账户请勿删除，超级管理员需要在商城中心购买商品需</br>要修改admin账户余额，另代理余额建议设置在一百万以下，设置过大会导致代理账户在购买商品时</br>出现扣费失败！</a>
        <hr>
        </div>
    </div>
</div>
</script>
<script src="<?php echo @JS_URL;?>
jquery.min.js?v=2.1.4"></script>
<script src="<?php echo @JS_URL;?>
bootstrap.min.js?v=3.3.5"></script>
<script src="<?php echo @JS_URL;?>
plugins/layer/layer.min.js"></script>
<script src="<?php echo @JS_URL;?>
content.min.js"></script>
<script src="<?php echo @JS_URL;?>
welcome.min.js"></script>
</body>

</html><?php }} ?>