<?php
return array(
	//'配置项'=>'配置值'
    //开启smarty模板引擎
    'TMPL_ENGINE_TYPE'=>'Smarty',
	'URL_MODEL'=>'3',
    //默认访问
    'MODULE_ALLOW_LIST'=>array(
        'home','admin','agent'
    ),
    //数据库相关配置
    'DB_TYPE'               =>  'mysql',     // 数据库类型
	//用户常用配置开始处
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  'ov',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  'root',          // 密码
	//用户常用配置结束处
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'jk_',    // 数据库表前缀
    'DB_PARAMS'          	=>  array(), // 数据库连接参数
    'DB_DEBUG'  			=>  TRUE, // 数据库调试模式 开启后可以记录SQL日志
    'DB_FIELDS_CACHE'       =>  true,        // 启用字段缓存
    'DB_CHARSET'            =>  'utf8',      // 数据库编码默认采用utf8
    //前台注册账号配置
    'RE_STATE'              =>  '1'  ,     //配置为1表示正常，配置为0表示未激活
    'RE_GIFT'              =>  '0'  ,     //注册赠送50M流量
    'RE_GIFT_DAYS'              =>  '0'  ,     //体验天数
);