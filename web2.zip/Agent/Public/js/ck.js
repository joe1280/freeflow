    window.onload = function () {
        var list=document.getElementsByName("ck[]");
        var all=document.getElementById("all");
        var li=document.getElementById("list");
        var s=document.getElementById("show");
        var p=document.getElementsByName("p");
        var t=0;

       li.onclick = function () {
           var sum=0;
           for(var i=0;i<list.length;i++){
               if(list[i].checked == true){
                   sum = sum + parseInt(p[i].innerHTML);

               }
               
           }
           s.innerHTML = '总价'+sum+"元";
       }

        all.onclick = function () {
            if(t==0){
                for(var i=0;i<list.length;i++){
                    if(list[i].value!='0'){
                        list[i].checked = true;
                    }

                }
                t=1;
            }else{
                for(var i=0;i<list.length;i++){
                    list[i].checked = false;
                }
                t=0;
            }

        }

    }