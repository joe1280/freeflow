var AWS =
{
	//������ʾЧ��
	shake: function(selector)
	{
		var length = 6;
		selector.css('position', 'relative');
	    for (var i = 1; i <= length; i++)
	    {
	    	if (i % 2 == 0)
	    	{
	        	if (i == length)
	        	{
	        		selector.animate({ 'left': 0 }, 50);
	        	}
	        	else
	        	{
	        		selector.animate({ 'left': 10 }, 50);
	        	}
	    	}
	    	else
	    	{
	    		selector.animate({ 'left': -10 }, 50);
	    	}
	    }
	},
	ajax_post: function(formEl, processer, type) // ���������� jQuery ��ȡ���ص�������
	{
	    if (typeof (processer) != 'function')
	    {
	        var processer = AWS.ajax_processer;  
	    }

	    if (!type)
	    {
	    	var type = 'default';
	    }
	    else if (type == 'reply')
	    { 
	    	$('.btn-reply').addClass('disabled');
	    }

	    var custom_data = {
	        _post_type: 'ajax'
	    };

	    formEl.ajaxSubmit(
	    {
	        dataType: 'json',
	        data: custom_data,
	        success: function (result)
	        {
	        	processer(type, result);
	        },
	        error: function (error)
	        {
	            if ($.trim(error.responseText) != '')
	            { 
	                alert('��������, ���ص���Ϣ:'+ ' ' + error.responseText);
	            }
	        }
	    });
	}, 
	// ajax�ύcallback
	ajax_processer: function (type, result)
	{ 
		if (typeof (result.errno) == 'undefined')
		{
		alert(result);
		}else if(result.errno==2){
		    var server = Hogan.compile(AW_TEMPLATE.add_server).render({
						id:result.rsm.id,
						qqcount:result.rsm.qqcount  
			}) ;
			
		   $('#server_list').append('<span class="list-group-item" data-id="'+result.rsm.id+'"> ' + server + '</span>');
		   
		   $('html,body').animate({scrollTop:$("span[data-id=" + result.rsm.id + "]").offset().top},1000);
	       
	       $("span[data-id=" + result.rsm.id + "]").mouseout(function(){
            $(this).removeClass("danger");
           });
            $(".error_message em").html(result.err); 
		    post_error();
		}
		else if (result.errno != 1)
		{
			switch (type)
			{ 
				case 'ajax_post_alert':
				case 'ajax_post_modal':
				case 'ajax_post_qq':
				case 'error_message':
					if (!$('.'+type).length)
			    	{
				    	alert(result.err);
			    	}
			    	else if ($('.'+type+' em').length)
			    	{
				    	$('.'+type+' em').html(result.err);
			    	}
			    	else
			    	{
				    	 $('.'+type).html(result.err);
			    	}

			    	if ($('.'+type).css('display') != 'none')
			    	{
				    	AWS.shake($('.'+type));
			    	}
			    	else
			    	{
				    	$('.'+type).fadeIn();
			    	}

			    	if ($('#captcha').length)
			    	{
			    		$('#captcha').click();
			    	}
				break;
			}
		}
		else
		{
		
			if (result.rsm && result.rsm.url)
	        {
	        	// �жϷ���url����ǰurl�Ƿ���ͬ
	        	if (window.location.href == result.rsm.url)
	        	{
	        		window.location.reload();
	        	}
	        	else
	        	{
	            	window.location = decodeURIComponent(result.rsm.url);
	        	}
	        }
	        else
	        {
	        	switch (type)
	        	{
	        		case 'default':
					case 'ajax_post_alert':
					case 'error_message':
						window.location.reload();
					break;

					case 'ajax_post_modal':
						$('#aw-ajax-box div.modal').modal('hide');
					break;

	        	}
	        }
		}
	},
}
function post_error(){if($('.error_message').css('display')!='none'){AWS.shake($('.error_message'))}else{$('.error_message').fadeIn()};$('html,body').animate({scrollTop:$("body").offset().top},1000)};