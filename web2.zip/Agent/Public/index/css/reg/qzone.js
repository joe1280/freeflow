var qquser = {
    index_dan_shift:function(a,b,c,d){
          
       $.post(_APP_  + "/Qzone/index/shift/",{'lei':b,'val': c},function (result)
	    {
	    	if (result.errno == 1)
	        { 
	            if(!result.rsm.jieg){
	                if(result.err){
	                 $(".error_message em").html(result.err);
	                }else{
	                  $(".error_message em").html('����ʧ��-��ˢ�º�����');   
	                }
	            }else{
	         $(".error_message em").html(result.rsm.jieg );
	                e = d.attr("title");
	                if(typeof(e)!= "undefined" && e.indexOf(":") >= 0 ){
	               f = d.attr("title").split(":"); 
	                }
	               
	                if(c=='on'){
	                 d.addClass('btn-info');
	                d.removeClass('btn-danger');
	                d.attr("onclick","qquser.index_dan_shift("+a+",'"+b+"','off',$('#"+b+a+"'))");
	                 if(typeof(e)!= "undefined" && e.indexOf(":") >= 0 ){
	                 d.attr("title",f[0] + ":����");
	                }
	                
	                }else{
	                d.addClass('btn-danger');
	                d.removeClass('btn-info');
	                d.attr("onclick","qquser.index_dan_shift("+a+",'"+b+"','on',$('#"+b+a+"'))");
	                
	                if(typeof(e)!= "undefined" && e.indexOf(":") >= 0 ){
	                 d.attr("title",f[0] + ":�ر�");
	                }
	                }
	            }
	            
	        }
	        else
	        {
	            if (result.err)
	            {
	                alert(result.err);
	            }

	            if (result.rsm.url)
	            {
	                window.location = decodeURIComponent(result.rsm.url);
	            }
	        }
 
	    }, 'json'); 
	    post_error(); 
	  
    }
    
}
$(document).on('click','.delq-data',function()
{
	    
		var _this = $(this),
			id = _this.parents('span').attr('data-id');
		$(this).parents('span[data-id='+id+']').fadeOut('slow',function(){
			_this.parents('span[data-id='+id+']').detach();
		});
		$.post( _APP_ + "/Qzone/index/del_data/" ,{'id':id}, function(result){
		    if(result.errno != 1)
		    {
		        alert(result.err);
		    }else{
		        $(".error_message em").html(result.err); 
		         post_error();
		    }
		}, 'json'); 
		
	});
$(document).on('click','.delq-usernews',function()
{
	    
		var _this = $(this),
			id = _this.parents('span').attr('data-id');
		$(this).parents('span[data-id='+id+']').fadeOut('slow',function(){
			_this.parents('span[data-id='+id+']').detach();
		});
		$.post( _APP_ + "/Qzone/index/delq_usernews/" ,{'id':id}, function(result){
		    if(result.errno != 1)
		    {
		        alert(result.err);
		    }else{
		        $(".error_message em").html(result.err); 
		         post_error();
		    }
		}, 'json'); 
		
	});
$(document).on('click','.on_Single',function(){
   var _this = $(this);
  if($('#Single').html()){
     _this.children('span').html('һ��ʱ�����޷����¼��'); 
     return;
  }else{
      $('#Single').html('');
  }
  _this.addClass('loading');
   
   $.post( _APP_ + "/Qzone/index/danSingle/" ,{'id':null}, function(result){
		    if(result.errno != 1)
		    {
		        alert(result.err);
		    }else{
		        var ul = '<ul class="list-group pt-page-rotateUnfoldBottom lie{{i}}" ><li class="list-group-item active"><span class="pull-right label label-danger">{{sum}}</span>{{name}}</li><div class="clearfix"></div><ul>'; 
		        var li = '<li class="list-group-item">{{qq}}-{{name}}</li>';
		        var no = '<li class="list-group-item">δ�е������</li>';
		        for(var i=0;i < result.err.length;i++){ 
		            
		        $('#Single').append(Hogan.compile(ul).render(
	                {
	                    'i': i , 
	                    'name':result.err[i].name,
	                    'sum':result.err[i].sum
	                }));
	               if(result.err[i].friend instanceof Array ){
    	            for(var j=0;j<result.err[i].friend.length;j++){ 
    	                 $('#Single').children('.lie' + i).append(Hogan.compile(li).render(
    	                {
    	                    'qq': result.err[i].friend[j].qq,
    	                    'name':result.err[i].friend[j].name
    	                }));
    	            } }else{
    	                 $('#Single').children('.lie' + i).append(Hogan.compile(no).render(
    	                {
    	                  
    	                }));
    	            }
		         }
		          
		    }
		      _this.removeClass('loading'); 
		      _this.children('span').html('�Ѽ�����');
	}, 'json');
    
});