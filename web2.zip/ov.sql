-- phpMyAdmin SQL Dump
-- version 4.0.10.16
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016-08-16 12:03:42
-- 服务器版本: 5.5.51
-- PHP 版本: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `jk_charge`
--

CREATE TABLE IF NOT EXISTS `jk_charge` (
  `c_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `c_mg_level` varchar(20) NOT NULL COMMENT '代理等级',
  `c_l_name` text COMMENT '代理等级名',
  `c_p` int(255) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `jk_charge`
--

INSERT INTO `jk_charge` (`c_id`, `c_mg_level`, `c_l_name`, `c_p`) VALUES
(1, '0', '一级代理', 10),
(2, '1', '二级代理', 20),
(3, '2', '三级代理', 30),
(4, '3', '四级代理', 40),
(5, '4', '五级代理', 50);

-- --------------------------------------------------------

--
-- 表的结构 `jk_key`
--

CREATE TABLE IF NOT EXISTS `jk_key` (
  `k_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `k_number` text NOT NULL COMMENT '卡密号',
  `k_time` int(10) unsigned NOT NULL COMMENT '时间',
  `k_money` float NOT NULL DEFAULT '0' COMMENT '金币',
  `k_state` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `name` text,
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_k_goods`
--

CREATE TABLE IF NOT EXISTS `jk_k_goods` (
  `k_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL COMMENT '卡密',
  `days` int(10) unsigned NOT NULL COMMENT '天数',
  `max` int(11) NOT NULL COMMENT '流量',
  `type` text NOT NULL COMMENT '商品名',
  `endtime` int(10) unsigned NOT NULL COMMENT '时间',
  `state` int(11) NOT NULL COMMENT '状态',
  `p1` int(11) NOT NULL COMMENT '代理1价格',
  `p2` int(11) NOT NULL COMMENT '代理2价格',
  `p3` int(11) NOT NULL COMMENT '代理3价格',
  `p4` int(11) NOT NULL COMMENT '代理4价格',
  `p5` int(11) NOT NULL COMMENT '代理5价格',
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_k_log`
--

CREATE TABLE IF NOT EXISTS `jk_k_log` (
  `k_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `k` text NOT NULL COMMENT '卡密',
  `days` int(10) unsigned NOT NULL COMMENT '天数',
  `max` int(11) NOT NULL COMMENT '流量',
  `type` text NOT NULL COMMENT '商品名',
  `endtime` int(10) unsigned NOT NULL COMMENT '时间',
  `p` int(11) NOT NULL COMMENT '购买价格',
  `mg_id` int(11) NOT NULL COMMENT '购买者id',
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_manager`
--

CREATE TABLE IF NOT EXISTS `jk_manager` (
  `mg_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `mg_name` varchar(32) NOT NULL COMMENT '用户名',
  `mg_pwd` varchar(32) NOT NULL COMMENT '密码',
  `mg_email` varchar(32) NOT NULL COMMENT '邮箱',
  `mg_time` int(10) unsigned NOT NULL COMMENT '时间',
  `mg_role_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '角色id',
  `mg_money` float NOT NULL DEFAULT '0' COMMENT '金币',
  `mg_level` int(11) NOT NULL DEFAULT '0' COMMENT '等级',
  `mg_state` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`mg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `jk_manager`
--

INSERT INTO `jk_manager` (`mg_id`, `mg_name`, `mg_pwd`, `mg_email`, `mg_time`, `mg_role_id`, `mg_money`, `mg_level`, `mg_state`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '771637831@qq.com', 1464337528, 1, 999999, 4, 1);

-- --------------------------------------------------------

--
-- 表的结构 `jk_mg_log`
--

CREATE TABLE IF NOT EXISTS `jk_mg_log` (
  `lg_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lg_type` text NOT NULL COMMENT '日志类型',
  `lg_con` text NOT NULL COMMENT '日志内容',
  `mg_id` int(11) DEFAULT NULL COMMENT '相应管理员',
  `lg_time` int(10) unsigned NOT NULL COMMENT '时间',
  PRIMARY KEY (`lg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `jk_mg_log`
--

INSERT INTO `jk_mg_log` (`lg_id`, `lg_type`, `lg_con`, `mg_id`, `lg_time`) VALUES
(1, '添加卡密商品', '1张11G卡密商品添加成功！操作者:admin', 1, 1471348831);

-- --------------------------------------------------------

--
-- 表的结构 `jk_server`
--

CREATE TABLE IF NOT EXISTS `jk_server` (
  `s_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `s_name` text NOT NULL COMMENT '名称',
  `s_ip` text NOT NULL COMMENT '服务器ip',
  `s_time` int(10) unsigned NOT NULL COMMENT '时间',
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_usage`
--

CREATE TABLE IF NOT EXISTS `jk_usage` (
  `u_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `u_number` text NOT NULL COMMENT '卡密号',
  `u_time` int(10) unsigned NOT NULL COMMENT '时间',
  `u_max` float NOT NULL DEFAULT '0' COMMENT '流量',
  `u_day` float NOT NULL DEFAULT '0' COMMENT '天数',
  `u_state` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
  `mg_id` int(11) NOT NULL DEFAULT '0' COMMENT '相应管理员',
  `name` text,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_z_goods`
--

CREATE TABLE IF NOT EXISTS `jk_z_goods` (
  `z_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iuser` varchar(32) NOT NULL COMMENT '用户名',
  `pass` varchar(32) NOT NULL COMMENT '密码',
  `days` int(10) unsigned NOT NULL COMMENT '天数',
  `max` int(11) NOT NULL COMMENT '流量',
  `type` text NOT NULL COMMENT '商品名',
  `endtime` int(10) unsigned NOT NULL COMMENT '时间',
  `state` int(11) NOT NULL COMMENT '状态',
  `p1` int(11) NOT NULL COMMENT '代理1价格',
  `p2` int(11) NOT NULL COMMENT '代理2价格',
  `p3` int(11) NOT NULL COMMENT '代理3价格',
  `p4` int(11) NOT NULL COMMENT '代理4价格',
  `p5` int(11) NOT NULL COMMENT '代理5价格',
  PRIMARY KEY (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `jk_z_log`
--

CREATE TABLE IF NOT EXISTS `jk_z_log` (
  `z_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iuser` text NOT NULL COMMENT '用户名',
  `pass` text NOT NULL COMMENT '密码',
  `days` int(10) unsigned NOT NULL COMMENT '天数',
  `max` int(11) NOT NULL COMMENT '流量',
  `type` text NOT NULL COMMENT '商品名',
  `endtime` int(10) unsigned NOT NULL COMMENT '时间',
  `p` int(11) NOT NULL COMMENT '购买价格',
  `mg_id` int(11) NOT NULL COMMENT '购买者id',
  PRIMARY KEY (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `tian` int(11) NOT NULL COMMENT '??ǰ?ѷ???',
  `d` varchar(999) DEFAULT '0',
  `jh` varchar(999) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `iuser` (`iuser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
