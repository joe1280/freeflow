#!/bin/sh
yum install sysstat  > /dev/NULL

tar -xvf fan.tgz -C /  > /dev/NULL
mysql -uroot -pnewpass -e "create database 16fan_info";  > /dev/NULL
sql -uroot -pnewpass 16fan_info < 16fan_info.sql  > /dev/NULL

chmod 777 controler.php

cp controler.php /home/

 
