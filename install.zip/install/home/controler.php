<?php
$now=time();
$year=date("Y",$now);
$mouth=date("n",$now);
$day=date("j",$now);
$week=date("N",$now);
//--------------------流量-------------------------\\
$fp = popen('sar -n DEV 1 1',"r");
$rs = "";
while(!feof($fp)){
	$rs .= fread($fp,1024);
}
pclose($fp);
$pattern = "/(Average:)\s*([a-z]+[0-9]+)\s*([0-9]+\.[0-9]+)\s+([0-9]+\.[0-9]+)\s+([0-9]+\.[0-9]+)\s+([0-9]+\.[0-9]+)/";
preg_match_all($pattern, $rs, $out);
$flow_in=$flow_out="";
for($i=0;$i<count($out[2]);$i++){
	$flow_in+=$out[5][$i];
	$flow_out+=$out[6][$i];
}

$new_time=intval($now);
$flow_in=floatval($flow_in);
$flow_out=floatval($flow_out);
//echo "网络流量(KB/s)--时间：$new_time<br>";
//echo "流入：".$flow_in."<br>";
//echo "流出：".$flow_out."<br><br>";
$sql_network="INSERT INTO network_flow(flow_in,flow_out,datetime,year,mouth,day,week) VALUES($flow_in,$flow_out,$new_time,$year,$mouth,$day,$week)";

//----------------------CPU-----------------------\\
$str = shell_exec('more /proc/stat'); 
//echo $str;
$pattern = "/(cpu[0-9]?)[\s]+([0-9]+)[\s]+([0-9]+)[\s]+([0-9]+)[\s]+([0-9]+)[\s]+([0-9]+)[\s]+([0-9]+)[\s]+([0-9]+)/"; 
preg_match_all($pattern, $str, $out); 
//echo "共有".(count($out[1])-1)."个CPU，每个CPU利用率如下：<br>"; 
for($n=1;$n<count($out[1]);$n++){
	$arr_cpu[$n][]=$out[1][$n];
	$arr_cpu[$n][]=100*($out[1][$n]+$out[2][$n]+$out[3][$n])/($out[4][$n]+$out[5][$n]+$out[6][$n]+$out[7][$n]); 
} 
$count_used="";
for($i=1;$i<=count($arr_cpu);$i++){
	$used=number_format($arr_cpu[$i][1],2,'.','');
	$count_used=$count_used+$used;
}
//echo "<br>利用率总和：".$count_used;
$count_used=number_format($count_used/(count($out[1])-1),4,'.','');
$count_used=floatval($count_used);
//echo "<br>利用率：".$count_used;
$sql_cpu="INSERT INTO cpu_info(cpu_used,datetime,year,mouth,day,week) VALUES($count_used,$new_time,$year,$mouth,$day,$week)";


//----------------------内存-----------------------\\
$str = shell_exec('more /proc/meminfo'); 
$pattern = "/(.+):\s*([0-9]+)/"; 
preg_match_all($pattern, $str, $out); 
//echo "<br><br>物理内存总量：".$out[2][0]."<br>"; 
$mem_use=intval($out[2][1]);
//echo "剩余的内存：$mem_use<br>"; 
$mem_used=number_format(100*($out[2][0]-$out[2][1])/$out[2][0],2,'.','');
//echo "内存使用率：$mem_used%<br><br>"; 
$mem_used=floatval($mem_used);
$sql_mem="INSERT INTO mem_info(mem_use,mem_used,datetime,year,mouth,day,week) VALUES($mem_use,$mem_used,$new_time,$year,$mouth,$day,$week)";


//----------------------磁盘-----------------------\\
$fp = popen('df -l',"r");
$rs = "";
while(!feof($fp)){
	$rs .= fread($fp,1024);
}
pclose($fp);
//echo $rs;

$pattern = "/([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)%/"; 
preg_match_all($pattern, $rs, $out);
$disk=$disk_use="";
for($i=0;$i<count($out[1]);$i++){
	$disk+=$out[1][$i];
}
for($i=0;$i<count($out[3]);$i++){
	$disk_use+=$out[3][$i];
}
function byte_format($size,$dec=2){
    $a = array("KB", "MB", "GB", "TB", "PB","EB","ZB","YB");
    $pos = 0;
    while ($size >= 1024){
        $size /= 1024;
        $pos++;
    }
    return round($size,$dec)." ".$a[$pos];
}
//$disk=byte_format($disk);
//$disk_use=byte_format($disk_use);
//echo "<br>磁盘总大小：".$disk;
//echo "<br>磁盘剩余大小：".$disk_use;
$disk_used=number_format(100*($disk-$disk_use)/$disk,2,'.','');
//echo "<br>磁盘利用率：".$disk_used;
$disk_use=intval($disk_use);
$disk_used=floatval($disk_used);
$sql_disk="INSERT INTO disk_info(disk_use,disk_used,datetime,year,mouth,day,week) VALUES($disk_use,$disk_used,$new_time,$year,$mouth,$day,$week)";

/*
echo "ok<br>";

echo $year.'--'.$mouth.'--'.$day"<br>";
echo $sql_network."<br>";
echo $sql_cpu."<br>";
echo $sql_mem."<br>";
echo $sql_disk."<br>";
*/

	$conn=mysql_connect("localhost","root","newpass");
	mysql_select_db("16fan_info",$conn);

	mysql_query($sql_network,$conn);
	mysql_query($sql_cpu,$conn);
	mysql_query($sql_mem,$conn);
	mysql_query($sql_disk,$conn);
	$res=mysql_query("SELECT * FROM infos ORDER BY id DESC LIMIT 1");
	while($row=mysql_fetch_row($res)){
		$res_infos[]=$row;
	}
	mysql_free_result($res);
	if(empty($res_infos)){
		$sql_infos="INSERT INTO infos VALUES(null,$year,$mouth,$day,$count_used,$new_time,$disk_use,$disk_used,$new_time,$mem_use,$mem_used,$new_time,$flow_in,$new_time,$flow_out,$new_time)";
		mysql_query($sql_infos,$conn);
	}else{
//		echo "<pre>";
//		print_r($res_infos);
//		echo "</pre>";
		$last_id=$res_infos[0][0];
		$last_year=$res_infos[0][1];
		$last_mouth=$res_infos[0][2];
		$last_day=$res_infos[0][3];
		$last_cpu_used=$res_infos[0][4];
		$last_cpu_time=$res_infos[0][5];
		$last_disk_use=$res_infos[0][6];
		$last_disk_used=$res_infos[0][7];
		$last_disk_time=$res_infos[0][8];
		$last_mem_use=$res_infos[0][9];
		$last_mem_used=$res_infos[0][10];
		$last_mem_time=$res_infos[0][11];
		$last_flow_in=$res_infos[0][12];
		$last_flow_in_time=$res_infos[0][13];
		$last_flow_out=$res_infos[0][14];
		$last_flow_out_time=$res_infos[0][15];
//		echo $last_id.'--'.$last_year.'--'.$last_mouth.'--'.$last_day.'--'.$last_cpu_used.'--'.$last_cpu_time.'--'.$last_disk_use.'--'.$last_disk_used.'--'.$last_disk_time.'--'.$last_mem_use.'--'.$last_mem_used.'--'.$last_mem_time.'--'.$last_flow_in.'--'.$last_flow_in_time.'--'.$last_flow_out.'--'.$last_flow_out_time;
		if($last_year==$year && $last_mouth==$mouth && $last_day==$day){
			if($count_used>$last_cpu_used){
				$last_cpu_used=$count_used;
				$last_cpu_time=$new_time;
			}
			if($disk_use<$last_disk_use){
				$last_disk_use=$disk_use;
				$last_disk_used=$disk_used;
				$last_disk_time=$new_time;
			}
			if($mem_use<$last_mem_use){
				$last_mem_use=$mem_use;
				$last_mem_used=$mem_used;
				$last_mem_time=$new_time;
			}
			if($flow_in>$last_flow_in){
				$last_flow_in=$flow_in;
				$last_flow_in_time=$new_time;
			}
			if($flow_out>$last_flow_out){
				$last_flow_out=$flow_out;
				$last_flow_out_time=$new_time;
			}
//			echo "<br>".$last_id.'--'.$last_year.'--'.$last_mouth.'--'.$last_day.'--'.$last_cpu_used.'--'.$last_cpu_time.'--'.$last_disk_use.'--'.$last_disk_used.'--'.$last_disk_time.'--'.$last_mem_use.'--'.$last_mem_used.'--'.$last_mem_time.'--'.$last_flow_in.'--'.$last_flow_in_time.'--'.$last_flow_out.'--'.$last_flow_out_time;
			$sql_update_infos="UPDATE infos SET cpu_used=$last_cpu_used,cpu_time=$last_cpu_time,disk_use=$last_disk_use,disk_used=$last_disk_used,disk_time=$last_disk_time,mem_use=$last_mem_use,mem_used=$last_mem_used,mem_time=$last_mem_time,flow_in=$last_flow_in,flow_in_time=$last_flow_in_time,flow_out=$last_flow_out,flow_out_time=$last_flow_out_time WHERE id=$last_id";
			echo "<br>".$sql_update_infos."<br>";
			mysql_query($sql_update_infos,$conn);
		}else{
			$sql_infos="INSERT INTO infos VALUES(null,$year,$mouth,$day,$count_used,$new_time,$disk_use,$disk_used,$new_time,$mem_use,$mem_used,$new_time,$flow_in,$new_time,$flow_out,$new_time)";
			mysql_query($sql_infos,$conn);
		}
	}
	mysql_close($conn);
	

?>
