-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appup`
--

DROP TABLE IF EXISTS `appup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `appname` char(50) DEFAULT NULL,
  `apphao` char(50) DEFAULT NULL,
  `appfile` varchar(100) DEFAULT NULL,
  `appinfo` varchar(250) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appup`
--

LOCK TABLES `appup` WRITE;
/*!40000 ALTER TABLE `appup` DISABLE KEYS */;
INSERT INTO `appup` VALUES (37,'','','meng.apk','',1);
/*!40000 ALTER TABLE `appup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_history`
--

DROP TABLE IF EXISTS `batch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_history` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(64) DEFAULT NULL COMMENT 'an identifier name of the batch instance',
  `batch_description` varchar(256) DEFAULT NULL COMMENT 'general description of the entry',
  `hotspot_id` int(32) DEFAULT '0' COMMENT 'the hotspot business id associated with this batch instance',
  `batch_status` varchar(128) NOT NULL DEFAULT 'Pending' COMMENT 'the batch status',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_name` (`batch_name`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_history`
--

LOCK TABLES `batch_history` WRITE;
/*!40000 ALTER TABLE `batch_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_history` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `planId` int(32) DEFAULT NULL,
  `billAmount` varchar(200) DEFAULT NULL,
  `billAction` varchar(128) NOT NULL DEFAULT 'Unavailable',
  `billPerformer` varchar(200) DEFAULT NULL,
  `billReason` varchar(200) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `cash` varchar(200) DEFAULT NULL,
  `creditcardname` varchar(200) DEFAULT NULL,
  `creditcardnumber` varchar(200) DEFAULT NULL,
  `creditcardverification` varchar(200) DEFAULT NULL,
  `creditcardtype` varchar(200) DEFAULT NULL,
  `creditcardexp` varchar(200) DEFAULT NULL,
  `coupon` varchar(200) DEFAULT NULL,
  `discount` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_merchant`
--

DROP TABLE IF EXISTS `billing_merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_merchant` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `mac` varchar(200) NOT NULL DEFAULT '',
  `pin` varchar(200) NOT NULL DEFAULT '',
  `txnId` varchar(200) NOT NULL DEFAULT '',
  `planName` varchar(128) NOT NULL DEFAULT '',
  `planId` int(32) NOT NULL,
  `quantity` varchar(200) NOT NULL DEFAULT '',
  `business_email` varchar(200) NOT NULL DEFAULT '',
  `business_id` varchar(200) NOT NULL DEFAULT '',
  `txn_type` varchar(200) NOT NULL DEFAULT '',
  `txn_id` varchar(200) NOT NULL DEFAULT '',
  `payment_type` varchar(200) NOT NULL DEFAULT '',
  `payment_tax` varchar(200) NOT NULL DEFAULT '',
  `payment_cost` varchar(200) NOT NULL DEFAULT '',
  `payment_fee` varchar(200) NOT NULL DEFAULT '',
  `payment_total` varchar(200) NOT NULL DEFAULT '',
  `payment_currency` varchar(200) NOT NULL DEFAULT '',
  `first_name` varchar(200) NOT NULL DEFAULT '',
  `last_name` varchar(200) NOT NULL DEFAULT '',
  `payer_email` varchar(200) NOT NULL DEFAULT '',
  `payer_address_name` varchar(200) NOT NULL DEFAULT '',
  `payer_address_street` varchar(200) NOT NULL DEFAULT '',
  `payer_address_country` varchar(200) NOT NULL DEFAULT '',
  `payer_address_country_code` varchar(200) NOT NULL DEFAULT '',
  `payer_address_city` varchar(200) NOT NULL DEFAULT '',
  `payer_address_state` varchar(200) NOT NULL DEFAULT '',
  `payer_address_zip` varchar(200) NOT NULL DEFAULT '',
  `payment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `payment_status` varchar(200) NOT NULL DEFAULT '',
  `pending_reason` varchar(200) NOT NULL DEFAULT '',
  `reason_code` varchar(200) NOT NULL DEFAULT '',
  `receipt_ID` varchar(200) NOT NULL DEFAULT '',
  `payment_address_status` varchar(200) NOT NULL DEFAULT '',
  `vendor_type` varchar(200) NOT NULL DEFAULT '',
  `payer_status` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_merchant`
--

LOCK TABLES `billing_merchant` WRITE;
/*!40000 ALTER TABLE `billing_merchant` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_merchant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_paypal`
--

DROP TABLE IF EXISTS `billing_paypal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_paypal` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `mac` varchar(200) DEFAULT NULL,
  `pin` varchar(200) DEFAULT NULL,
  `txnId` varchar(200) DEFAULT NULL,
  `planName` varchar(128) DEFAULT NULL,
  `planId` varchar(200) DEFAULT NULL,
  `quantity` varchar(200) DEFAULT NULL,
  `receiver_email` varchar(200) DEFAULT NULL,
  `business` varchar(200) DEFAULT NULL,
  `tax` varchar(200) DEFAULT NULL,
  `mc_gross` varchar(200) DEFAULT NULL,
  `mc_fee` varchar(200) DEFAULT NULL,
  `mc_currency` varchar(200) DEFAULT NULL,
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `payer_email` varchar(200) DEFAULT NULL,
  `address_name` varchar(200) DEFAULT NULL,
  `address_street` varchar(200) DEFAULT NULL,
  `address_country` varchar(200) DEFAULT NULL,
  `address_country_code` varchar(200) DEFAULT NULL,
  `address_city` varchar(200) DEFAULT NULL,
  `address_state` varchar(200) DEFAULT NULL,
  `address_zip` varchar(200) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_status` varchar(200) DEFAULT NULL,
  `payment_address_status` varchar(200) DEFAULT NULL,
  `payer_status` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_paypal`
--

LOCK TABLES `billing_paypal` WRITE;
/*!40000 ALTER TABLE `billing_paypal` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_paypal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans`
--

DROP TABLE IF EXISTS `billing_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `planName` varchar(128) DEFAULT NULL,
  `planId` varchar(128) DEFAULT NULL,
  `planType` varchar(128) DEFAULT NULL,
  `planTimeBank` varchar(128) DEFAULT NULL,
  `planTimeType` varchar(128) DEFAULT NULL,
  `planTimeRefillCost` varchar(128) DEFAULT NULL,
  `planBandwidthUp` varchar(128) DEFAULT NULL,
  `planBandwidthDown` varchar(128) DEFAULT NULL,
  `planTrafficTotal` varchar(128) DEFAULT NULL,
  `planTrafficUp` varchar(128) DEFAULT NULL,
  `planTrafficDown` varchar(128) DEFAULT NULL,
  `planTrafficRefillCost` varchar(128) DEFAULT NULL,
  `planRecurring` varchar(128) DEFAULT NULL,
  `planRecurringPeriod` varchar(128) DEFAULT NULL,
  `planRecurringBillingSchedule` varchar(128) NOT NULL DEFAULT 'Fixed',
  `planCost` varchar(128) DEFAULT NULL,
  `planSetupCost` varchar(128) DEFAULT NULL,
  `planTax` varchar(128) DEFAULT NULL,
  `planCurrency` varchar(128) DEFAULT NULL,
  `planGroup` varchar(128) DEFAULT NULL,
  `planActive` varchar(32) NOT NULL DEFAULT 'yes',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planName` (`planName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans`
--

LOCK TABLES `billing_plans` WRITE;
/*!40000 ALTER TABLE `billing_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans_profiles`
--

DROP TABLE IF EXISTS `billing_plans_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans_profiles` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(128) NOT NULL COMMENT 'the name of the plan',
  `profile_name` varchar(256) DEFAULT NULL COMMENT 'the profile/group name',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans_profiles`
--

LOCK TABLES `billing_plans_profiles` WRITE;
/*!40000 ALTER TABLE `billing_plans_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_plans_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_rates`
--

DROP TABLE IF EXISTS `billing_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_rates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rateName` varchar(128) NOT NULL DEFAULT '',
  `rateType` varchar(128) NOT NULL DEFAULT '',
  `rateCost` int(32) NOT NULL DEFAULT '0',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rateName` (`rateName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_rates`
--

LOCK TABLES `billing_rates` WRITE;
/*!40000 ALTER TABLE `billing_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cui`
--

DROP TABLE IF EXISTS `cui`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cui` (
  `clientipaddress` varchar(15) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `cui` varchar(32) NOT NULL DEFAULT '',
  `creationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastaccounting` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`username`,`clientipaddress`,`callingstationid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cui`
--

LOCK TABLES `cui` WRITE;
/*!40000 ALTER TABLE `cui` DISABLE KEYS */;
/*!40000 ALTER TABLE `cui` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Type` varchar(30) DEFAULT NULL,
  `Attribute` varchar(64) DEFAULT NULL,
  `Value` varchar(64) DEFAULT NULL,
  `Format` varchar(20) DEFAULT NULL,
  `Vendor` varchar(32) DEFAULT NULL,
  `RecommendedOP` varchar(32) DEFAULT NULL,
  `RecommendedTable` varchar(32) DEFAULT NULL,
  `RecommendedHelper` varchar(32) DEFAULT NULL,
  `RecommendedTooltip` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9723 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dictionary`
--

LOCK TABLES `dictionary` WRITE;
/*!40000 ALTER TABLE `dictionary` DISABLE KEYS */;
INSERT INTO `dictionary` VALUES (9722,'integer','Max-Active-Days',NULL,NULL,'OpenVPN',':=','check',NULL,'最长使用天数'),(9721,'integer','Simultaneous-Use',NULL,NULL,'OpenVPN',':=','check',NULL,'同时在线数'),(9718,'integer','Max-Global-Traffic',NULL,NULL,'OpenVPN',':=','check','','最大流量M');
/*!40000 ALTER TABLE `dictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotspots`
--

DROP TABLE IF EXISTS `hotspots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotspots` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `mac` varchar(200) DEFAULT NULL,
  `geocode` varchar(200) DEFAULT NULL,
  `owner` varchar(200) DEFAULT NULL,
  `email_owner` varchar(200) DEFAULT NULL,
  `manager` varchar(200) DEFAULT NULL,
  `email_manager` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `phone1` varchar(200) DEFAULT NULL,
  `phone2` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `companywebsite` varchar(200) DEFAULT NULL,
  `companyemail` varchar(200) DEFAULT NULL,
  `companycontact` varchar(200) DEFAULT NULL,
  `companyphone` varchar(200) DEFAULT NULL,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `mac` (`mac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotspots`
--

LOCK TABLES `hotspots` WRITE;
/*!40000 ALTER TABLE `hotspots` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotspots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(5) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `value` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,1,1,'省流量软件，全国最好用的流量软件。');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(32) DEFAULT NULL COMMENT 'user id of the userbillinfo table',
  `batch_id` int(32) DEFAULT NULL COMMENT 'batch id of the batch_history table',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status_id` int(10) NOT NULL DEFAULT '1' COMMENT 'the status of the invoice from invoice_status',
  `type_id` int(10) NOT NULL DEFAULT '1' COMMENT 'the type of the invoice from invoice_type',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_items` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(32) NOT NULL COMMENT 'invoice id of the invoices table',
  `plan_id` int(32) DEFAULT NULL COMMENT 'the plan_id of the billing_plans table',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'the amount cost of an item',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'the tax amount for an item',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'the total amount',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_status`
--

DROP TABLE IF EXISTS `invoice_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_status` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `value` varchar(32) NOT NULL DEFAULT '' COMMENT 'status value',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_status`
--

LOCK TABLES `invoice_status` WRITE;
/*!40000 ALTER TABLE `invoice_status` DISABLE KEYS */;
INSERT INTO `invoice_status` VALUES (1,'open','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(2,'disputed','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(3,'draft','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(4,'sent','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(5,'paid','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(6,'partial','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator');
/*!40000 ALTER TABLE `invoice_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_type`
--

DROP TABLE IF EXISTS `invoice_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `value` varchar(32) NOT NULL DEFAULT '' COMMENT 'type value',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_type`
--

LOCK TABLES `invoice_type` WRITE;
/*!40000 ALTER TABLE `invoice_type` DISABLE KEYS */;
INSERT INTO `invoice_type` VALUES (1,'Plans','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(2,'Services','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(3,'Consulting','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator');
/*!40000 ALTER TABLE `invoice_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node`
--

DROP TABLE IF EXISTS `node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Time of last checkin',
  `netid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `owner_name` varchar(50) NOT NULL COMMENT 'node owner''s name',
  `owner_email` varchar(50) NOT NULL COMMENT 'node owner''s email address',
  `owner_phone` varchar(25) NOT NULL COMMENT 'node owner''s phone number',
  `owner_address` varchar(100) NOT NULL COMMENT 'node owner''s address',
  `approval_status` varchar(1) NOT NULL COMMENT 'approval status: A (accepted), R (rejected), P (pending)',
  `ip` varchar(20) NOT NULL COMMENT 'ROBIN',
  `mac` varchar(20) NOT NULL COMMENT 'ROBIN',
  `uptime` varchar(100) NOT NULL COMMENT 'ROBIN',
  `robin` varchar(20) NOT NULL COMMENT 'ROBIN: robin version',
  `batman` varchar(20) NOT NULL COMMENT 'ROBIN: batman version',
  `memfree` varchar(20) NOT NULL COMMENT 'ROBIN',
  `nbs` mediumtext NOT NULL COMMENT 'ROBIN: neighbor list',
  `gateway` varchar(20) NOT NULL COMMENT 'ROBIN: nearest gateway',
  `gw-qual` varchar(20) NOT NULL COMMENT 'ROBIN: quality of nearest gateway',
  `routes` mediumtext NOT NULL COMMENT 'ROBIN: route to nearest gateway',
  `users` char(3) NOT NULL COMMENT 'ROBIN: current number of users',
  `kbdown` varchar(20) NOT NULL COMMENT 'ROBIN: downloaded kb',
  `kbup` varchar(20) NOT NULL COMMENT 'ROBIN: uploaded kb',
  `hops` varchar(3) NOT NULL COMMENT 'ROBIN: hops to gateway',
  `rank` varchar(3) NOT NULL COMMENT 'ROBIN: ???, not currently used for anything',
  `ssid` varchar(20) NOT NULL COMMENT 'ROBIN: ssid, not currently used for anything',
  `pssid` varchar(20) NOT NULL COMMENT 'ROBIN: pssid, not currently used for anything',
  `gateway_bit` tinyint(1) NOT NULL COMMENT 'ROBIN derivation: is this node a gateway?',
  `memlow` varchar(20) NOT NULL COMMENT 'ROBIN derivation: lowest reported memory on the node',
  `usershi` char(3) NOT NULL COMMENT 'ROBIN derivation: highest number of users',
  `cpu` float NOT NULL DEFAULT '0',
  `wan_iface` varchar(128) DEFAULT NULL,
  `wan_ip` varchar(128) DEFAULT NULL,
  `wan_mac` varchar(128) DEFAULT NULL,
  `wan_gateway` varchar(128) DEFAULT NULL,
  `wifi_iface` varchar(128) DEFAULT NULL,
  `wifi_ip` varchar(128) DEFAULT NULL,
  `wifi_mac` varchar(128) DEFAULT NULL,
  `wifi_ssid` varchar(128) DEFAULT NULL,
  `wifi_key` varchar(128) DEFAULT NULL,
  `wifi_channel` varchar(128) DEFAULT NULL,
  `lan_iface` varchar(128) DEFAULT NULL,
  `lan_mac` varchar(128) DEFAULT NULL,
  `lan_ip` varchar(128) DEFAULT NULL,
  `wan_bup` varchar(128) DEFAULT NULL,
  `wan_bdown` varchar(128) DEFAULT NULL,
  `firmware` varchar(128) DEFAULT NULL,
  `firmware_revision` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mac` (`mac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='node database';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node`
--

LOCK TABLES `node` WRITE;
/*!40000 ALTER TABLE `node` DISABLE KEYS */;
/*!40000 ALTER TABLE `node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operators`
--

DROP TABLE IF EXISTS `operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  `department` varchar(32) NOT NULL,
  `company` varchar(32) NOT NULL,
  `phone1` varchar(32) NOT NULL,
  `phone2` varchar(32) NOT NULL,
  `email1` varchar(32) NOT NULL,
  `email2` varchar(32) NOT NULL,
  `messenger1` varchar(32) NOT NULL,
  `messenger2` varchar(32) NOT NULL,
  `notes` varchar(128) NOT NULL,
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators`
--

LOCK TABLES `operators` WRITE;
/*!40000 ALTER TABLE `operators` DISABLE KEYS */;
INSERT INTO `operators` VALUES (6,'administrator','radius','','','','','','','','','','','','','2016-06-01 16:10:43','2009-12-07 20:12:33','admin','2016-04-16 14:16:41','administrator');
/*!40000 ALTER TABLE `operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operators_acl`
--

DROP TABLE IF EXISTS `operators_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators_acl` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `operator_id` int(32) NOT NULL,
  `file` varchar(128) NOT NULL,
  `access` tinyint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators_acl`
--

LOCK TABLES `operators_acl` WRITE;
/*!40000 ALTER TABLE `operators_acl` DISABLE KEYS */;
INSERT INTO `operators_acl` VALUES (114,6,'acct_custom_query',1),(115,6,'acct_active',1),(116,6,'acct_all',1),(117,6,'acct_ipaddress',1),(118,6,'acct_username',1),(119,6,'acct_date',1),(120,6,'acct_nasipaddress',1),(121,6,'acct_hotspot_accounting',1),(122,6,'acct_hotspot_compare',1),(123,6,'acct_maintenance_cleanup',1),(124,6,'acct_maintenance_delete',1),(125,6,'acct_plans_usage',1),(126,6,'bill_history_query',1),(127,6,'bill_merchant_transactions',1),(128,6,'bill_plans_list',1),(129,6,'bill_plans_del',1),(130,6,'bill_plans_edit',1),(131,6,'bill_plans_new',1),(132,6,'bill_pos_del',1),(133,6,'bill_pos_list',1),(134,6,'bill_pos_new',1),(135,6,'bill_pos_edit',1),(136,6,'bill_rates_date',1),(137,6,'bill_rates_new',1),(138,6,'bill_rates_list',1),(139,6,'bill_rates_del',1),(140,6,'bill_rates_edit',1),(141,6,'config_backup_managebackups',1),(142,6,'config_backup_createbackups',1),(143,6,'config_user',1),(144,6,'config_db',0),(145,6,'config_lang',1),(146,6,'config_interface',1),(147,6,'config_logging',1),(148,6,'config_maint_test_user',1),(149,6,'config_maint_disconnect_user',1),(150,6,'config_operators_list',1),(151,6,'config_operators_new',1),(152,6,'config_operators_del',1),(153,6,'config_operators_edit',1),(154,6,'gis_editmap',1),(155,6,'gis_viewmap',1),(156,6,'graphs_alltime_logins',1),(157,6,'graphs_overall_download',1),(158,6,'graphs_overall_logins',1),(159,6,'graphs_alltime_traffic_compare',1),(160,6,'graphs_overall_upload',1),(161,6,'graphs_logged_users',1),(162,6,'mng_rad_attributes_import',1),(163,6,'mng_rad_attributes_list',1),(164,6,'mng_rad_attributes_edit',1),(165,6,'mng_rad_attributes_del',1),(166,6,'mng_rad_attributes_new',1),(167,6,'mng_rad_attributes_search',1),(168,6,'mng_rad_groupcheck_new',1),(169,6,'mng_rad_groupreply_search',1),(170,6,'mng_rad_groupreply_list',1),(171,6,'mng_rad_groupreply_edit',1),(172,6,'mng_rad_groupcheck_search',1),(173,6,'mng_rad_groupcheck_list',1),(174,6,'mng_rad_groupcheck_edit',1),(175,6,'mng_rad_groupreply_del',1),(176,6,'mng_rad_groupreply_new',1),(177,6,'mng_rad_groupcheck_del',1),(178,6,'mng_hs_edit',1),(179,6,'mng_hs_list',1),(180,6,'mng_hs_del',1),(181,6,'mng_hs_new',1),(182,6,'mng_rad_ippool_new',1),(183,6,'mng_rad_ippool_del',1),(184,6,'mng_rad_ippool_list',1),(185,6,'mng_rad_ippool_edit',1),(186,6,'mng_rad_nas_edit',1),(187,6,'mng_rad_nas_list',1),(188,6,'mng_rad_nas_del',1),(189,6,'mng_rad_nas_new',1),(190,6,'mng_rad_profiles_edit',1),(191,6,'mng_rad_profiles_del',1),(192,6,'mng_rad_profiles_new',1),(193,6,'mng_rad_profiles_duplicate',1),(194,6,'mng_rad_profiles_list',1),(195,6,'mng_rad_proxys_new',1),(196,6,'mng_rad_proxys_del',1),(197,6,'mng_rad_proxys_list',1),(198,6,'mng_rad_proxys_edit',1),(199,6,'mng_rad_realms_new',1),(200,6,'mng_rad_realms_del',1),(201,6,'mng_rad_realms_list',1),(202,6,'mng_rad_realms_edit',1),(203,6,'mng_rad_usergroup_edit',1),(204,6,'mng_rad_usergroup_list_user',1),(205,6,'mng_rad_usergroup_del',1),(206,6,'mng_rad_usergroup_new',1),(207,6,'mng_rad_usergroup_list',1),(208,6,'mng_search',1),(209,6,'mng_del',1),(210,6,'mng_new',1),(211,6,'mng_import_users',1),(212,6,'mng_batch',1),(213,6,'mng_edit',1),(214,6,'mng_new_quick',1),(215,6,'mng_list_all',1),(216,6,'rep_lastconnect',1),(217,6,'rep_online',1),(218,6,'rep_history',1),(219,6,'rep_topusers',1),(220,6,'rep_logs_radius',1),(221,6,'rep_logs_boot',1),(222,6,'rep_logs_system',1),(223,6,'rep_logs_daloradius',1),(224,6,'rep_stat_services',1),(225,6,'rep_stat_server',1),(226,6,'mng_rad_hunt_del',1),(227,6,'mng_rad_hunt_edit',1),(228,6,'mng_rad_hunt_list',1),(229,6,'mng_rad_hunt_new',1),(230,6,'config_mail',1),(231,6,'mng_batch_add',1),(232,6,'mng_batch_list',1),(233,6,'mng_batch_del',1),(234,6,'bill_invoice_list',1),(235,6,'bill_invoice_new',1),(236,6,'bill_invoice_edit',1),(237,6,'bill_invoice_del',1),(238,6,'bill_payment_types_new',1),(239,6,'bill_payment_types_edit',1),(240,6,'bill_payment_types_list',1),(241,6,'bill_payment_types_del',1),(242,6,'bill_payments_list',1),(243,6,'bill_payments_edit',1),(244,6,'bill_payments_new',1),(245,6,'bill_payments_del',1),(246,6,'rep_newusers',1),(247,6,'bill_invoice_report',1),(248,6,'config_reports_dashboard',1),(249,6,'rep_stat_ups',1),(250,6,'rep_stat_raid',1),(251,6,'rep_stat_cron',1);
/*!40000 ALTER TABLE `operators_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operators_acl_files`
--

DROP TABLE IF EXISTS `operators_acl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators_acl_files` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `file` varchar(128) NOT NULL,
  `category` varchar(128) NOT NULL,
  `section` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators_acl_files`
--

LOCK TABLES `operators_acl_files` WRITE;
/*!40000 ALTER TABLE `operators_acl_files` DISABLE KEYS */;
INSERT INTO `operators_acl_files` VALUES (2,'mng_search','Management','Users'),(3,'mng_batch','Management','Users'),(4,'mng_del','Management','Users'),(5,'mng_edit','Management','Users'),(6,'mng_new','Management','Users'),(7,'mng_new_quick','Management','Users'),(8,'mng_import_users','Management','Users'),(9,'mng_list_all','Management','Users'),(10,'mng_hs_del','Management','Hotspot'),(11,'mng_hs_edit','Management','Hotspot'),(12,'mng_hs_new','Management','Hotspot'),(13,'mng_hs_list','Management','Hotspot'),(14,'mng_rad_nas_del','Management','NAS'),(15,'mng_rad_nas_edit','Management','NAS'),(16,'mng_rad_nas_new','Management','NAS'),(17,'mng_rad_nas_list','Management','NAS'),(18,'mng_rad_usergroup_del','Management','UserGroup'),(19,'mng_rad_usergroup_edit','Management','UserGroup'),(20,'mng_rad_usergroup_new','Management','UserGroup'),(21,'mng_rad_usergroup_list_user','Management','UserGroup'),(22,'mng_rad_usergroup_list','Management','UserGroup'),(23,'mng_rad_groupcheck_search','Management','Groups'),(24,'mng_rad_groupcheck_del','Management','Groups'),(25,'mng_rad_groupcheck_list','Management','Groups'),(26,'mng_rad_groupcheck_new','Management','Groups'),(27,'mng_rad_groupcheck_edit','Management','Groups'),(28,'mng_rad_groupreply_search','Management','Groups'),(29,'mng_rad_groupreply_del','Management','Groups'),(30,'mng_rad_groupreply_list','Management','Groups'),(31,'mng_rad_groupreply_new','Management','Groups'),(32,'mng_rad_groupreply_edit','Management','Groups'),(33,'mng_rad_profiles_new','Management','Profiles'),(34,'mng_rad_profiles_edit','Management','Profiles'),(35,'mng_rad_profiles_duplicate','Management','Profiles'),(36,'mng_rad_profiles_del','Management','Profiles'),(37,'mng_rad_profiles_list','Management','Profiles'),(38,'mng_rad_attributes_list','Management','Attributes'),(39,'mng_rad_attributes_new','Management','Attributes'),(40,'mng_rad_attributes_edit','Management','Attributes'),(41,'mng_rad_attributes_search','Management','Attributes'),(42,'mng_rad_attributes_del','Management','Attributes'),(43,'mng_rad_attributes_import','Management','Attributes'),(44,'mng_rad_realms_list','Management','Realms'),(45,'mng_rad_realms_new','Management','Realms'),(46,'mng_rad_realms_edit','Management','Realms'),(47,'mng_rad_realms_del','Management','Realms'),(48,'mng_rad_proxys_list','Management','Proxys'),(49,'mng_rad_proxys_new','Management','Proxys'),(50,'mng_rad_proxys_edit','Management','Proxys'),(51,'mng_rad_proxys_del','Management','Proxys'),(52,'mng_rad_ippool_list','Management','IPPool'),(53,'mng_rad_ippool_new','Management','IPPool'),(54,'mng_rad_ippool_edit','Management','IPPool'),(55,'mng_rad_ippool_del','Management','IPPool'),(56,'rep_topusers','Reporting','Core'),(57,'rep_online','Reporting','Core'),(58,'rep_lastconnect','Reporting','Core'),(59,'rep_history','Reporting','Core'),(60,'rep_logs_radius','Reporting','Logs'),(61,'rep_logs_system','Reporting','Logs'),(62,'rep_logs_boot','Reporting','Logs'),(63,'rep_logs_daloradius','Reporting','Logs'),(64,'rep_stat_services','Reporting','Status'),(65,'rep_stat_server','Reporting','Status'),(66,'acct_active','Accounting','General'),(67,'acct_username','Accounting','General'),(68,'acct_all','Accounting','General'),(69,'acct_date','Accounting','General'),(70,'acct_ipaddress','Accounting','General'),(71,'acct_nasipaddress','Accounting','General'),(72,'acct_hotspot_accounting','Accounting','Hotspot'),(73,'acct_hotspot_compare','Accounting','Hotspot'),(74,'acct_custom_query','Accounting','Custom'),(75,'acct_maintenance_cleanup','Accounting','Maintenance'),(76,'acct_maintenance_delete','Accounting','Maintenance'),(77,'bill_pos_del','Billing','POS'),(78,'bill_pos_new','Billing','POS'),(79,'bill_pos_list','Billing','POS'),(80,'bill_pos_edit','Billing','POS'),(81,'bill_rates_date','Billing','Rates'),(82,'bill_rates_del','Billing','Rates'),(83,'bill_rates_new','Billing','Rates'),(84,'bill_rates_edit','Billing','Rates'),(85,'bill_rates_list','Billing','Rates'),(86,'bill_merchant_transactions','Billing','Merchant'),(87,'bill_plans_del','Billing','Plans'),(88,'bill_plans_new','Billing','Plans'),(89,'bill_plans_edit','Billing','Plans'),(90,'bill_plans_list','Billing','Plans'),(91,'bill_history_query','Billing','History'),(92,'gis_editmap','GIS','General'),(93,'gis_viewmap','GIS','General'),(94,'graphs_alltime_logins','Graphs','General'),(95,'graphs_alltime_traffic_compare','Graphs','General'),(96,'graphs_overall_download','Graphs','General'),(97,'graphs_overall_upload','Graphs','General'),(98,'graphs_overall_logins','Graphs','General'),(99,'graphs_logged_users','Graphs','General'),(100,'config_db','Configuration','Core'),(101,'config_interface','Configuration','Core'),(102,'config_lang','Configuration','Core'),(103,'config_logging','Configuration','Core'),(104,'config_maint_test_user','Configuration','Maintenance'),(105,'config_maint_disconnect_user','Configuration','Maintenance'),(106,'config_operators_del','Configuration','Operators'),(107,'config_operators_list','Configuration','Operators'),(108,'config_operators_edit','Configuration','Operators'),(109,'config_operators_new','Configuration','Operators'),(110,'config_backup_createbackups','Configuration','Backup'),(111,'config_backup_managebackups','Configuration','Backup'),(112,'acct_plans_usage','Accounting','Plans'),(113,'config_user','Configuration','Core'),(114,'mng_rad_hunt_del','Management','HuntGroups'),(115,'mng_rad_hunt_edit','Management','HuntGroups'),(116,'mng_rad_hunt_list','Management','HuntGroups'),(117,'mng_rad_hunt_new','Management','HuntGroups'),(118,'config_mail','Configuration','Core'),(119,'mng_batch_add','Management','Batch'),(120,'mng_batch_list','Management','Batch'),(121,'mng_batch_del','Management','Batch'),(122,'bill_invoice_list','Billing','Invoice'),(123,'bill_invoice_new','Billing','Invoice'),(124,'bill_invoice_edit','Billing','Invoice'),(125,'bill_invoice_del','Billing','Invoice'),(126,'bill_payment_types_new','Billing','Payment Types'),(127,'bill_payment_types_edit','Billing','Payment Types'),(128,'bill_payment_types_list','Billing','Payment Types'),(129,'bill_payment_types_del','Billing','Payment Types'),(130,'bill_payments_list','Billing','Payments'),(131,'bill_payments_edit','Billing','Payments'),(132,'bill_payments_new','Billing','Payments'),(133,'bill_payments_del','Billing','Payments'),(134,'rep_newusers','Reporting','Core'),(135,'bill_invoice_report','Billing','Invoice'),(136,'config_reports_dashboard','Configuration','Reporting'),(137,'rep_stat_ups','Reporting','Status'),(138,'rep_stat_raid','Reporting','Status'),(139,'rep_stat_cron','Reporting','Status');
/*!40000 ALTER TABLE `operators_acl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(32) NOT NULL COMMENT 'invoice id of the invoices table',
  `amount` decimal(10,2) NOT NULL COMMENT 'the amount paid',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type_id` int(10) NOT NULL DEFAULT '1' COMMENT 'the type of the payment from payment_type',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_type`
--

DROP TABLE IF EXISTS `payment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `value` varchar(32) NOT NULL DEFAULT '' COMMENT 'type value',
  `notes` varchar(128) NOT NULL COMMENT 'general notes/description',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_type`
--

LOCK TABLES `payment_type` WRITE;
/*!40000 ALTER TABLE `payment_type` DISABLE KEYS */;
INSERT INTO `payment_type` VALUES (1,'Cash','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(2,'Check','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator'),(3,'Bank Transfer','','2010-05-27 00:00:00','operator','2010-05-27 00:00:00','operator');
/*!40000 ALTER TABLE `payment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxys`
--

DROP TABLE IF EXISTS `proxys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proxys` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `proxyname` varchar(128) DEFAULT NULL,
  `retry_delay` int(8) DEFAULT NULL,
  `retry_count` int(8) DEFAULT NULL,
  `dead_time` int(8) DEFAULT NULL,
  `default_fallback` int(8) DEFAULT NULL,
  `creationdate` datetime DEFAULT NULL,
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxys`
--

LOCK TABLES `proxys` WRITE;
/*!40000 ALTER TABLE `proxys` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(15) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctsessiontime` int(12) DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(50) DEFAULT NULL,
  `connectinfo_stop` varchar(50) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `acctstartdelay` int(12) DEFAULT NULL,
  `acctstopdelay` int(12) DEFAULT NULL,
  `xascendsessionsvrkey` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`)
) ENGINE=InnoDB AUTO_INCREMENT=11871 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
INSERT INTO `radacct` VALUES (1,'5878C96107218D07E201AC826371731C','dd392be86d1f5c8d','12','','','127.0.0.1','1','Virtual','2016-05-30 09:22:03','2016-05-30 09:23:29',86,'','','',14706285,24286861,'','127.0.0.1','','Outbound-User','PPP','10.11.0.2',0,0,''),(2,'A9400D96A979CC669770B214ABD87BA9','e2918c01525aede3','12','','','127.0.0.1','1','Virtual','2016-05-30 09:31:20','2016-05-30 09:33:35',135,'','','',326226,3146589,'','127.0.0.1','','Outbound-User','PPP','10.8.0.2',0,0,''),(3,'8C8008050AD34E00326583B57C6B4B8E','f09b80cdb98ec6c3','12','','','127.0.0.1','1','Virtual','2016-05-30 09:43:26','2016-05-30 09:45:18',112,'','','',5519328,25521541,'','127.0.0.1','','Outbound-User','PPP','10.10.0.2',0,0,''),(4,'5348B1DAEADDE641E5B5B94A37095A51','4b01e89d9fa320a5','12','','','127.0.0.1','1','Virtual','2016-05-30 09:46:33','2016-05-30 09:56:57',624,'','','',930182,7764968,'','127.0.0.1','','Outbound-User','PPP','10.11.0.2',0,0,''),(5,'0A6BA6BBA1196B7397EE855B178050A4','f5977d458358723c','12','','','127.0.0.1','1','Virtual','2016-05-30 09:59:18','2016-05-30 10:00:21',63,'','','',1438,4821,'','127.0.0.1','','Outbound-User','PPP','10.11.0.2',0,0,''),(6,'6AE0738E3321870700707579B8AC513B','d86abad319e449b9','12','','','127.0.0.1','1','Virtual','2016-05-30 10:08:31','2016-05-30 10:14:14',343,'','','',8728912,79362149,'','127.0.0.1','','Outbound-User','PPP','10.10.0.2',0,0,''),(7,'D0B0B329E392230EA7173E626B117258','858ee6ab88d18c9d','1','','','127.0.0.1','1','Virtual','2016-05-30 10:09:39','2016-05-30 10:09:42',3,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.0.3',0,0,''),(1475,'80E520190A588A0BB5B21AD922B44112','0ec93f50138e703e','1','','','127.0.0.1','9','Virtual','2016-05-31 00:47:31','2016-05-31 00:51:52',261,'','','',44239,124200,'','127.0.0.1','','Outbound-User','PPP','10.11.0.3',0,0,''),(1804,'80D000650A175A3C77883360DC6D8709','7adf345b825971f4','1','','','127.0.0.1','2','Virtual','2016-05-31 00:56:13','2016-05-31 00:57:41',88,'','','',16899084,32637557,'','127.0.0.1','','Outbound-User','PPP','10.11.0.3',0,0,''),(1833,'AC0E3874552DC58C261EE6150A70AA94','d20648d23e8a6b61','55152776','','','127.0.0.1','30','Virtual','2016-05-31 01:00:00','2016-05-31 01:01:10',70,'','','',11098,5767,'','127.0.0.1','','Outbound-User','PPP','10.9.0.188',0,0,''),(1865,'9004DD7084CAC8607E1E350103346063','7c87bcb84589fccd','55152776','','','127.0.0.1','45','Virtual','2016-05-31 01:03:54','2016-05-31 01:04:30',36,'','','',24784,12529,'','127.0.0.1','','Outbound-User','PPP','10.10.0.187',0,0,''),(2030,'62732CCC4B11CC056E090B0970B10B16','10e9a179439adbd6','91349687','','','127.0.0.1','29','Virtual','2016-05-31 01:35:54','2016-05-31 02:12:37',2203,'','','',2517482,11399649,'','127.0.0.1','','Outbound-User','PPP','10.9.0.202',0,0,''),(2182,'63B158C33D00823C0C9C0D8AA8283D81','3b0fdb46dcd738a3','91349687','','','127.0.0.1','53','Virtual','2016-05-31 02:08:51','2016-05-31 02:21:04',733,'','','',1162199,3938043,'','127.0.0.1','','Outbound-User','PPP','10.10.0.212',0,0,''),(2183,'D00DE561E76BCA2659B4014A35EAD2E8','4cebefa8cf4a17ce','12','','','127.0.0.1','44','Virtual','2016-05-31 02:09:02','2016-05-31 03:01:30',3148,'','','',596974,2260580,'','127.0.0.1','','Outbound-User','PPP','10.10.0.2',0,0,''),(2744,'A040AB00BC891E0530C06E1E087DE043','b9af06e11797bec9','12','','','127.0.0.1','39','Virtual','2016-05-31 02:58:27','2016-05-31 03:00:49',142,'','','',10917,4591,'','127.0.0.1','','Outbound-User','PPP','10.9.0.242',0,0,''),(2897,'AC1BBDE65A7594400C03BBB1AA55000B','53ec0017e3421ab9','12','','','127.0.0.1','56','Virtual','2016-05-31 03:16:32','2016-05-31 05:33:07',8195,'','','',1526654,13512864,'','127.0.0.1','','Outbound-User','PPP','10.9.0.242',0,0,''),(3103,'B770C86D8C02DC0DE0B8E5DBE8070E52','0b79735587512b2d','92685117','','','127.0.0.1','4','Virtual','2016-05-31 04:05:48','2016-05-31 04:14:04',496,'','','',137712,90035,'','127.0.0.1','','Outbound-User','PPP','10.9.0.255',0,0,''),(3347,'113D2277C2B791040EA0B30567015A7E','c4046f59298854f7','92685117','','','127.0.0.1','46','Virtual','2016-05-31 04:51:20','2016-05-31 05:26:52',2132,'','','',166892,248108,'','127.0.0.1','','Outbound-User','PPP','10.10.1.22',0,0,''),(3419,'4CE7888E032780D01A3CD210602E3ED8','310fd15dda8f332a','76219318','','','127.0.0.1','45','Virtual','2016-05-31 05:05:06','2016-05-31 05:07:12',126,'','','',66792,51470,'','127.0.0.1','','Outbound-User','PPP','10.11.1.24',0,0,''),(3423,'A9B470008A62D1680E0C54530CE38C68','02bdbadaa9d0c5b6','76219318','','','127.0.0.1','18','Virtual','2016-05-31 05:07:16','2016-05-31 05:14:11',415,'','','',1056940,8484499,'','127.0.0.1','','Outbound-User','PPP','10.11.1.24',0,0,''),(3460,'0EB72D3602802D139DAA628129E6B9AB','d0e0b4f93b043f8d','76219318','','','127.0.0.1','63','Virtual','2016-05-31 05:14:14','2016-05-31 05:18:07',233,'','','',191753,426316,'','127.0.0.1','','Outbound-User','PPP','10.9.1.21',0,0,''),(3483,'EE0A95C501CA844BDED1B744E03C3B03','d3d61113452252a4','76219318','','','127.0.0.1','30','Virtual','2016-05-31 05:18:15','2016-05-31 05:19:18',63,'','','',154194,76975,'','127.0.0.1','','Outbound-User','PPP','10.10.1.35',0,0,''),(3493,'9A55408539C19AAE73EE0C1CA0700048','049e9801d6c78f3d','76219318','','','127.0.0.1','68','Virtual','2016-05-31 05:19:23','2016-05-31 05:26:17',414,'','','',532825,1200073,'','127.0.0.1','','Outbound-User','PPP','10.9.1.21',0,0,''),(3573,'289D80001768536A09BB97050B556AD1','81921772d820abb7','76219318','','','127.0.0.1','5','Virtual','2016-05-31 05:29:04','2016-05-31 05:29:26',22,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.1.24',0,0,''),(3806,'2C67104A3AE0520B5D74187A0A38A8D0','1b038d623bf2d2fb','38516185','','','127.0.0.1','48','Virtual','2016-05-31 05:34:21','2016-05-31 05:39:12',291,'','','',3525,7333,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(4094,'A6210637CEB3D5367361190218294ADB','774fd97f7b96bb6c','38516185','','','127.0.0.1','66','Virtual','2016-05-31 05:53:44','2016-05-31 08:00:07',7583,'','','',2634967,6652524,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(4101,'C32877B835C0D12C096C7902E3173092','25ba8d3d6ada2f17','92685117','','','127.0.0.1','59','Virtual','2016-05-31 05:55:00','2016-05-31 08:33:10',9490,'','','',11099804,129570334,'','127.0.0.1','','Outbound-User','PPP','10.11.1.50',0,0,''),(4390,'933DA04407A6209906394C17A05098BE','a732d95cbbe2c3cf','55152776','','','127.0.0.1','74','Virtual','2016-05-31 06:42:16','2016-05-31 06:48:17',361,'','','',236559,5022309,'','127.0.0.1','','Outbound-User','PPP','10.8.1.63',0,0,''),(4406,'E30006AA29D69920E10DC448A917C23A','a43b68106f4431b7','55152776','','','127.0.0.1','81','Virtual','2016-05-31 06:44:32','2016-05-31 11:21:11',16599,'','','',8905465,62345853,'','127.0.0.1','','Outbound-User','PPP','10.10.0.187',0,0,''),(4426,'76CD2B38239106D2B6456C5A3E02369C','0261ae5346b44471','87463445','','','127.0.0.1','59','Virtual','2016-05-31 06:47:07','2016-05-31 06:47:38',31,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.8.1.65',0,0,''),(4432,'B9237102E6E5E006A0810BC1B0C70D0E','ede9473d0432e5e6','87463445','','','127.0.0.1','59','Virtual','2016-05-31 06:48:10','2016-05-31 07:06:37',1107,'','','',1840698,16488346,'','127.0.0.1','','Outbound-User','PPP','10.8.1.65',0,0,''),(4865,'6985B5A0BC304891405B3C671AD8E503','4e88496b7d316edd','38516185','','','127.0.0.1','55','Virtual','2016-05-31 08:00:53','2016-05-31 08:17:16',983,'','','',236081,531210,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(4927,'12B33D5D010EA7ECA9A9017E569B2120','0d8a116841904ea9','39283641','','','127.0.0.1','93','Virtual','2016-05-31 08:09:40','2016-05-31 08:23:58',858,'','','',695607,2175833,'','127.0.0.1','','Outbound-User','PPP','10.10.1.97',0,0,''),(5216,'0464B13026B2B76050E5BA016BB2D045','9c08eea4f56bb166','38516185','','','127.0.0.1','93','Virtual','2016-05-31 08:46:39','2016-05-31 09:05:22',1123,'','','',356398,854110,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(5280,'17C215E929E3E938E566C18A8337083A','faef83680d7b0000','83338598','','','127.0.0.1','52','Virtual','2016-05-31 08:55:51','2016-05-31 08:56:29',38,'','','',17116,16789,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(5339,'9E34C43ED4AE768D8E30CBE9319D0029','4ac6eea8aa828f8c','38516185','','','127.0.0.1','38','Virtual','2016-05-31 09:03:24','2016-05-31 09:27:25',1441,'','','',372163,623347,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(5396,'6462553E4C3C5EB965DB42E8093409AD','e299345f94e03080','83338598','','','127.0.0.1','90','Virtual','2016-05-31 09:08:14','2016-05-31 09:09:13',59,'','','',11708,13845,'','127.0.0.1','','Outbound-User','PPP','10.11.1.126',0,0,''),(5420,'00E80AE6961AA0DD0D5898DCE82922AB','035caa401c0bf97e','83338598','','','127.0.0.1','54','Virtual','2016-05-31 09:10:40','2016-05-31 09:13:25',165,'','','',179353,803048,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(5477,'12305E8B6ACB6E128C0D8E744B51B06E','ab637622f5bb7414','12299896','','','127.0.0.1','92','Virtual','2016-05-31 09:16:32','2016-05-31 09:22:54',382,'','','',455532,5214472,'','127.0.0.1','','Outbound-User','PPP','10.8.1.132',0,0,''),(5555,'1D940C99BD012AE10D18187BC07AB93B','e29c1e7f47d3c3f8','12299896','','','127.0.0.1','79','Virtual','2016-05-31 09:24:43','2016-05-31 09:30:22',339,'','','',348286,730239,'','127.0.0.1','','Outbound-User','PPP','10.10.1.136',0,0,''),(5588,'A8A2103E13C1BE574CD32DC4808D2A11','c2360153affcae56','38516185','','','127.0.0.1','75','Virtual','2016-05-31 09:27:25','2016-05-31 09:41:56',871,'','','',81542,150620,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(5626,'337C0BA645629AEC9D60E7064CBCE1EC','065b6162ed5c3684','12299896','','','127.0.0.1','82','Virtual','2016-05-31 09:30:46','2016-05-31 09:48:04',1038,'','','',236593,1277380,'','127.0.0.1','','Outbound-User','PPP','10.9.1.136',0,0,''),(5682,'549CD97898749572D8917305A86491B5','ed1d6dd2ff21e8b4','83338598','','','127.0.0.1','109','Virtual','2016-05-31 09:35:18','2016-05-31 09:37:05',107,'','','',53511,71256,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(5719,'AB476CD9AE73708DD0D9C0006E9956EB','b7e5f37051e8e039','83338598','','','127.0.0.1','111','Virtual','2016-05-31 09:38:13','2016-05-31 09:39:53',100,'','','',19264,12904,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(5725,'0920EBB1B7D9070067C6D9719C62D040','05d74c69890ee22e','38516185','','','127.0.0.1','105','Virtual','2016-05-31 09:39:03','2016-05-31 09:43:08',245,'','','',4044,9442,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(5738,'909193A3695C787E578579B2C6B79036','ce2b0fe2ae1f8362','83338598','','','127.0.0.1','104','Virtual','2016-05-31 09:39:51','2016-05-31 09:40:19',28,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.1.126',0,0,''),(5777,'1BDA71915C0616D32D9313DC0C2A47CA','fa750dcf333356c3','83338598','','','127.0.0.1','102','Virtual','2016-05-31 09:43:37','2016-05-31 09:44:17',40,'','','',41978,42380,'','127.0.0.1','','Outbound-User','PPP','10.10.1.155',0,0,''),(5785,'ED91AD1BB8DDD4394E96DD75A500046B','9f986c24c47798fd','83338598','','','127.0.0.1','35','Virtual','2016-05-31 09:44:51','2016-05-31 09:45:47',56,'','','',6795,12811,'','127.0.0.1','','Outbound-User','PPP','10.10.1.155',0,0,''),(5799,'D2200B609EDB9E5234896E8245154E9D','3e1fb257ab86ef4e','72982617','','','127.0.0.1','92','Virtual','2016-05-31 09:46:05','2016-05-31 10:41:17',3312,'','','',6470620,85365035,'','127.0.0.1','','Outbound-User','PPP','10.9.1.151',0,0,''),(5800,'954B0E2D05D211079EDABB2D902BC906','222e56e116c3b1c5','83338598','','','127.0.0.1','102','Virtual','2016-05-31 09:46:10','2016-05-31 09:48:11',121,'','','',31611,43235,'','127.0.0.1','','Outbound-User','PPP','10.10.1.155',0,0,''),(5822,'99900070CA5C54A970C88DC2DB5E26EB','cf29b4dde070b9bf','12299896','','','127.0.0.1','76','Virtual','2016-05-31 09:48:13','2016-05-31 09:49:55',102,'','','',68976,239839,'','127.0.0.1','','Outbound-User','PPP','10.9.1.136',0,0,''),(5825,'2C317177394959C24DA1EA71B43B8B71','b0b7de571589fe57','83338598','','','127.0.0.1','101','Virtual','2016-05-31 09:48:34','2016-05-31 09:49:18',44,'','','',23954,28516,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(5837,'594510A16C1A2550BA945C9977690AA8','a477198b6ccc97d1','83338598','','','127.0.0.1','101','Virtual','2016-05-31 09:49:29','2016-05-31 09:52:35',186,'','','',160143,369539,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(5841,'47C7901EC36C4D617777346376AAB792','2a2f878c96f8691c','12299896','','','127.0.0.1','37','Virtual','2016-05-31 09:50:04','2016-05-31 09:51:40',96,'','','',36746,34179,'','127.0.0.1','','Outbound-User','PPP','10.8.1.132',0,0,''),(5855,'03B51A903184AC1029C023AA50AAB103','1f77032ea276062a','12299896','','','127.0.0.1','78','Virtual','2016-05-31 09:51:49','2016-05-31 09:53:49',120,'','','',40556,47265,'','127.0.0.1','','Outbound-User','PPP','10.11.1.161',0,0,''),(5869,'36A91CCB1206D675B54AC00EA9A5D2C4','681e3b01c8a06a10','83338598','','','127.0.0.1','101','Virtual','2016-05-31 09:53:01','2016-05-31 09:56:25',204,'','','',839266,1362011,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(5877,'5EB1AC7603B08A0DD755E58300258658','a4b92523403ea3bd','12299896','','','127.0.0.1','112','Virtual','2016-05-31 09:53:58','2016-05-31 09:56:56',178,'','','',73711,76274,'','127.0.0.1','','Outbound-User','PPP','10.10.1.136',0,0,''),(5882,'4EB6E9427B270005A99540275DC5E5D9','df9b8461d6cc577c','38516185','','','127.0.0.1','62','Virtual','2016-05-31 09:54:30','2016-05-31 09:58:47',257,'','','',2435,5979,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(5901,'7AC140141336ECD4B6605C0E44312E63','a1fcc370f7a918ad','19878745','','','127.0.0.1','101','Virtual','2016-05-31 09:56:26','2016-05-31 09:58:01',95,'','','',236093,2570649,'','127.0.0.1','','Outbound-User','PPP','10.9.1.155',0,0,''),(5905,'6B1D2ECBBA0C3E3B4D9BE0D120784006','6d21dd47ff4aaf89','12299896','','','127.0.0.1','63','Virtual','2016-05-31 09:57:05','2016-05-31 09:58:32',87,'','','',52480,68107,'','127.0.0.1','','Outbound-User','PPP','10.9.1.136',0,0,''),(5907,'DA5DB0C510656A7871DB6C987614C800','ee986cfde69a1276','83338598','','','127.0.0.1','80','Virtual','2016-05-31 09:57:20','2016-05-31 09:58:38',78,'','','',389231,13525,'','127.0.0.1','','Outbound-User','PPP','10.11.1.126',0,0,''),(5917,'0002A6D173A497089B6CC04650E456A6','37a63f642416bdb5','19878745','','','127.0.0.1','102','Virtual','2016-05-31 09:58:29','2016-05-31 10:08:10',581,'','','',817606,8061285,'','127.0.0.1','','Outbound-User','PPP','10.8.1.157',0,0,''),(5918,'2890D60089DC0E49000433A0A18EE81E','5e8bf2f4a22a0a03','12299896','','','127.0.0.1','68','Virtual','2016-05-31 09:58:33','2016-05-31 10:07:09',516,'','','',358483,2487330,'','127.0.0.1','','Outbound-User','PPP','10.10.1.136',0,0,''),(5922,'52353D5A86A750EE42D60DC9CD35A012','b63ac879a4343fd8','83338598','','','127.0.0.1','78','Virtual','2016-05-31 09:58:45','2016-05-31 09:59:35',50,'','','',104020,277590,'','127.0.0.1','','Outbound-User','PPP','10.10.1.155',0,0,''),(6014,'7C255B4CE64808070862B0C8DC665DD0','280e38b415a93891','12299896','','','127.0.0.1','9','Virtual','2016-05-31 10:07:19','2016-05-31 10:11:08',229,'','','',24732,78563,'','127.0.0.1','','Outbound-User','PPP','10.10.1.136',0,0,''),(6025,'8398982885A4A11220D53AA31A42371B','e870b5a082434a1d','19878745','','','127.0.0.1','114','Virtual','2016-05-31 10:08:26','2016-05-31 11:03:59',3333,'','','',3184524,18936876,'','127.0.0.1','','Outbound-User','PPP','10.11.1.174',0,0,''),(6052,'949A50B6D9053855DE9E53C4B734AA65','37c653e91e080850','83338598','','','127.0.0.1','114','Virtual','2016-05-31 10:10:50','2016-05-31 10:18:12',442,'','','',446150,2054017,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(6055,'4E226626C556BB7060031C5E97ECEAAC','3fe5059a948267e6','12299896','','','127.0.0.1','111','Virtual','2016-05-31 10:11:12','2016-05-31 10:16:32',320,'','','',67090,92609,'','127.0.0.1','','Outbound-User','PPP','10.11.1.161',0,0,''),(6056,'70CB9915422AC5849540B503A8B21595','8b91dd33dde84c91','92685117','','','127.0.0.1','88','Virtual','2016-05-31 10:11:19','2016-05-31 11:01:31',3012,'','','',2382945,34332000,'','127.0.0.1','','Outbound-User','PPP','10.9.0.255',0,0,''),(6085,'EEE7DB8A6140CED089AECBDBBB85E457','4340cd6917d5e53b','38516185','','','127.0.0.1','89','Virtual','2016-05-31 10:14:11','2016-05-31 10:24:51',640,'','','',177680,506675,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(6099,'005E8C05D0E1018816E4E1B06EA2A6C2','8b31b3364a9b03ae','12299896','','','127.0.0.1','70','Virtual','2016-05-31 10:16:38','2016-05-31 10:19:45',187,'','','',48435,178229,'','127.0.0.1','','Outbound-User','PPP','10.9.1.136',0,0,''),(6190,'902EA5A89B943BD97E9017929CE8067D','5f83417459196669','15862857','','','127.0.0.1','119','Virtual','2016-05-31 10:23:21','2016-05-31 10:25:35',134,'','','',63124,26409,'','127.0.0.1','','Outbound-User','PPP','10.11.1.188',0,0,''),(6206,'3DAE7433725CDC3BE7DB68CC3498B113','95c52b50c0b7db8c','38516185','','','127.0.0.1','35','Virtual','2016-05-31 10:24:51','2016-05-31 10:36:50',719,'','','',350803,806242,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(6217,'17B088BB7DC7780E540829B02D25AE1D','a2492e1f68f33564','15862857','','','127.0.0.1','51','Virtual','2016-05-31 10:25:36','2016-05-31 10:27:22',106,'','','',17718,28465,'','127.0.0.1','','Outbound-User','PPP','10.11.1.188',0,0,''),(6473,'E4311071BD8A3118A1DC4DD6C3078C08','aa6d2c1eb66d3bee','74342763','','','127.0.0.1','127','Virtual','2016-05-31 10:48:27','2016-05-31 10:58:48',621,'','','',1126625,9335340,'','127.0.0.1','','Outbound-User','PPP','10.9.1.188',0,0,''),(6564,'52D0A03E605591540EE0B5B5AECDDB0C','62990063567050a9','74342763','','','127.0.0.1','115','Virtual','2016-05-31 10:58:51','2016-05-31 11:49:56',3065,'','','',7056631,72890620,'','127.0.0.1','','Outbound-User','PPP','10.11.1.208',0,0,''),(6708,'C51B40935ABB40B3B969BCC09EAE6070','4a7ab38accd649f8','38516185','','','127.0.0.1','73','Virtual','2016-05-31 11:05:05','2016-05-31 11:07:52',167,'','','',74850,933043,'','127.0.0.1','','Outbound-User','PPP','10.11.1.210',0,0,''),(6827,'80E90DD61E01B7ABA93E20B6B028B432','4d9f1ff5b781ae60','38516185','','','127.0.0.1','16','Virtual','2016-05-31 11:16:19','2016-05-31 11:19:05',166,'','','',49830,1364031,'','127.0.0.1','','Outbound-User','PPP','10.9.1.202',0,0,''),(6891,'4D07BCD700BD936BE100749D95812BE4','db491f55aec04bd2','38516185','','','127.0.0.1','83','Virtual','2016-05-31 11:23:56','2016-05-31 14:20:02',10566,'','','',138362,145221,'','127.0.0.1','','Outbound-User','PPP','10.11.1.210',0,0,''),(6955,'0421E55C230188CA96BA92B683D2EABA','9129415e7adec6e8','43371767','','','127.0.0.1','42','Virtual','2016-05-31 11:31:32','2016-05-31 11:51:53',1221,'','','',4110951,71616556,'','127.0.0.1','','Outbound-User','PPP','10.10.1.224',0,0,''),(7196,'242B4BA0364A2BE52337235511CC46DB','218f73b88ca39493','83338598','','','127.0.0.1','74','Virtual','2016-05-31 11:56:18','2016-05-31 11:58:46',148,'','','',35534,34478,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(7229,'E6408209A40AEE501342923253A0544B','82f494b41c14afb6','43371767','','','127.0.0.1','84','Virtual','2016-05-31 11:59:59','2016-05-31 12:17:19',1040,'','','',4536468,67038046,'','127.0.0.1','','Outbound-User','PPP','10.8.1.225',0,0,''),(7274,'6383684C7501DD258E15C4C3A415E380','a78b1d8b52b613d4','83338598','','','127.0.0.1','39','Virtual','2016-05-31 12:06:10','2016-05-31 12:20:00',830,'','','',157469,2011590,'','127.0.0.1','','Outbound-User','PPP','10.10.1.155',0,0,''),(7367,'5A8AEE5C04B0D443029E4B6E6A096012','3342bcf009f4bb42','43371767','','','127.0.0.1','52','Virtual','2016-05-31 12:18:26','2016-05-31 12:51:36',1990,'','','',3872149,93677664,'','127.0.0.1','','Outbound-User','PPP','10.8.1.225',0,0,''),(7381,'507CD00DED80AC185B37B991DA16DC22','56e315b01a38c2b0','83338598','','','127.0.0.1','49','Virtual','2016-05-31 12:21:38','2016-05-31 12:30:21',523,'','','',600533,11208178,'','127.0.0.1','','Outbound-User','PPP','10.11.1.126',0,0,''),(7416,'D25E893E52870D0628C14AC74DC20DA2','042066594cc93d56','83338598','','','127.0.0.1','4','Virtual','2016-05-31 12:31:20','2016-05-31 12:52:51',1291,'','','',1056996,14076698,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(8305,'CEA6ADB07EAC88BD1A20736CC008CD20','0fca74372a2ad031','72982617','','','127.0.0.1','42','Virtual','2016-05-31 14:10:01','2016-05-31 15:32:21',4940,'','','',17312040,300767169,'','127.0.0.1','','Outbound-User','PPP','10.10.1.252',0,0,''),(8344,'D13601092B331D4090CE02BA37571A88','d183ab47f546ee22','38516185','','','127.0.0.1','38','Virtual','2016-05-31 14:16:25','2016-05-31 16:47:21',9056,'','','',332420,3105673,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(8936,'54D3D0A38857E0EB007A655E30CD0A15','395fcb3ce35db65e','38516185','','','127.0.0.1','9','Virtual','2016-05-31 16:46:38','2016-05-31 18:51:52',7514,'','','',623325,6531011,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(9406,'0EC5D010EBEC6A071D183E30B9411401','5cf17f0ee2fdbebc','83338598','','','127.0.0.1','39','Virtual','2016-05-31 18:30:13','2016-05-31 18:48:28',1095,'','','',344725,10087988,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(9657,'0D4E2780738452C1A0E8CADDB1E469A1','a6764f01f30f76e1','38516185','','','127.0.0.1','80','Virtual','2016-05-31 18:51:08','2016-05-31 18:55:12',244,'','','',5105,6316,'','127.0.0.1','','Outbound-User','PPP','10.11.1.210',0,0,''),(9681,'18E4A605C46919DC6AEBE91A36501BCD','5dc8bca1ea1ae0e2','27969424','','','127.0.0.1','17','Virtual','2016-05-31 18:55:30','2016-05-31 19:13:54',1104,'','','',1432113,10700528,'','127.0.0.1','','Outbound-User','PPP','10.11.2.1',0,0,''),(9747,'DEB00355D24349BD0050033B8DD0D854','f105f89c5a25adfc','83338598','','','127.0.0.1','62','Virtual','2016-05-31 19:02:07','2016-05-31 19:04:26',139,'','','',22370,29987,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(9780,'79852586009B1603E4C0788BA3D8B0D1','b0cc45e10eefb5d6','83338598','','','127.0.0.1','58','Virtual','2016-05-31 19:04:32','2016-05-31 19:07:12',160,'','','',18797,27606,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(9865,'E25E3E8904214E9C059C41B893CB6211','c01e088d8484cb9c','27969424','','','127.0.0.1','88','Virtual','2016-05-31 19:13:10','2016-05-31 19:20:15',425,'','','',868340,19969717,'','127.0.0.1','','Outbound-User','PPP','10.10.2.15',0,0,''),(9883,'13B2B72CD070A0CECE307DBE354E6B21','1454b74bb0aed44d','38516185','','','127.0.0.1','73','Virtual','2016-05-31 19:16:03','2016-05-31 20:05:32',2969,'','','',1155112,6111102,'','127.0.0.1','','Outbound-User','PPP','10.9.1.202',0,0,''),(9920,'BC22BA28C3B5415C01909DA0539526A4','5ecba6dd6c08ed86','27969424','','','127.0.0.1','87','Virtual','2016-05-31 19:20:31','2016-05-31 21:10:06',6575,'','','',15052567,45182583,'','127.0.0.1','','Outbound-User','PPP','10.10.2.15',0,0,''),(10435,'91D5D241548A0AAE9632D70D3AD96DE0','761cf61d75bf4447','38516185','','','127.0.0.1','39','Virtual','2016-05-31 20:02:42','2016-05-31 20:42:18',2376,'','','',1486397,4388003,'','127.0.0.1','','Outbound-User','PPP','10.8.1.50',0,0,''),(10475,'03D803A4B04980A278B6C4DA888BA355','bc2503ea3b2bd908','72982617','','','127.0.0.1','58','Virtual','2016-05-31 20:05:59','2016-05-31 20:16:56',657,'','','',504047,1417494,'','127.0.0.1','','Outbound-User','PPP','10.10.1.252',0,0,''),(10486,'100ADBDDDE4E9D4C08AC000AEC5370E3','5af881cb7fbaf7f8','21538414','','','127.0.0.1','33','Virtual','2016-05-31 20:07:07','2016-05-31 20:24:13',1026,'','','',983123,5344591,'','127.0.0.1','','Outbound-User','PPP','10.9.2.16',0,0,''),(10622,'266D620062323D38D50D6406DCD4A5BD','4a457932b7ee2003','72982617','','','127.0.0.1','81','Virtual','2016-05-31 20:17:09','2016-05-31 20:22:12',303,'','','',49094,346083,'','127.0.0.1','','Outbound-User','PPP','10.9.1.151',0,0,''),(10671,'C069072A6A9DBAA93E10395700A5D966','f87db06a06e96fd1','83338598','','','127.0.0.1','115','Virtual','2016-05-31 20:21:21','2016-05-31 20:27:15',354,'','','',107991,361451,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(10699,'B420AC0A82B6BB007A82AD54B803E001','f11d50a26968eff5','45861198','','','127.0.0.1','72','Virtual','2016-05-31 20:23:57','2016-05-31 20:28:38',281,'','','',138196,102542,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(10761,'7416049BBBCB251D920E7CC094E35E38','4541e6f9a03712df','45861198','','','127.0.0.1','119','Virtual','2016-05-31 20:28:39','2016-05-31 20:34:26',347,'','','',1410036,15109989,'','127.0.0.1','','Outbound-User','PPP','10.8.2.37',0,0,''),(10887,'8D009902D91C3ED8B590C0466E650E41','9aad227bc2f874e0','45861198','','','127.0.0.1','38','Virtual','2016-05-31 20:34:28','2016-05-31 21:30:29',3361,'','','',1711684,4383836,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(10888,'C1406C4540B800B8B8AE823C056D2037','480e1139028e4e07','83338598','','','127.0.0.1','77','Virtual','2016-05-31 20:34:41','2016-05-31 20:49:26',885,'','','',91950,310908,'','127.0.0.1','','Outbound-User','PPP','10.9.1.122',0,0,''),(10938,'E030C04EC9A8C7604EE4CAE658072202','2098baac01e54d50','38516185','','','127.0.0.1','9','Virtual','2016-05-31 20:38:32','2016-05-31 20:39:04',32,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.1.47',0,0,''),(10944,'BAA78E20603E6AB6121C9B00409A3AD7','4586bcc4561d9a8d','38516185','','','127.0.0.1','54','Virtual','2016-05-31 20:39:10','2016-05-31 20:54:06',896,'','','',294220,2591303,'','127.0.0.1','','Outbound-User','PPP','10.9.1.202',0,0,''),(10996,'D070036D2BE29A940D9B74982578386B','35efb67d12d73927','54619857','','','127.0.0.1','39','Virtual','2016-05-31 20:42:22','2016-05-31 20:54:53',751,'','','',2489893,25884940,'','127.0.0.1','','Outbound-User','PPP','10.8.2.42',0,0,''),(11113,'AD52C38967E8567ECA0D0E658D9D4DA1','53077e6fb53140a0','42617612','','','127.0.0.1','68','Virtual','2016-05-31 20:51:12','2016-05-31 20:57:43',391,'','','',393182,1258171,'','127.0.0.1','','Outbound-User','PPP','10.8.2.46',0,0,''),(11123,'2450D2B981C00A5B7ECE59C0670A8C51','4f1fb635f81beedb','38516185','','','127.0.0.1','91','Virtual','2016-05-31 20:52:12','2016-05-31 20:55:32',200,'','','',122893,418874,'','127.0.0.1','','Outbound-User','PPP','10.11.1.210',0,0,''),(11177,'C1607D4D5D50BBDB7AB078B1C329B4B7','3df56b0606f5497e','38516185','','','127.0.0.1','58','Virtual','2016-05-31 20:55:39','2016-05-31 21:31:05',2126,'','','',847365,5840841,'','127.0.0.1','','Outbound-User','PPP','10.9.1.202',0,0,''),(11185,'CEEEA9DDAB1880BC5A70329B72AB361E','ebc87c1cabc8434a','54619857','','','127.0.0.1','104','Virtual','2016-05-31 20:55:58','2016-05-31 21:08:22',744,'','','',1348042,18268175,'','127.0.0.1','','Outbound-User','PPP','10.8.2.42',0,0,''),(11232,'2A547DDD3926BDD127DB43C409243A13','ce6113771797bfe8','42617612','','','127.0.0.1','56','Virtual','2016-05-31 20:59:01','2016-05-31 21:25:05',1564,'','','',1925684,8248270,'','127.0.0.1','','Outbound-User','PPP','10.9.2.31',0,0,''),(11298,'A460577D25B7CE95C4237D60E43DB79D','65e5c2758ed47aff','12299896','','','127.0.0.1','114','Virtual','2016-05-31 21:04:46','2016-05-31 21:08:10',204,'','','',2945,6152,'','127.0.0.1','','Outbound-User','PPP','10.8.1.132',0,0,''),(11309,'678E6AA0C472AC917A960666B4036313','567d0b0cf3231ba7','83338598','','','127.0.0.1','116','Virtual','2016-05-31 21:06:03','2016-05-31 21:11:35',332,'','','',14731,30125,'','127.0.0.1','','Outbound-User','PPP','10.8.1.121',0,0,''),(11319,'BE4D093599BE108E3E6046ACA63A60DB','7c986a2f9105daaa','12299896','','','127.0.0.1','47','Virtual','2016-05-31 21:07:07','2016-05-31 21:07:54',47,'','','',1558,4239,'','127.0.0.1','','Outbound-User','PPP','10.11.1.161',0,0,''),(11345,'91BB6758E133A004073DA224882C8C69','12ea11673aa699b5','72982617','','','127.0.0.1','90','Virtual','2016-05-31 21:09:39','2016-05-31 21:11:39',120,'','','',503434,106182,'','127.0.0.1','','Outbound-User','PPP','10.9.1.151',0,0,''),(11618,'D644A29AB5A0705BCAB574D460103B1A','c9eabe24b02bbce9','45861198','','','127.0.0.1','69','Virtual','2016-05-31 21:31:34','2016-05-31 21:31:37',3,'','','',1356,3537,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(11620,'062AC7D55C11C92245B058D249012DB4','74806061cf7ce7a5','45861198','','','127.0.0.1','56','Virtual','2016-05-31 21:31:47','2016-05-31 21:31:48',1,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11623,'37240AD4BA612685E2237E7C1E2AE191','70b393121275e81e','45861198','','','127.0.0.1','49','Virtual','2016-05-31 21:32:03','2016-05-31 21:32:04',1,'','','',1272,3147,'','127.0.0.1','','Outbound-User','PPP','10.8.2.37',0,0,''),(11627,'8CEB80EDE09E7616054DD3CE603A0143','9473546687c6c293','45861198','','','127.0.0.1','49','Virtual','2016-05-31 21:32:22','2016-05-31 21:32:23',1,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.8.2.37',0,0,''),(11633,'08C0482894461D1B91780CA8171D0104','fc97be7d8b53e7fc','45861198','','','127.0.0.1','117','Virtual','2016-05-31 21:32:50','2016-05-31 21:32:52',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.2.63',0,0,''),(11641,'B336C5015C076E18785B9AAB8EB43962','2762e6268a15bc8b','45861198','','','127.0.0.1','99','Virtual','2016-05-31 21:33:15','2016-05-31 21:33:17',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(11647,'50215B93480B2DB7E80CC7D197EA2506','ae2f1303f1e510af','45861198','','','127.0.0.1','117','Virtual','2016-05-31 21:34:02','2016-05-31 21:34:03',1,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.8.2.37',0,0,''),(11652,'388650BE240E70018B410A0851590328','b059524cfb126539','45861198','','','127.0.0.1','119','Virtual','2016-05-31 21:34:33','2016-05-31 21:34:35',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11656,'57CE0DDA557687024D2366C079147886','b1248e7d2ee1a7e8','45861198','','','127.0.0.1','119','Virtual','2016-05-31 21:34:47','2016-05-31 21:34:48',1,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11669,'501668CB63934B09435C26A91D8A4AB7','98990b1d9925f837','45861198','','','127.0.0.1','99','Virtual','2016-05-31 21:35:44','2016-05-31 21:35:46',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(11673,'C18E63CD517D38C0E2D1006676050216','6c23622ef9516be9','45861198','','','127.0.0.1','114','Virtual','2016-05-31 21:36:08','2016-05-31 21:36:09',1,'','','',1272,3147,'','127.0.0.1','','Outbound-User','PPP','10.10.2.63',0,0,''),(11680,'CA58C4A8BB7A00BA154D00A760013A07','ee60d16b67184811','45861198','','','127.0.0.1','44','Virtual','2016-05-31 21:36:43','2016-05-31 21:36:45',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11681,'1A45C3782114525508D2A0155AE108CB','7c9a43d953c17291','45861198','','','127.0.0.1','90','Virtual','2016-05-31 21:36:57','2016-05-31 21:36:58',1,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.2.63',0,0,''),(11688,'C0C7D323AABA7A2C91D8B2C03D7205BA','c848303660cc9082','45861198','','','127.0.0.1','44','Virtual','2016-05-31 21:38:18','2016-05-31 21:38:20',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11706,'49C410D5AB217351BEAB8883CD2C9840','382ecfc9faefa820','45861198','','','127.0.0.1','100','Virtual','2016-05-31 21:39:55','2016-05-31 21:39:57',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.2.35',0,0,''),(11717,'573E20003D7C40802E51D3E0D2DE002E','2250c6c5a06dca15','45861198','','','127.0.0.1','114','Virtual','2016-05-31 21:40:48','2016-05-31 21:40:50',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.2.63',0,0,''),(11724,'663D5672E7DDB47902E6EC906725D97E','d8d5c8b0dae7d5c7','45861198','','','127.0.0.1','114','Virtual','2016-05-31 21:41:34','2016-05-31 21:41:36',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.2.63',0,0,''),(11767,'CE67C41C71ACD7792381D460770E3955','f3bc44be2a716755','45861198','','','127.0.0.1','117','Virtual','2016-05-31 21:43:57','2016-05-31 21:44:41',44,'','','',23150,12768,'','127.0.0.1','','Outbound-User','PPP','10.9.2.38',0,0,''),(11832,'EAEB7CB2E68D5A0C221BD1DC55E8026C','662a410b6c591679','t','','','127.0.0.1','1','Virtual','2016-06-01 11:55:03','2016-06-01 11:55:06',3,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,''),(11833,'138BA29215B492B531487171A0704AC4','9b0f2b09ec110796','r','','','127.0.0.1','1','Virtual','2016-06-01 11:55:39','2016-06-01 11:55:41',2,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.9.0.6',0,0,''),(11834,'C69392B2904EB6C6221E02440BA2877B','94dbcf5b8d5eca57','t','','','127.0.0.1','1','Virtual','2016-06-01 12:09:57','2016-06-01 12:13:17',200,'','','',55933,5733,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,''),(11835,'659ACE492A021A0A5A9D64990E7EB917','ad6d781f18ba55f3','t','','','127.0.0.1','1','Virtual','2016-06-01 12:13:38','2016-06-01 12:14:46',68,'','','',6904,4892,'','127.0.0.1','','Outbound-User','PPP','10.9.0.7',0,0,''),(11836,'9A60AE170A7AE1A7193740A0080A8C16','119f2ac8d047baff','t','','','127.0.0.1','1','Virtual','2016-06-01 12:22:00','2016-06-01 12:22:29',29,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.0.5',0,0,''),(11837,'7720EEDB871DB2E1052743256B67E4C1','055e76946f9ed5bb','t','','','127.0.0.1','1','Virtual','2016-06-01 12:55:36','2016-06-01 12:57:19',103,'','','',14873,5277,'','127.0.0.1','','Outbound-User','PPP','10.10.0.5',0,0,''),(11839,'EB89A308967343BE30D69DA059CB1AC4','2ed2236e54a2c916','t','','','127.0.0.1','1','Virtual','2016-06-01 13:04:05','2016-06-01 13:20:58',1013,'','','',247542,10243,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,''),(11840,'D4EE9090DD1A62E41431CDC08E1324CD','ca4e58089c399682','t','','','127.0.0.1','1','Virtual','2016-06-01 13:21:37','2016-06-01 13:22:58',81,'','','',9353,5112,'','127.0.0.1','','Outbound-User','PPP','10.10.0.5',0,0,''),(11841,'78E528C506E7E706785E0288D171A481','330ab41c4a761a5f','t','','','127.0.0.1','1','Virtual','2016-06-01 13:23:30','2016-06-01 13:24:34',64,'','','',3053,4837,'','127.0.0.1','','Outbound-User','PPP','10.9.0.7',0,0,''),(11842,'91AA0A139ABA003E3A4CC2A6E3A544C5','56eeebf1dabf7eb0','t','','','127.0.0.1','1','Virtual','2016-06-01 13:24:55','2016-06-01 13:25:00',5,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.0.7',0,0,''),(11844,'91D4D26C237D670EC227A7E986200CA3','8c67c9efa656b8f3','t','','','127.0.0.1','1','Virtual','2016-06-01 13:25:12','2016-06-01 13:27:44',152,'','','',21244,6381,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,NULL),(11845,'A25B9A1C60B95B077CD9B5C8078A06B3','a6f4c4c285ed6d95','t','','','127.0.0.1','1','Virtual','2016-06-01 13:27:45','2016-06-01 13:36:14',509,'','','',46692,7422,'','127.0.0.1','','Outbound-User','PPP','10.11.0.7',0,0,''),(11846,'E6E02E5A7AAD10C1A1602E50E26A8EAB','192dfd52efcdf1b4','t','','','127.0.0.1','1','Virtual','2016-06-01 13:27:46','2016-06-01 13:36:33',527,'','','',90290,8200,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,''),(11847,'3D002D038AC308502E42962915A15B62','928d268f7d53a750','t','','','127.0.0.1','1','Virtual','2016-06-01 13:36:22','2016-06-01 14:22:54',2792,'','','',243666,19742,'','127.0.0.1','','Outbound-User','PPP','10.10.0.5',0,0,''),(11848,'8173B074CDD08755BBD006B94C72AE64','a24ce6f465d89e75','t','','','127.0.0.1','1','Virtual','2016-06-01 14:52:17','2016-06-01 15:20:26',1689,'','','',218512,13692,'','127.0.0.1','','Outbound-User','PPP','10.11.0.7',0,0,''),(11849,'51805B036650378C73493359D72CB273','a1c0dbfde365e603','t','','','127.0.0.1','1','Virtual','2016-06-01 15:20:28',NULL,1260,'','','',390583,23255,'','127.0.0.1','','Outbound-User','PPP','10.9.0.7',0,0,''),(11850,'2E8AA9733E2BE0002C8178974562880D','d04d38175420da17','t','','','127.0.0.1','1','Virtual','2016-06-01 15:43:51','2016-06-01 15:45:09',78,'','','',42541,5073,'','127.0.0.1','','Outbound-User','PPP','10.8.0.8',0,0,''),(11851,'9968CA0919040802ABA43922938C65B2','5ff92c333bac8c4d','t','','','127.0.0.1','1','Virtual','2016-06-01 15:53:32','2016-06-01 16:07:40',848,'','','',311274,9182,'','127.0.0.1','','Outbound-User','PPP','10.10.0.5',0,0,''),(11852,'74BED4AC5375B296AB7B4E6E240ADB5C','f71eeaa4f2a98fba','0000','','','127.0.0.1','1','Virtual','2016-06-01 16:10:58',NULL,120,'','','',16302,5057,'','127.0.0.1','','Outbound-User','PPP','10.11.0.8',0,0,''),(11853,'0E2483614735B1B4C60B1C9566484CBA','7d5991f2ad736019','0000','','','127.0.0.1','1','Virtual','2016-06-01 16:24:07','2016-06-01 16:24:48',41,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.0.6',0,0,''),(11854,'E198234EE48A8B6C4C908165669CD7B0','4a7f29580a4103ea','0000','','','127.0.0.1','1','Virtual','2016-06-02 00:24:23','2016-06-02 00:24:57',34,'','','',21420,4892,'','127.0.0.1','','Outbound-User','PPP','10.10.0.6',0,0,''),(11855,'3B9801B542701D75B04B4CE0C73607E0','fb18c0b1d21dcf14','111','','','127.0.0.1','1','Virtual','2016-06-02 01:09:43',NULL,720,'','','',59762,8412,'','127.0.0.1','','Outbound-User','PPP','10.10.0.7',0,0,''),(11856,'983C0ADAD0C53A89944851CB87626A5E','07a207e2151dd2db','111','','','127.0.0.1','1','Virtual','2016-06-02 01:24:53','2016-06-02 01:26:36',103,'','','',13430,5073,'','127.0.0.1','','Outbound-User','PPP','10.8.0.9',0,0,''),(11857,'A50082039E63769C6E65A5B74A068470','234dd7d636791281','111','','','127.0.0.1','1','Virtual','2016-06-02 01:26:44','2016-06-02 02:02:32',2148,'','','',435579,70931,'','127.0.0.1','','Outbound-User','PPP','10.9.0.8',0,0,''),(11858,'67D06C2A95890D2BE5760C98455BC772','290fa404f590697b','111','','','127.0.0.1','1','Virtual','2016-06-02 02:02:46','2016-06-02 02:05:15',149,'','','',16332,5387,'','127.0.0.1','','Outbound-User','PPP','10.10.0.7',0,0,''),(11859,'DA4AC7703A880725BE8461BCE7630E80','ad117f3daf87d204','111','','','127.0.0.1','1','Virtual','2016-06-02 02:05:28','2016-06-02 02:05:35',7,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.0.9',0,0,''),(11860,'3069096B198B308C7D3994919AA0000D','e5d966fc7c335ae2','111','','','127.0.0.1','1','Virtual','2016-06-02 02:05:45','2016-06-02 02:40:01',2056,'','','',148817,15876,'','127.0.0.1','','Outbound-User','PPP','10.8.0.9',0,0,''),(11861,'17C69AE84C9CE7829B1D1CAAB10DC5B1','c9518b3a72ee6fa8','0000','','','127.0.0.1','1','Virtual','2016-06-02 03:25:31','2016-06-02 03:58:56',2005,'','','',381359,15452,'','127.0.0.1','','Outbound-User','PPP','10.9.0.9',0,0,''),(11862,'C12DA024DD4C2C029044448011B00A70','67f0c0a233e109cb','222','','','127.0.0.1','1','Virtual','2016-06-02 04:16:10','2016-06-02 04:16:36',26,'','','',3550,7086,'','127.0.0.1','','Outbound-User','PPP','10.11.0.10',0,0,''),(11863,'20678D925220D43C5395DA312116D6EC','b736ac2ba45d8c9d','222','','','127.0.0.1','1','Virtual','2016-06-02 05:20:23','2016-06-02 05:24:01',218,'','','',35650,6671,'','127.0.0.1','','Outbound-User','PPP','10.11.0.10',0,0,''),(11864,'9BC99273A81CB5500B6D506A4BD05042','7b3442ab726b48dc','222','','','127.0.0.1','1','Virtual','2016-06-02 05:24:25','2016-06-02 05:29:36',311,'','','',12797,6212,'','127.0.0.1','','Outbound-User','PPP','10.9.0.10',0,0,''),(11865,'E3C043D25276CB61A78295D316C60C04','4da68b74cd8b34ff','222','','','127.0.0.1','1','Virtual','2016-06-02 05:25:46','2016-06-02 05:25:50',4,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.10.0.8',0,0,''),(11866,'364C430475C16AA07C01AD59193C9BC0','c687542c05a40909','222','','','127.0.0.1','1','Virtual','2016-06-02 05:25:56','2016-06-02 05:26:00',4,'','','',0,0,'','127.0.0.1','','Outbound-User','PPP','10.11.0.10',0,0,''),(11867,'15804968983DE4B57945CC60B5A5CCA6','45cc8a26858afbc6','222','','','127.0.0.1','1','Virtual','2016-06-02 05:26:04',NULL,960,'','','',479298,118524,'','127.0.0.1','','Outbound-User','PPP','10.8.0.10',0,0,''),(11868,'50AC07905CB9E325440B75630DD68900','721352b8fb7439e5','222','','','127.0.0.1','1','Virtual','2016-06-02 05:46:00',NULL,1440,'','','',1171348,186955,'','127.0.0.1','','Outbound-User','PPP','10.8.0.10',0,0,''),(11869,'6E4A0B086A6E0E2AE8BB83CC46A53163','2bf84a1f0f95fbf4','222','','','127.0.0.1','1','Virtual','2016-06-02 06:13:46','2016-06-02 06:18:31',285,'','','',92756,254747,'','127.0.0.1','','Outbound-User','PPP','10.8.0.10',0,0,''),(11870,'08ACDD795102E0D7BD15CCE17CCD0174','f79241c718b817ba','222','','','127.0.0.1','1','Virtual','2016-06-02 06:16:36','2016-06-02 06:49:16',1960,'','','',360411,767424,'','127.0.0.1','','Outbound-User','PPP','10.11.0.10',0,0,'');
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES (3,'test','Password','==','test'),(4,'111','Cleartext-Password',':=','111'),(5,'222','Cleartext-Password',':=','222'),(6,'333','User-Password',':=','333'),(7,'444','User-Password',':=','444'),(8,'t','Cleartext-Password',':=','t'),(10,'0000','Cleartext-Password',':=','0000');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
INSERT INTO `radgroupcheck` VALUES (101,'30day6G','Max-Active-Days',':=','30'),(1,'1day500M','Max-Active-Days',':=','1'),(2,'1day500M','Max-Global-Traffic',':=','500'),(102,'30day6G','Max-Global-Traffic',':=','6144'),(104,'30day12G','Max-Global-Traffic',':=','12288'),(103,'30day12G','Max-Active-Days',':=','30'),(106,'15day','Max-Active-Days',':=','15'),(105,'30day','Max-Active-Days',':=','30');
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radhuntgroup`
--

DROP TABLE IF EXISTS `radhuntgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radhuntgroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nasipaddress` (`nasipaddress`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radhuntgroup`
--

LOCK TABLES `radhuntgroup` WRITE;
/*!40000 ALTER TABLE `radhuntgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `radhuntgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radippool`
--

DROP TABLE IF EXISTS `radippool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radippool` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pool_name` varchar(30) NOT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `calledstationid` varchar(30) NOT NULL,
  `callingstationid` varchar(30) NOT NULL,
  `expiry_time` datetime DEFAULT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pool_key` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `radippool_poolname_expire` (`pool_name`,`expiry_time`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `radippool_nasip_poolkey_ipaddress` (`nasipaddress`,`pool_key`,`framedipaddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radippool`
--

LOCK TABLES `radippool` WRITE;
/*!40000 ALTER TABLE `radippool` DISABLE KEYS */;
/*!40000 ALTER TABLE `radippool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14831 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
INSERT INTO `radpostauth` VALUES (9,'19354745','73622446','Access-Reject','2016-05-30 14:49:58'),(10,'19354745','73622446','Access-Reject','2016-05-30 14:49:59'),(11,'19354745','73622446','Access-Reject','2016-05-30 14:50:30'),(12,'19354745','73622446','Access-Reject','2016-05-30 14:50:31'),(13,'94555631','321227375','Access-Reject','2016-05-30 14:50:42'),(14,'94555631','321227375','Access-Reject','2016-05-30 14:50:43'),(15,'35932776','45619465','Access-Reject','2016-05-30 14:51:47'),(16,'35932776','45619465','Access-Reject','2016-05-30 14:51:48'),(17,'35932776','45619465','Access-Reject','2016-05-30 14:51:59'),(18,'35932776','45619465','Access-Reject','2016-05-30 14:52:00'),(19,'19354745','73622446','Access-Reject','2016-05-30 14:52:06'),(20,'19354745','73622446','Access-Reject','2016-05-30 14:52:07'),(21,'35932776','45619465','Access-Reject','2016-05-30 14:52:19'),(22,'35932776','45619465','Access-Reject','2016-05-30 14:52:20'),(23,'35932776','45619465','Access-Reject','2016-05-30 14:52:36'),(24,'35932776','45619465','Access-Reject','2016-05-30 14:52:37'),(25,'61473489','39361948','Access-Reject','2016-05-30 14:55:21'),(26,'61473489','39361948','Access-Reject','2016-05-30 14:55:22'),(27,'16889572','46662582','Access-Reject','2016-05-30 14:56:57'),(28,'16889572','46662582','Access-Reject','2016-05-30 14:56:58'),(29,'11624252','73444686','Access-Reject','2016-05-30 15:14:02'),(30,'11624252','73444686','Access-Reject','2016-05-30 15:14:03'),(33,'93697743','42277269','Access-Reject','2016-05-30 15:30:54'),(34,'93697743','42277269','Access-Reject','2016-05-30 15:30:55'),(39,'15852773','61672457','Access-Reject','2016-05-30 15:37:23'),(40,'15852773','61672457','Access-Reject','2016-05-30 15:37:24'),(41,'15852773','61672457','Access-Reject','2016-05-30 15:37:36'),(42,'15852773','61672457','Access-Reject','2016-05-30 15:37:37'),(43,'145315843','16663761','Access-Reject','2016-05-30 15:38:11'),(45,'15852773','61672457','Access-Reject','2016-05-30 15:38:29'),(46,'15852773','61672457','Access-Reject','2016-05-30 15:38:30'),(47,'15852773','61672457','Access-Reject','2016-05-30 15:38:43'),(49,'15852773','61672457','Access-Reject','2016-05-30 15:39:13'),(50,'15852773','61672457','Access-Reject','2016-05-30 15:39:14'),(51,'15852773','61672457','Access-Reject','2016-05-30 15:39:47'),(52,'15852773','61672457','Access-Reject','2016-05-30 15:39:48'),(53,'15852773','61672457','Access-Reject','2016-05-30 15:40:12'),(54,'15852773','61672457','Access-Reject','2016-05-30 15:40:35'),(55,'15852773','61672457','Access-Reject','2016-05-30 15:40:36'),(56,'15852773','61672457','Access-Reject','2016-05-30 15:41:06'),(57,'15852773','61672457','Access-Reject','2016-05-30 15:41:07'),(80,'79327594','43476544','Access-Reject','2016-05-30 15:53:24'),(81,'79327594','43476544','Access-Reject','2016-05-30 15:53:25'),(157,'1148229060@qq.com','qwerty','Access-Reject','2016-05-30 16:16:59'),(158,'1148229060@qq.com','qwerty','Access-Reject','2016-05-30 16:17:00'),(228,'84151717','26263215','Access-Reject','2016-05-30 17:46:50'),(347,'92151535','33782326','Access-Reject','2016-05-30 22:54:38'),(348,'92151535','33782326','Access-Reject','2016-05-30 22:54:39'),(351,'41456481','27755445','Access-Reject','2016-05-30 22:55:43'),(352,'41456481','27755445','Access-Reject','2016-05-30 22:55:44'),(353,'41456481','27755445','Access-Reject','2016-05-30 22:55:54'),(354,'41456481','27755445','Access-Reject','2016-05-30 22:55:55'),(358,'84151717','12393397','Access-Reject','2016-05-30 22:58:47'),(359,'84151717','12393397','Access-Reject','2016-05-30 22:58:48'),(360,'84151717','12393397','Access-Reject','2016-05-30 22:59:09'),(361,'84151717','12393392','Access-Reject','2016-05-30 22:59:51'),(363,'84151717','12393392','Access-Reject','2016-05-30 23:00:23'),(364,'84151717','12393392','Access-Reject','2016-05-30 23:00:24'),(367,'84151717','12393392','Access-Reject','2016-05-30 23:00:38'),(368,'84151717','12393392','Access-Reject','2016-05-30 23:00:39'),(370,'12393392','84151717','Access-Reject','2016-05-30 23:02:57'),(371,'12393392','84151717','Access-Reject','2016-05-30 23:02:58'),(374,'3464469','12393392','Access-Reject','2016-05-30 23:04:52'),(375,'3464469','12393392','Access-Reject','2016-05-30 23:04:53'),(406,'59889948','99123271','Access-Reject','2016-05-30 23:21:04'),(407,'59889948','99123271','Access-Reject','2016-05-30 23:21:05'),(408,'59889948','99123271','Access-Reject','2016-05-30 23:21:20'),(409,'59889948','99123271','Access-Reject','2016-05-30 23:21:31'),(410,'59889948','99123271','Access-Reject','2016-05-30 23:21:43'),(448,'43854595','13463438','Access-Reject','2016-05-30 23:47:54'),(449,'43854595','13463438','Access-Reject','2016-05-30 23:47:55'),(470,'24599737','77746512','Access-Reject','2016-05-30 23:53:42'),(473,'97989458','61866415','Access-Reject','2016-05-30 23:54:07'),(475,'97989458','61866415','Access-Reject','2016-05-30 23:54:20'),(485,'97989458','61866415','Access-Reject','2016-05-30 23:56:06'),(567,'43854595','13463438','Access-Reject','2016-05-31 00:21:14'),(572,'43854595','13463438','Access-Reject','2016-05-31 00:23:01'),(575,'43854595','13463438','Access-Reject','2016-05-31 00:23:09'),(593,'58364587','986995945','Access-Reject','2016-05-31 00:28:08'),(594,'58364587','986995945','Access-Reject','2016-05-31 00:28:09'),(619,'15249288','36166791','Access-Reject','2016-05-31 00:33:19'),(620,'15249288','36166791','Access-Reject','2016-05-31 00:33:30'),(635,'12759651','76177885','Access-Reject','2016-05-31 00:38:13'),(636,'12759651','76177885','Access-Reject','2016-05-31 00:38:14'),(637,'12759651','76177885','Access-Reject','2016-05-31 00:38:25'),(640,'12759651','76177885','Access-Reject','2016-05-31 00:39:00'),(641,'12759651','76177885','Access-Reject','2016-05-31 00:39:01'),(653,'57161781','67483944','Access-Reject','2016-05-31 00:43:03'),(686,'111114759','62447662','Access-Reject','2016-05-31 00:51:20'),(689,'111114759','62447662','Access-Reject','2016-05-31 00:51:31'),(692,'111114759','62447622','Access-Reject','2016-05-31 00:52:00'),(723,'12759651','76177885','Access-Reject','2016-05-31 00:58:31'),(791,'52454158','62881263','Access-Reject','2016-05-31 01:19:38'),(792,'52454158','62881263','Access-Reject','2016-05-31 01:19:52'),(797,'52454158','62881263','Access-Reject','2016-05-31 01:20:29'),(798,'52454158','62881263','Access-Reject','2016-05-31 01:20:30'),(799,'52454158','62881263','Access-Reject','2016-05-31 01:20:58'),(806,'33722859','13444498','Access-Reject','2016-05-31 01:23:35'),(850,'33722859','13444498','Access-Reject','2016-05-31 01:31:59'),(852,'33722859','13444498','Access-Reject','2016-05-31 01:32:25'),(914,'15669575','56298571','Access-Reject','2016-05-31 01:45:51'),(1050,'21557677','17363758','Access-Reject','2016-05-31 02:19:16'),(1053,'21557677','17363758','Access-Reject','2016-05-31 02:19:27'),(1057,'21557677','17363758','Access-Reject','2016-05-31 02:19:51'),(1059,'21557677','17363758','Access-Reject','2016-05-31 02:20:02'),(1089,'46973583','21356387','Access-Reject','2016-05-31 02:26:01'),(1091,'46973583','21356387','Access-Reject','2016-05-31 02:26:12'),(1093,'46973583','21356387','Access-Reject','2016-05-31 02:26:23'),(1098,'32142128','32165176','Access-Reject','2016-05-31 02:27:59'),(1100,'46973583','21356387','Access-Reject','2016-05-31 02:28:09'),(1102,'46973583','21356387','Access-Reject','2016-05-31 02:28:31'),(1610,'67482944','541617','Access-Reject','2016-05-31 04:08:31'),(1613,'67482944','541617','Access-Reject','2016-05-31 04:09:16'),(1694,'29647828','41987254','Access-Reject','2016-05-31 04:25:34'),(1695,'29647828','41987254','Access-Reject','2016-05-31 04:25:47'),(1705,'29647828','41987254','Access-Reject','2016-05-31 04:26:02'),(1712,'1148229060@qq.com','qwerty','Access-Reject','2016-05-31 04:26:56'),(1723,'5472740','5991491','Access-Reject','2016-05-31 04:29:09'),(1725,'5472740','5991491','Access-Reject','2016-05-31 04:29:25'),(1729,'5472740','5991491','Access-Reject','2016-05-31 04:29:58'),(1730,'5472740','5991491','Access-Reject','2016-05-31 04:29:59'),(1731,'5472740','5991491','Access-Reject','2016-05-31 04:30:11'),(1736,'5472740','5991491','Access-Reject','2016-05-31 04:30:36'),(1742,'5472740','5991491','Access-Reject','2016-05-31 04:30:58'),(1744,'5472740','5991491','Access-Reject','2016-05-31 04:31:21'),(1745,'5472740','5991491','Access-Reject','2016-05-31 04:31:22'),(1780,'86519148','19718474','Access-Reject','2016-05-31 04:35:25'),(1782,'86519148','19718474','Access-Reject','2016-05-31 04:35:39'),(1799,'86519148','19718474','Access-Reject','2016-05-31 04:38:13'),(1802,'86519148','19718474','Access-Reject','2016-05-31 04:38:29'),(1831,'13314256','9564283','Access-Reject','2016-05-31 04:40:54'),(1842,'13314256','95642483','Access-Reject','2016-05-31 04:41:38'),(1854,'13314256','95642483','Access-Reject','2016-05-31 04:42:38'),(1919,'13314256','95642483','Access-Reject','2016-05-31 04:46:28'),(2364,'13314256','95642483','Access-Reject','2016-05-31 04:58:01'),(2417,'69386377','43712737','Access-Reject','2016-05-31 05:05:36'),(2418,'24599737','77746512','Access-Reject','2016-05-31 05:05:39'),(2419,'24599737','77746512','Access-Reject','2016-05-31 05:05:40'),(2424,'24599737','77746512','Access-Reject','2016-05-31 05:06:00'),(2425,'69386377','43712737','Access-Reject','2016-05-31 05:06:13'),(2426,'24599737','77746512','Access-Reject','2016-05-31 05:06:15'),(2432,'24599737','77746512','Access-Reject','2016-05-31 05:06:56'),(2439,'69386377','43712737','Access-Reject','2016-05-31 05:08:02'),(2456,'24599737','77746512','Access-Reject','2016-05-31 05:10:37'),(2458,'24599737','77746512','Access-Reject','2016-05-31 05:11:02'),(2463,'24599737','77746512','Access-Reject','2016-05-31 05:11:28'),(2465,'24599737','77746512','Access-Reject','2016-05-31 05:11:29'),(2481,'24599737','77746512','Access-Reject','2016-05-31 05:14:03'),(2535,'2554277','34546337','Access-Reject','2016-05-31 05:25:24'),(2600,'66275821','19348242','Access-Reject','2016-05-31 05:37:43'),(2605,'66275821','19348242','Access-Reject','2016-05-31 05:37:59'),(2606,'9222418','76769979','Access-Reject','2016-05-31 05:38:02'),(2612,'9222418','76769979','Access-Reject','2016-05-31 05:38:40'),(2613,'9222418','76769979','Access-Reject','2016-05-31 05:38:50'),(2616,'9222418','76769979','Access-Reject','2016-05-31 05:39:02'),(2621,'9222418','76769979','Access-Reject','2016-05-31 05:39:48'),(2625,'9222418','76769979','Access-Reject','2016-05-31 05:40:10'),(2627,'9222418','76769979','Access-Reject','2016-05-31 05:40:22'),(2632,'61341918','23792184','Access-Reject','2016-05-31 05:40:47'),(2690,'9222418','76769979','Access-Reject','2016-05-31 05:53:02'),(2694,'9222418','76769979','Access-Reject','2016-05-31 05:53:17'),(2857,'44891678','26695513','Access-Reject','2016-05-31 06:17:39'),(2861,'44891678','26695513','Access-Reject','2016-05-31 06:17:50'),(2864,'44891678','26695513','Access-Reject','2016-05-31 06:18:00'),(2867,'44891678','26695513','Access-Reject','2016-05-31 06:18:15'),(2891,'17319175','18985993','Access-Reject','2016-05-31 06:21:24'),(2901,'57749318','95652427','Access-Reject','2016-05-31 06:22:55'),(2907,'57749318','95652427','Access-Reject','2016-05-31 06:23:39'),(2909,'57749318','95652427','Access-Reject','2016-05-31 06:23:50'),(2910,'57749318','95652427','Access-Reject','2016-05-31 06:24:01'),(2911,'57749318','95652427','Access-Reject','2016-05-31 06:24:13'),(2936,'59889948','99123271','Access-Reject','2016-05-31 06:28:20'),(3060,'9222418','76769979','Access-Reject','2016-05-31 06:47:12'),(3244,'36370897','45065262','Access-Reject','2016-05-31 06:52:50'),(3247,'36370897','45065262','Access-Reject','2016-05-31 06:52:51'),(3258,'36370897','45065262','Access-Reject','2016-05-31 06:53:01'),(3506,'5472740','5991491','Access-Reject','2016-05-31 07:01:21'),(3528,'5472740','5991491','Access-Reject','2016-05-31 07:03:36'),(3539,'5472740','5991491','Access-Reject','2016-05-31 07:06:04'),(3543,'5472740','5991491','Access-Reject','2016-05-31 07:06:42'),(3545,'5472740','5991491','Access-Reject','2016-05-31 07:07:09'),(3557,'5472740','5991491','Access-Reject','2016-05-31 07:08:35'),(3558,'5472740','5991491','Access-Reject','2016-05-31 07:08:36'),(3564,'5472740','5991491','Access-Reject','2016-05-31 07:09:27'),(3565,'5472740','5991491','Access-Reject','2016-05-31 07:09:28'),(3671,' 71388278','46671375','Access-Reject','2016-05-31 07:27:52'),(3672,' 71388278','46671375','Access-Reject','2016-05-31 07:27:53'),(3676,' 71388278','46671375','Access-Reject','2016-05-31 07:28:34'),(3678,' 71388278','46671375','Access-Reject','2016-05-31 07:28:57'),(3679,' 71388278','46671375','Access-Reject','2016-05-31 07:28:58'),(3681,' 71388278','46671375','Access-Reject','2016-05-31 07:29:11'),(3686,' 71388278','46671375','Access-Reject','2016-05-31 07:30:26'),(3688,' 71388278','46671375','Access-Reject','2016-05-31 07:30:41'),(3699,' 71388278','46671375','Access-Reject','2016-05-31 07:33:25'),(3702,' 71388278','46671375','Access-Reject','2016-05-31 07:33:42'),(3703,' 71388278','46671375','Access-Reject','2016-05-31 07:34:07'),(3718,'52527327','58565213','Access-Reject','2016-05-31 07:36:16'),(3779,'5472740','5991491','Access-Reject','2016-05-31 07:48:12'),(3784,'5472740','5991491','Access-Reject','2016-05-31 07:48:59'),(3793,'5472740','5991491','Access-Reject','2016-05-31 07:50:15'),(3798,'5472740','5991491','Access-Reject','2016-05-31 07:50:49'),(3800,'5472740','5991491','Access-Reject','2016-05-31 07:51:00'),(3802,'5472740','5991491','Access-Reject','2016-05-31 07:51:15'),(4021,'5472740','5991491','Access-Reject','2016-05-31 08:24:40'),(4128,'5472853','6357602','Access-Reject','2016-05-31 08:40:58'),(4129,'5472853','6357602','Access-Reject','2016-05-31 08:41:10'),(4152,'5472853','6357602','Access-Reject','2016-05-31 08:44:22'),(4154,'5472853','6357602','Access-Reject','2016-05-31 08:44:33'),(4156,'5472853','6357602','Access-Reject','2016-05-31 08:44:43'),(4174,'69833172','48847798','Access-Reject','2016-05-31 08:47:31'),(4176,'69833172','48847798','Access-Reject','2016-05-31 08:47:42'),(4177,'69833172','48847798','Access-Reject','2016-05-31 08:47:50'),(4179,'69833172','48847798','Access-Reject','2016-05-31 08:48:09'),(4182,'69833172','48847798','Access-Reject','2016-05-31 08:48:20'),(4188,'69833172','48847798','Access-Reject','2016-05-31 08:48:39'),(4197,'69833172','48847798','Access-Reject','2016-05-31 08:49:44'),(4198,'69833172','48847798','Access-Reject','2016-05-31 08:49:56'),(4204,'69833172','48847798','Access-Reject','2016-05-31 08:50:18'),(4208,'69833172','48847798','Access-Reject','2016-05-31 08:50:39'),(4211,'69833172','48847798','Access-Reject','2016-05-31 08:50:51'),(4219,'69833172','48847798','Access-Reject','2016-05-31 08:51:41'),(4274,'79194653','12766269','Access-Reject','2016-05-31 08:58:29'),(4375,'69833172','48847798','Access-Reject','2016-05-31 09:14:08'),(4379,'69833172','48847798','Access-Reject','2016-05-31 09:14:20'),(4398,'69833172','48847798','Access-Reject','2016-05-31 09:16:31'),(4400,'69833172','48847798','Access-Reject','2016-05-31 09:16:32'),(4403,'69833172','48847798','Access-Reject','2016-05-31 09:16:43'),(4587,'21222983','72817855','Access-Reject','2016-05-31 09:30:53'),(4600,'21222983','72817855','Access-Reject','2016-05-31 09:31:06'),(4623,'21222983','72817855','Access-Reject','2016-05-31 09:31:30'),(4624,'21222983','72817855','Access-Reject','2016-05-31 09:31:31'),(4658,'21222983','72817855','Access-Reject','2016-05-31 09:32:02'),(4678,'21222983','72817855','Access-Reject','2016-05-31 09:32:25'),(4701,'21222983','72817855','Access-Reject','2016-05-31 09:32:56'),(4728,'21222983','72817855','Access-Reject','2016-05-31 09:33:34'),(4791,'21222983','72817855','Access-Reject','2016-05-31 09:34:25'),(4798,'21222983','72817855','Access-Reject','2016-05-31 09:34:30'),(4803,'21222983','72817855','Access-Reject','2016-05-31 09:34:39'),(4855,'21222983','72817855','Access-Reject','2016-05-31 09:36:24'),(4856,'21222983','72817855','Access-Reject','2016-05-31 09:36:25'),(4868,'69833172','48847798','Access-Reject','2016-05-31 09:36:37'),(4888,'21222983','72817855','Access-Reject','2016-05-31 09:36:54'),(4890,'21222983','72817855','Access-Reject','2016-05-31 09:36:55'),(4916,'69833172','48847798','Access-Reject','2016-05-31 09:39:16'),(4937,'21222983','72817855','Access-Reject','2016-05-31 09:40:35'),(5010,'69833172','48847798','Access-Reject','2016-05-31 09:43:49'),(5043,'69833172','48847798','Access-Reject','2016-05-31 09:44:13'),(5054,'69833172','48847798','Access-Reject','2016-05-31 09:44:24'),(5105,'788359691','57748444','Access-Reject','2016-05-31 09:50:10'),(5106,'788359691','57748444','Access-Reject','2016-05-31 09:50:11'),(5293,'5285278','81324889','Access-Reject','2016-05-31 10:16:14'),(5295,'5285278','81324889','Access-Reject','2016-05-31 10:16:25'),(5296,'5285278','81324889','Access-Reject','2016-05-31 10:16:26'),(5298,'5285278','81324889','Access-Reject','2016-05-31 10:16:40'),(5299,'5285278','81324889','Access-Reject','2016-05-31 10:16:53'),(5302,'5285278','81324889','Access-Reject','2016-05-31 10:17:18'),(5307,'5285278','81324889','Access-Reject','2016-05-31 10:17:50'),(5353,'5285278','81324889','Access-Reject','2016-05-31 10:25:42'),(5404,'13935493','514095219','Access-Reject','2016-05-31 10:33:45'),(5437,'69833172','48847798','Access-Reject','2016-05-31 10:39:42'),(5579,'30062428','51913668','Access-Reject','2016-05-31 10:54:31'),(5601,'88858439','75234328','Access-Reject','2016-05-31 10:57:06'),(5603,'88858439','75234328','Access-Reject','2016-05-31 10:57:19'),(5713,'38772442','69998364','Access-Reject','2016-05-31 11:10:35'),(5715,'38772442','69998364','Access-Reject','2016-05-31 11:10:48'),(6063,'99567956','97613552','Access-Reject','2016-05-31 11:56:17'),(6213,'20210109','18642143','Access-Reject','2016-05-31 12:12:46'),(6214,'29468929','65255833','Access-Reject','2016-05-31 12:12:48'),(6216,'29468929','65255833','Access-Reject','2016-05-31 12:12:57'),(6218,'20210109','18642143','Access-Reject','2016-05-31 12:13:03'),(6219,'29468929','65255833','Access-Reject','2016-05-31 12:13:10'),(6344,'95119767','58359993','Access-Reject','2016-05-31 12:26:31'),(6348,'95119767','58359993','Access-Reject','2016-05-31 12:26:43'),(6352,'95119767','58359993','Access-Reject','2016-05-31 12:26:57'),(6359,'95119767','58359993','Access-Reject','2016-05-31 12:27:43'),(6361,'95119767','58359993','Access-Reject','2016-05-31 12:27:44'),(6363,'95119767','58359993','Access-Reject','2016-05-31 12:27:57'),(6636,'58819328','91477583','Access-Reject','2016-05-31 12:54:00'),(6776,'32987786','31581693','Access-Reject','2016-05-31 13:06:23'),(6849,'6146919','32843794','Access-Reject','2016-05-31 13:12:15'),(6971,'21222983','72817855','Access-Reject','2016-05-31 13:22:23'),(7040,'38415195','23722185','Access-Reject','2016-05-31 13:27:18'),(7047,'38415195','23722185','Access-Reject','2016-05-31 13:27:33'),(7051,'38415195','23722185','Access-Reject','2016-05-31 13:27:52'),(7070,'5285594','14642279','Access-Reject','2016-05-31 13:29:16'),(7099,'84263481','25148923','Access-Reject','2016-05-31 13:31:13'),(7107,'84263481','25148923','Access-Reject','2016-05-31 13:31:33'),(7118,'84263481','25148923','Access-Reject','2016-05-31 13:32:02'),(7223,'3986484','479933366','Access-Reject','2016-05-31 13:39:46'),(7241,'3986484','479933366','Access-Reject','2016-05-31 13:41:20'),(7246,'3986484','479933366','Access-Reject','2016-05-31 13:41:44'),(7248,'3986484','479933366','Access-Reject','2016-05-31 13:42:01'),(7255,'3986484','479933366','Access-Reject','2016-05-31 13:42:22'),(7571,'78835969','57748444','Access-Reject','2016-05-31 14:07:18'),(7576,'78835969','57748444','Access-Reject','2016-05-31 14:07:35'),(7578,'788359696','57748444','Access-Reject','2016-05-31 14:07:47'),(7586,'89314814','22493494','Access-Reject','2016-05-31 14:08:21'),(7593,'89314814','22493494','Access-Reject','2016-05-31 14:08:34'),(7706,'59889948','99123271','Access-Reject','2016-05-31 14:17:21'),(7707,'59889946','99123271','Access-Reject','2016-05-31 14:17:33'),(7712,'59819946','99123271','Access-Reject','2016-05-31 14:17:52'),(7738,' 66818169','44624152 ','Access-Reject','2016-05-31 14:19:20'),(7787,'19745996','82578348','Access-Reject','2016-05-31 14:22:12'),(7789,'19745996','82578348','Access-Reject','2016-05-31 14:22:13'),(7791,'74466661','47812843','Access-Reject','2016-05-31 14:22:19'),(8112,'42159592','42159592','Access-Reject','2016-05-31 14:44:57'),(8113,'42159592','42159592','Access-Reject','2016-05-31 14:45:16'),(8158,'58574249ï¼Œ','25957342','Access-Reject','2016-05-31 14:48:26'),(8163,'58574249ï¼Œ','25957342','Access-Reject','2016-05-31 14:48:45'),(8202,'42159592','42159592','Access-Reject','2016-05-31 14:52:18'),(8310,'11598575=2C88626791','88626791','Access-Reject','2016-05-31 15:00:52'),(8312,'11598575=2C88626791','88626791','Access-Reject','2016-05-31 15:01:06'),(8314,'11598575=2C88626791','88626791','Access-Reject','2016-05-31 15:01:07'),(8640,'65299674','38432386','Access-Reject','2016-05-31 15:21:48'),(8658,'26484545','81711265','Access-Reject','2016-05-31 15:23:00'),(8671,'26484545','81711265','Access-Reject','2016-05-31 15:24:22'),(8672,'26484545','81711265','Access-Reject','2016-05-31 15:24:23'),(8674,'26484545','81711265','Access-Reject','2016-05-31 15:24:33'),(8693,'55145869','58333771','Access-Reject','2016-05-31 15:26:17'),(8828,'99288976','48794482','Access-Reject','2016-05-31 15:40:46'),(9095,'626262295','68137116','Access-Reject','2016-05-31 16:02:07'),(9100,'626262295','68137116','Access-Reject','2016-05-31 16:02:19'),(9105,'626262295','68137116','Access-Reject','2016-05-31 16:02:37'),(9121,'626262295','68137116','Access-Reject','2016-05-31 16:03:38'),(9125,'626262295','68137116','Access-Reject','2016-05-31 16:03:56'),(9131,'626262295','68137116','Access-Reject','2016-05-31 16:04:13'),(9136,'626262295','68137116','Access-Reject','2016-05-31 16:04:28'),(9141,'626262295','68137116','Access-Reject','2016-05-31 16:04:46'),(9238,'31941768','69274313','Access-Reject','2016-05-31 16:13:40'),(9244,'31941768','69274313','Access-Reject','2016-05-31 16:13:59'),(9245,'31941768','69274313','Access-Reject','2016-05-31 16:14:16'),(9248,'31941768','69274313','Access-Reject','2016-05-31 16:14:28'),(9255,'31941768','69274313','Access-Reject','2016-05-31 16:15:31'),(9386,'69554477','71481356','Access-Reject','2016-05-31 16:36:42'),(9388,'69554477','71481356','Access-Reject','2016-05-31 16:37:04'),(10374,'2448556849','ltd123456789','Access-Reject','2016-05-31 17:59:29'),(10851,'41597529','83613842','Access-Reject','2016-05-31 19:17:49'),(12736,'13314256','95642483','Access-Reject','2016-05-31 23:36:54'),(12740,'13314256','95642483','Access-Reject','2016-05-31 23:37:06'),(12742,'13314256','95642483','Access-Reject','2016-05-31 23:37:21'),(12749,'27251898','29684668','Access-Reject','2016-05-31 23:37:35'),(12752,'27251898','29684668','Access-Reject','2016-05-31 23:37:50'),(13583,'65345884','51131479','Access-Reject','2016-06-01 00:31:29'),(13595,'65345884','51131479','Access-Reject','2016-06-01 00:31:55'),(14731,'84767964','71744333','Access-Reject','2016-06-01 01:45:24'),(14740,'84767964','71744333','Access-Reject','2016-06-01 01:45:38'),(14758,'84767964','71744333','Access-Reject','2016-06-01 01:46:31'),(14759,'84767964','71744333','Access-Reject','2016-06-01 01:47:04'),(14770,'test','test','Access-Accept','2016-06-01 10:12:48'),(14771,'test','test','Access-Accept','2016-06-01 10:16:07'),(14772,'111','111','Access-Accept','2016-06-01 15:44:38'),(14773,'222','222','Access-Accept','2016-06-01 15:44:38'),(14774,'333','333','Access-Accept','2016-06-01 15:44:38'),(14775,'444','444','Access-Accept','2016-06-01 15:44:39'),(14776,'t','t','Access-Accept','2016-06-01 15:55:03'),(14778,'r','r','Access-Reject','2016-06-01 16:09:47'),(14779,'r','r','Access-Reject','2016-06-01 16:09:48'),(14780,'t','t','Access-Accept','2016-06-01 16:09:57'),(14781,'t','t','Access-Accept','2016-06-01 16:13:38'),(14782,'t','t','Access-Accept','2016-06-01 16:22:00'),(14783,'t','t','Access-Accept','2016-06-01 16:55:36'),(14784,'t','t','Access-Accept','2016-06-01 16:57:28'),(14785,'t','t','Access-Accept','2016-06-01 17:04:05'),(14786,'t','t','Access-Accept','2016-06-01 17:21:37'),(14787,'1111','1111','Access-Reject','2016-06-01 17:22:42'),(14788,'1111','1111','Access-Reject','2016-06-01 17:22:43'),(14789,'1111','1111','Access-Reject','2016-06-01 17:22:55'),(14790,'1111','1111','Access-Reject','2016-06-01 17:22:56'),(14791,'t','t','Access-Accept','2016-06-01 17:23:30'),(14792,'t','t','Access-Accept','2016-06-01 17:24:54'),(14793,'t','t','Access-Accept','2016-06-01 17:25:12'),(14794,'1111','1111','Access-Reject','2016-06-01 17:25:41'),(14795,'1111','1111','Access-Reject','2016-06-01 17:25:42'),(14796,'2222','2222','Access-Reject','2016-06-01 17:25:55'),(14797,'2222','2222','Access-Reject','2016-06-01 17:25:56'),(14798,'t','t','Access-Accept','2016-06-01 17:27:44'),(14799,'t','t','Access-Accept','2016-06-01 17:27:46'),(14800,'t','t','Access-Accept','2016-06-01 17:36:22'),(14801,'123=5D','123','Access-Reject','2016-06-01 18:23:26'),(14802,'123=5D','123','Access-Reject','2016-06-01 18:23:27'),(14803,'t','t','Access-Accept','2016-06-01 18:52:17'),(14804,'t','t','Access-Accept','2016-06-01 19:20:28'),(14805,'t','t','Access-Accept','2016-06-01 19:43:51'),(14806,'444','444','Access-Accept','2016-06-01 19:52:19'),(14807,'111','111','Access-Accept','2016-06-01 19:52:28'),(14808,'222','222','Access-Accept','2016-06-01 19:52:28'),(14809,'333','333','Access-Accept','2016-06-01 19:52:28'),(14810,'444','444','Access-Accept','2016-06-01 19:52:32'),(14811,'t','t','Access-Accept','2016-06-01 19:53:32'),(14812,'0000','0000','Access-Accept','2016-06-01 20:10:58'),(14813,'0000','0000','Access-Accept','2016-06-01 20:24:07'),(14814,'0000','0000','Access-Accept','2016-06-02 04:24:23'),(14815,'111','111','Access-Accept','2016-06-02 05:09:43'),(14816,'111','111','Access-Accept','2016-06-02 05:24:53'),(14817,'111','111','Access-Accept','2016-06-02 05:26:43'),(14818,'111','111','Access-Accept','2016-06-02 06:02:45'),(14819,'111','111','Access-Accept','2016-06-02 06:05:27'),(14820,'111','111','Access-Accept','2016-06-02 06:05:44'),(14821,'0000','0000','Access-Accept','2016-06-02 07:25:31'),(14822,'222','222','Access-Accept','2016-06-02 08:16:10'),(14823,'222','222','Access-Accept','2016-06-02 09:20:23'),(14824,'222','222','Access-Accept','2016-06-02 09:24:25'),(14825,'222','222','Access-Accept','2016-06-02 09:25:46'),(14826,'222','222','Access-Accept','2016-06-02 09:25:56'),(14827,'222','222','Access-Accept','2016-06-02 09:26:04'),(14828,'222','222','Access-Accept','2016-06-02 09:46:00'),(14829,'222','222','Access-Accept','2016-06-02 10:13:46'),(14830,'222','222','Access-Accept','2016-06-02 10:16:35');
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radusergroup` (
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT '1',
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES ('111','30day6G',0),('222','1day500M',0),('333','30day12G',0),('444','15day',0),('t','30day',0),('0000','30day12G',0);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realms`
--

DROP TABLE IF EXISTS `realms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `realmname` varchar(128) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `authhost` varchar(256) DEFAULT NULL,
  `accthost` varchar(256) DEFAULT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `ldflag` varchar(64) DEFAULT NULL,
  `nostrip` int(8) DEFAULT NULL,
  `hints` int(8) DEFAULT NULL,
  `notrealm` int(8) DEFAULT NULL,
  `creationdate` datetime DEFAULT NULL,
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realms`
--

LOCK TABLES `realms` WRITE;
/*!40000 ALTER TABLE `realms` DISABLE KEYS */;
/*!40000 ALTER TABLE `realms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userbillinfo`
--

DROP TABLE IF EXISTS `userbillinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbillinfo` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `planName` varchar(128) DEFAULT NULL,
  `hotspot_id` int(32) DEFAULT NULL,
  `hotspotlocation` varchar(32) DEFAULT NULL,
  `contactperson` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `cash` varchar(200) DEFAULT NULL,
  `creditcardname` varchar(200) DEFAULT NULL,
  `creditcardnumber` varchar(200) DEFAULT NULL,
  `creditcardverification` varchar(200) DEFAULT NULL,
  `creditcardtype` varchar(200) DEFAULT NULL,
  `creditcardexp` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserbillinfo` varchar(128) DEFAULT NULL,
  `lead` varchar(200) DEFAULT NULL,
  `coupon` varchar(200) DEFAULT NULL,
  `ordertaker` varchar(200) DEFAULT NULL,
  `billstatus` varchar(200) DEFAULT NULL,
  `lastbill` date NOT NULL DEFAULT '0000-00-00',
  `nextbill` date NOT NULL DEFAULT '0000-00-00',
  `nextinvoicedue` int(32) DEFAULT NULL,
  `billdue` int(32) DEFAULT NULL,
  `postalinvoice` varchar(8) DEFAULT NULL,
  `faxinvoice` varchar(8) DEFAULT NULL,
  `emailinvoice` varchar(8) DEFAULT NULL,
  `batch_id` int(32) DEFAULT NULL,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `planname` (`planName`)
) ENGINE=MyISAM AUTO_INCREMENT=2978 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbillinfo`
--

LOCK TABLES `userbillinfo` WRITE;
/*!40000 ALTER TABLE `userbillinfo` DISABLE KEYS */;
INSERT INTO `userbillinfo` VALUES (2971,'111',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 11:43:57','administrator',NULL,NULL),(2972,'222',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 11:44:05','administrator',NULL,NULL),(2973,'333',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 11:44:17','administrator',NULL,NULL),(2974,'444',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 11:44:26','administrator',NULL,NULL),(2975,'t',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 11:54:46','administrator',NULL,NULL),(2977,'0000',NULL,NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2016-06-01 15:53:24','administrator',NULL,NULL);
/*!40000 ALTER TABLE `userbillinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `firstname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `department` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `workphone` varchar(200) DEFAULT NULL,
  `homephone` varchar(200) DEFAULT NULL,
  `mobilephone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserinfo` varchar(128) DEFAULT NULL,
  `portalloginpassword` varchar(128) DEFAULT '',
  `enableportallogin` int(32) DEFAULT '0',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2978 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES (2971,'111','','','','','','','','','','','','','','','0','',0,'2016-06-01 11:43:57','administrator',NULL,NULL),(2972,'222','','','','','','','','','','','','','','','0','',0,'2016-06-01 11:44:05','administrator',NULL,NULL),(2973,'333','','','','','','','','','','','','','','','0','',0,'2016-06-01 11:44:17','administrator',NULL,NULL),(2974,'444','','','','','','','','','','','','','','','0','',0,'2016-06-01 11:44:26','administrator',NULL,NULL),(2975,'t','','','','','','','','','','','','','','','0','',0,'2016-06-01 11:54:46','administrator',NULL,NULL),(2977,'0000','','','','','','','','','','','','','','','0','',0,'2016-06-01 15:53:24','administrator',NULL,NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wimax`
--

DROP TABLE IF EXISTS `wimax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wimax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `authdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `spi` varchar(16) NOT NULL DEFAULT '',
  `mipkey` varchar(400) NOT NULL DEFAULT '',
  `lifetime` int(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `spi` (`spi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wimax`
--

LOCK TABLES `wimax` WRITE;
/*!40000 ALTER TABLE `wimax` DISABLE KEYS */;
/*!40000 ALTER TABLE `wimax` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-02  6:49:55
