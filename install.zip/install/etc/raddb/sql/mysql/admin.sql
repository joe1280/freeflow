CREATE USER 'radius'@'localhost';  
SET PASSWORD FOR 'radius'@'localhost' = PASSWORD('hehe123');  
GRANT All ON radius.* TO 'radius'@'localhost'; 
