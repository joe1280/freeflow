<script type="text/javascript" src="library/tabber/tabber.js"></script>
<link rel="stylesheet" href="library/tabber/tab-css2.css" TYPE="text/css" MEDIA="screen">

<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
</script>

